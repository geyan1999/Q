// @ts-nocheck
import * as tools from '@/assets/js/util'
// import SDKEMIT from '@/assets/js/sdk.emit'
import EVENTS from '../event-types'
import * as _TYPES from '../action-types'
export default function sdkInit({ sdk, $vue }) {
	let $commit = $vue.$store.commit
	let $getters = $vue.$store.getters
	let $dispatch = $vue.$store.dispatch
	// let TYPES = $vue.TYPES

	// 房间初始化
	sdk.on(EVENTS.ROOM.INIT, (initData) => {
		// console.log('[SDK_EVENT_ON]::room:init', initData)
	})

	// 直播未开始
	sdk.on(EVENTS.LIVE.WAIT, () => {
		// console.log('[SDK_EVENT_ON]::live:wait')
		$dispatch(_TYPES.UPDATE_LIVE_STATE, 'wait')
	})

	// 直播开始
	sdk.on(EVENTS.LIVE.START, (title) => {
		// console.log('[SDK_EVENT_ON]::live:start', title)
		if (title) {
			document.title = title
		}
		$dispatch(_TYPES.UPDATE_LIVE_STATE, 'start')
	})

	// 直播停止
	sdk.on(EVENTS.LIVE.STOP, () => {
		// console.error('[SDK_EVENT_ON]::live:stop')
		$dispatch(_TYPES.UPDATE_LIVE_STATE, 'stop')
		$commit(_TYPES.UPDATE_MODE_CHANGE, 0)
	})

	// 直播更新
	sdk.on(EVENTS.LIVE.UPDATE_WB, (data) => {
		// console.error('[SDK_EVENT_ON]::live.data.update', data.live)
		if (data.live) {
			$commit(_TYPES.UPDATE_LIVEID, data.live.liveid)
		}
		if (data.action == 2) {
			// console.error("UPDATE_WHITEBOARD")
			$commit(_TYPES.UPDATE_WHITEBOARD, true)
		}
	})

	// 摄像头开启
	sdk.on(EVENTS.CAMERA.START, () => {
		// console.log('[SDK_EVENT_ON]::camera:start')
		let { ...playerStatus } = $getters.getPlayerStatus
		playerStatus.camera = 'open'
		$commit(_TYPES.UPDATE_PAGE_INFO, { playerStatus: playerStatus })
	})

	// 摄像头关闭
	sdk.on(EVENTS.CAMERA.STOP, () => {
		// console.log('[SDK_EVENT_ON]::camera:stop')
		let { ...playerStatus } = $getters.getPlayerStatus
		playerStatus.camera = 'close'
		$commit(_TYPES.UPDATE_PAGE_INFO, { playerStatus: playerStatus })
	})

	// 当前在线人数
	sdk.on(EVENTS.MEMBER.TOTAL, (total) => {
		// console.error(total)
		$commit(_TYPES.UPDATE_MEMBER_TOTAL, total)
	})

	// 机器人
	sdk.on(EVENTS.MEMBER.ROBOTS, (res) => {
		// console.log("robots", res)
		$dispatch(_TYPES.UPDATE_ROBOTS_TOTAL, { total: res.robots.total })
	})

	// 接收信息
	sdk.on(EVENTS.CHAT.SEND, (chat) => {
		chat = sdk.getAvatar(chat)
		$commit(_TYPES.CHAT_UPDATE_LIST, chat)
	})

	// 接收私聊信息
	sdk.on(EVENTS.CHAT.PRIVATE, (chat) => {
		// console.error(chat)
		chat.type = "service"
		$commit("updatePvChatList", chat)
		$commit("updateChatTip", chat)
		$commit("updateCurTip", true)
	})

	// 禁止发言
	sdk.on(EVENTS.CHAT.DISABLE, (chat) => {
		if (!tools.isMe(chat, $getters.getHtData.user)) {
			let chatlist = []
			$getters.getChatList.forEach((item) => {
				if (item.xid != chat.xid) {
					chatlist.push(item)
				}
			})
			$commit(_TYPES.CHAT_SET_LIST, chatlist)
		}
	})

	// 解除禁言
	sdk.on(EVENTS.CHAT.ENABLE, (chat) => {
		// console.error(tools.isMe(chat, $getters.getHtData.user))
	})

	// 模式切换
	sdk.on(EVENTS.LIVE.MODE_CHANGE, (mode) => {
		// console.log("模式切换消息==>", mode)
		// console.error("模式",mode)
		$commit(_TYPES.UPDATE_MODE_CHANGE, mode.currentMode)
	})

	// 打赏主播消息
	sdk.on('live:reward', (data) => {
		let reward = {
			type: 'notify_reward_zhubo',
			nickname: data.nickname,
			money: data.money
		}
		$commit(_TYPES.CHAT_UPDATE_LIST, reward)
		$commit(_TYPES.UPDATE_REWARD_MSG, reward)
	})
	// 接收红包信息
	sdk.on(EVENTS.REWARD.SEND, (data) => {
		// console.log("接收红包")
		let reward = {
			type: 'notify_reward',
			originCnt: data,
			end: 0
		}
		$commit(_TYPES.CHAT_UPDATE_LIST, reward)
	})

	// 红包领取信息
	sdk.on(EVENTS.REWARD.GET, (data) => {
		// console.log("红包领取")
		let reward = {
			type: 'notify_reward',
			originCnt: data,
			end: 1
		}
		$commit(_TYPES.CHAT_UPDATE_LIST, reward)
	})

	// 红包已领取完信息
	sdk.on(EVENTS.REWARD.END, (data) => {
		// console.log("红包领取完")
		let reward = {
			type: 'notify_reward',
			originCnt: data,
			end: 2
		}
		$commit(_TYPES.CHAT_UPDATE_LIST, reward)
	})


	// 接收通知
	sdk.on(EVENTS.NOTICE.PUBLIC, (data) => {
		$commit(_TYPES.UPDATE_PUBLIC_NOTICE, data)
	})

	// 滚动通知
	sdk.on(EVENTS.NOTICE.SCROLL, (data) => {
		$dispatch(_TYPES.UPDATE_SCROLL_NOTICE, data)
	})

	// 切换PPT、黑板
	sdk.on(EVENTS.LIVE.SET.PAGE, () => {
		// console.log('[SDK_EVENT_ON]::live:set:page')
		let { ...playerStatus } = $getters.getPlayerStatus
		playerStatus.course = 'open'
		$commit(_TYPES.UPDATE_PAGE_INFO, { playerStatus: playerStatus })
	})

	// 收到新投票
	sdk.on(EVENTS.VOTE.NEW, (data) => {
		// console.log('[SDK_EVENT_ON]::vote:new d => ', data)
		$commit(_TYPES.UPDATE_VOTE_STATUS, 'start')
		$commit(_TYPES.UPDATE_VOTE_POP_STATUS, 'open')
		$commit(_TYPES.UPDATE_NEW_VOTE, data)
		// 插入
		let d = {
			type: 'notify_vote',
			originCnt: data
		}
		$commit(_TYPES.CHAT_UPDATE_LIST, d)
		$commit(_TYPES.UPDATE_TOOLS_MODE, { type: 'vote', flag: true })
	})

	// 公布投票结果
	sdk.on(EVENTS.VOTE.PUB, (data) => {
		// console.log('[SDK_EVENT_ON]::vote:PUB => data => ', data)
		if (!data.isShow) {
			return
		}
		$commit(_TYPES.UPDATE_VOTE_STATUS, 'end')
		$commit(_TYPES.UPDATE_VOTE_POP_STATUS, 'open')
		$commit(_TYPES.UPDATE_VOTE_RESULT, data)

		// 插入
		let d = {
			type: 'notify_vote',
			originCnt: data
		}
		$commit(_TYPES.CHAT_UPDATE_LIST, d)
		$commit(_TYPES.UPDATE_TOOLS_MODE, { type: 'vote', flag: true })
	})

	// 课程错误
	sdk.on(EVENTS.LIVE.COURSE_ERROR, (res) => {
		// $vue.$vux.alert.show({
		//   title: '提示',
		//   content: res.msg
		// })
		$dispatch(_TYPES.UPDATE_LIVE_STATE, 'error')
	})

	// 房间错误
	sdk.on(EVENTS.SYSTEM.ROOM.ERROR, (res) => {
		// $vue.$vux.toast.text(data.msg, 'center')
		$vue.$vux.alert.show({
			title: '提示',
			content: res.msg
		})
		$dispatch(_TYPES.UPDATE_LIVE_STATE, 'error')
	})

	// 点赞
	sdk.on(EVENTS.LIKE.TOTAL, (data) => {
		// console.log('[SDK_EVENT_ON]::question:apply data => ', data)
		// console.error(new Date().getTime())
		$commit(_TYPES.UPDATA_LIKE_TIME, new Date().getTime())
		$commit(_TYPES.UPDATA_LIKE, data.times)
	})

	// 提问错误
	sdk.on(EVENTS.QUESTION.ERROR, (data) => {
		// console.log('[SDK_EVENT_ON]::question:ask error => ', data)
		$vue.$vux.toast.text(data.msg, 'bottom')
	})

	// 收到提问
	sdk.on(EVENTS.QUESTION.ASK, (data) => {
		// console.error('[SDK_EVENT_ON]::question:ask data => ', data)
		let d = {
			type: 'question',
			data: data
		}
		if (!$getters.getToolsQuestion) {
			$commit(_TYPES.UPDATE_QUESTION_TIP, true)
		}
		$commit(_TYPES.UPDATE_QUESTION_LIST, d)
	})

	// 收到提问
	sdk.on(EVENTS.QUESTION.APPLY, (data) => {
		// console.error('[SDK_EVENT_ON]::question:apply data => ', data)
		let d = {
			type: 'question',
			data: data
		}
		$commit(_TYPES.UPDATE_QUESTION_LIST, d)
		if (!$getters.getToolsQuestion) {
			$commit(_TYPES.UPDATE_QUESTION_TIP, true)
		}
	})

	// 收到提问回答
	sdk.on(EVENTS.QUESTION.REPLY, (data) => {
		// console.log('[SDK_EVENT_ON]::question:reply data => ', data)
		let d = {
			type: 'teacher_reply',
			data: data
		}
		$commit(_TYPES.UPDATE_QUESTION_LIST, d)
		if (!$getters.getToolsQuestion) {
			$commit(_TYPES.UPDATE_QUESTION_TIP, true)
		}
	})

	// 提问被删除
	sdk.on(EVENTS.QUESTION.DELETE, (data) => {
		// console.log('[SDK_EVENT_ON]::question:delete data => ', data)
		$commit(_TYPES.UPDATE_QUESTION_LIST, { type: 'delete', data: data })
	})

	// 签到开始
	sdk.on(EVENTS.SIGN.NEW, (data) => {
		$commit(_TYPES.UPDATA_NEW_SIGN, data)
		$commit(_TYPES.UPDATA_SIGN_STATUS, 'start')
	})

	// 签到结束
	sdk.on(EVENTS.SIGN.END, () => {
		$commit(_TYPES.UPDATA_SIGN_STATUS, 'end')
	})

	// 抽奖开始
	sdk.on(EVENTS.LOTTERY.START, (data) => {
		// console.log('[SDK_EVENT_ON]::LOTTERY:START', data)
		$commit(_TYPES.UPDATE_LOTTERY_STATUS, {
			staus: 0,
			data: data
		})
	})

	// 抽奖结束
	sdk.on(EVENTS.LOTTERY.STOP, (data) => {
		// console.log('[SDK_EVENT_ON]::LOTTERY:STOP', data)
		$commit(_TYPES.UPDATE_LOTTERY_STATUS, {
			staus: 1,
			data: data
		})

	})

	// 退出
	sdk.on(EVENTS.MEMBER.FORCEOUT, () => {
		if (window.partner_id == 13067) {
			return false
		} else {
			setTimeout(function () {
				window.location.href = `//${window.apiHost || 'open.talk-fun.com'}/open/maituo/mobile_error.html?var=3`;
			}, 100);
		}
	})

	// 踢人
	sdk.on(EVENTS.MEMBER.KICK, () => {
		setTimeout(function () {
			window.location.replace(`//${window.apiHost || 'open.talk-fun.com'}/open/maituo/mobile_error.html?var=4`);
		}, 100);
	})

	// 用户进入直播
	sdk.on("member:join:other", (data) => {
		// console.error("member:join:other",data)
		if (data.member.role === 'user') {
			$commit(_TYPES.UPDATE_CHAT_INTOROOM, data)
		}
		if (data.member.role === 'admin') {
			// 更新客服列表
			$dispatch("setIntoUser", data.member)
		}
	})

	/**
	 * 创建摄像头am
	 * @camera(@容器ID, @播放器ID, @回调函数)
	 */
	sdk.camera("ht_camera_container", 'cameraVideo', (cameraPlayer) => {
		if (cameraPlayer && cameraPlayer.setAttribute) {
			let getConfig = $getters.getConfig
			if (getConfig && getConfig.global.switch.background && getConfig.global.switch.background.enable == 1 && getConfig.global.switch.background.url != '') {
				cameraPlayer.setAttribute('poster', getConfig.global.switch.background.url)
			} else {
				// cameraPlayer.setAttribute('poster', '//static-1.talk-fun.com/open/cooperation/default/live-h5-v1/static/img/bg_full.png')
			}
		}
		if (window.MT && window.MT.tools && window.MT.tools.isCompatible()) {
			if (cameraPlayer) {
				if ($getters.getConfig.global.setting.pageViewMode == 1) {
					cameraPlayer.setAttribute('x5-video-player-type', 'h5')
				}
			}
		}
		if (window.isVod) {
			let timer = setInterval(() => {
				let dom = document.getElementById("ht_camera_container")
				let video = dom.getElementsByTagName("video")[0]
				if (video) {
					$commit("setVodPlayVideo", video)
					clearInterval(timer)
				}
			}, 1000)
		}
	})

	/**
	 * 创建外部推流播放器
	 * @mainPlayer(@容器ID, @播放器ID, @回调函数)
	 */
	sdk.mainPlayer('ht_player_container', 'playerVideo', (player) => {
		// console.error(player)
		if (player && player.setAttribute) {
			let getConfig = $getters.getConfig
			if (getConfig && getConfig.global.switch.background && getConfig.global.switch.background.enable == 1 && getConfig.global.switch.background.url != '') {
				player.setAttribute('poster', getConfig.global.switch.background.url)
			} else {
				// player.setAttribute('poster', '//static-1.talk-fun.com/open/cooperation/default/live-h5-v1/static/img/bg_full.png')
			}
		}
		if (window.isVod) {
			let timer = setInterval(() => {
				let dom = document.getElementById("ht_player_container")
				let video = dom.getElementsByTagName("video")[0]
				if (video) {
					$commit("setVodPlayVideo", video)
					clearInterval(timer)
				}
			}, 1000)
		}
	})

	/**
	 * 创建课件播放器
	 * @whiteboardPlayer(@容器ID, @播放器ID, @回调函数)
	 */
	if (sdk.whiteboardPlayer) {
		sdk.whiteboardPlayer('ht_course_container', 'courseVideo', (whiteboardPlayer) => {
			// console.error(courseVideo)
			whiteboardPlayer.whiteboardResize()
		})
	}


	sdk.on('live:info', function (live) {
		// console.log("live", live)
	});
	sdk.on('live:message:append', function (curlist) {
		// console.log("curlist", curlist)
		$commit(_TYPES.CHAT_INIT_LIST, curlist)
	});
	sdk.on('live:seek:begin', function (duration) {
		// console.log("开始", duration)
	})
	sdk.on("live:seek:finish", function (duration) {
		// console.log("结束", duration)
	});
	sdk.on("live:course:access:error", function (data) {
		// console.error("课程已结束",data)
		$commit(_TYPES.UPDATE_COURSEStAtUS, false)
	})
	// 直播器状态
	sdk.on('live:duration', function (currentTime, duration, currentPercent) {
		// console.error(currentTime,duration)
		// 返回seek时间点
		// console.log(currentTime, duration, currentPercent)
		$commit(_TYPES.UPDATE_LIVE_VOD, {
			currentTime: currentTime,
			duration: duration,
			currentPercent: currentPercent
		})
		if (Number(currentTime) !== 0) {
			$commit('changePlayStatus', 'play')
		}
	})
	sdk.on('live:camera:waiting', (data) => {
		$commit(_TYPES.UPDATE_VIDEO_STATUS, 'waiting')
	})

	sdk.on('live:camera:timeupdate', () => {
		$commit(_TYPES.UPDATE_VIDEO_STATUS, 'onplay')
	})

	sdk.on('live:video:onplay', (data) => {
		$commit(_TYPES.UPDATE_VIDEO_STATUS, 'onplay')
	})

	sdk.on('live:video:play', () => {
		$commit(_TYPES.UPDATE_VIDEO_STATUS, 'onplay')
	})
	sdk.on('live:video:pause', () => {
		$commit(_TYPES.UPDATE_VIDEO_STATUS, 'pause')
		$commit('changePlayStatus', 'pause')
	})
	sdk.on('live:camera:timeout', (t, t2) => {
		$commit(_TYPES.UPDATE_VIDEO_STATUS, 'overTime')
	})
	sdk.on('live:video:waiting', () => {
		$commit('changePlayStatus', 'waiting')
	})
	// 修改商品
	sdk.on('goods:edit', (data) => {
		let goods = [...$getters.getProductIdList]
		goods.forEach((product,index,arr)=>{
			if(product.id == data.id){
				arr.splice(index,1,data)
			}
		})
		$commit(_TYPES.UPDATE_PRODUCT, goods)
	})
	// 新增商品
	sdk.on('goods:add', (data) => {
		let goods = [...$getters.getProductIdList]
		goods.unshift(data)
		$commit(_TYPES.UPDATE_PRODUCT, goods)
	})
	// 商品更新
	sdk.on('goods:update', (data) => {
		let list = data.ids
		let type = data.putaway
		let goods = $getters.getProductIdList
		if (typeof (list) == 'string') {
			let updata = list.split(",")
			// 删除、下架
			if (type == -1 || type == 0) {
				let arr = []
				goods.forEach(product => {
					if (!updata.some(updata => {
						return Number(product.id) === Number(updata)
					})) {
						arr.push(product)
					}
				})
				$commit(_TYPES.UPDATE_PRODUCT, arr)
			}
			// 推荐、取消推荐
			if (type == 2 || type == 3) {
				let cancel = [] // 取消推荐
				let recom = [] // 推荐
				goods.forEach((product) => {
					if (updata.some(updata => {
						return Number(product.id) === Number(updata)
					})) {
						if (type == 2) {
							recom.push(product)
						}
						if (type == 3) {
							cancel.push(product)
						}
					}
				})
				if (type == 2) {
					$commit(_TYPES.UPDATE_ADD_PRODUCT, recom)
				}
				if (type == 3) {
					$commit(_TYPES.UPDATE_CANCEL_PRODUCT, cancel)
				}
			}
			// 商品排序
			if (type == 4) {
				let arr = []
				// console.error(updata, type, arr)
				try {
					updata.forEach((updata) => {
						goods.forEach((product) => {
							if (Number(product.id) === Number(updata)){
								arr.push(product)
							}
						})
					})
				} catch (err) {
					console.error(err)
				}
				$commit(_TYPES.UPDATE_PRODUCT, arr)
			}
		}
	})
	// 更新上架商品
	sdk.on('goods:put', (data) => {
		let list = data.ids
		let type = data.putaway
		let add = []
		let cancel = []
		let recom = []
		if (typeof (list) == 'string') {
			let product_list_up = list.split(",")
			product_list_up.forEach((update) => {
				$getters.getProductIdList.forEach((product, index) => {
					if (Number(product.id) === Number(update)) {
						// 将推荐，上架商品添加到add
						if (type == 2 || (product.putaway == 0 && type == 1)) {
							add.push({ product: product, index: index })
							// 推荐置顶
							if (type == 2) {
								recom.push({ product: product, index: index })
							}
						} else {
							// 取消推荐,下架
							cancel.push(product)
						}
						product.putaway = type
					}
				})
			})
			// 更新取消推荐商品
			if (cancel.length) {
				$commit(_TYPES.UPDATE_CANCEL_PRODUCT, cancel)
			}
			// 更新弹出商品
			if (add.length) {
				$commit(_TYPES.UPDATE_ADD_PRODUCT, add.sort((a, b) => {
					return a.index - b.index
				}).map(item => item.product))
				if (recom.length) {
					// 推荐排序
					$commit(_TYPES.UPDATE_PRODUCT, tools.onlyArr([...(recom.sort((a, b) => {
						return a.index - b.index
					}).map(item => item.product)), ...$getters.getProductIdList], 'id'))
				}
			} else {
				$commit(_TYPES.UPDATE_PRODUCT, [...$getters.getProductIdList])
			}

		}
	})
	// 更新优惠劵
	sdk.on('popup:put', (data) => {
		$commit(_TYPES.UPDATE_POP_CARD, data)
	})
	// 购买提示
	sdk.on('shopping:put', (data) => {
		$commit(_TYPES.UPDATE_SHOP, data)
	})
	// 播放线路
	sdk.on('live:network:list', (data) => {
		$commit(_TYPES.UPDATE_LIVE_LINE, data)
	})
	// 视频比例
	sdk.on('live:video:ratio', (data) => {
		// console.error(data)
	})
}
