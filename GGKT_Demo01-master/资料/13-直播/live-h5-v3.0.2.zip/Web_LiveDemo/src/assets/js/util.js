/**
 * ## 工具类 ##
 */

// 格式化时间
export const convertToHms = (val, flag) => {
  /**
   * 1501502139 - 10 * 60 * 60
   * @param {String | Number} val 为1970/01/01距离现在的 秒数
   * @param {Boolean} flag 是否输出字符串形式
   * @return {Object} 包含时分秒的对象
   * @return {Number} obj.h 小时
   * @return {Number} obj.m 分钟
   * @return {Number} obj.h 秒数
   * @example convertToHms(123131, true)         return 00:00:00 形式
   * @example convertToHms(123131, false)        return {h: 0, m: 0, s: 0}
   */
  // val的单位为秒
  val = parseInt(val)
  let h
  let m
  let s
  let prefixZero = val => {
    val = val >= 10 ?
      val :
      `0${val}`
    return val
  }
  if (!val) {
    h = m = s = '00'
  } else {
    h = prefixZero(Math.floor(val / 60 / 60))
    m = prefixZero(parseInt(val / 60 % 60))
    s = prefixZero(val % 60)
  }
  if (flag) {
    return `${h}:${m}:${s}`
  }
  return {
    h,
    m,
    s
  }
}
export const isMe = (user,self) => {
  if (user.xid == self.xid){
    return true
  }else{
    return false
  }
}
// 时间转换
export const convertTimestamp = (timestamp) => {
  let d = null
  if (typeof (timestamp) === 'string' && !Number(timestamp)) {
    return timestamp
  }
  if (typeof timestamp === 'object') {
    d = new Date(timestamp.time * 1000)
  } else {
    d = new Date(timestamp * 1000)
  }
  let h = d.getHours()
  let min = ('0' + d.getMinutes()).slice(-2)
  let time = h + ':' + min
  return time
}
// 微信环境判断
export const getIsWxClient = () => {
  var ua = navigator.userAgent.toLowerCase();
  if (ua.match(/MicroMessenger/i) == "micromessenger") {
      return true;
  }
  return false;
}
//判断横竖屏
export const isMobileStatus = () => {
  // 竖屏
  if (window.orientation === 180 || window.orientation === 0) {
    return 'vertical'
  }
  //  横屏
  if (window.orientation === 90 || window.orientation === -90) {
    return 'horizontal'
  }
}

// 获取系统平台信息
export const getPlatformInfo = () => {
  // UA
  let ua = navigator.userAgent.toLowerCase()
  let os = null
  let version = -1
  let isIOS = !!ua.match(/iphone|ipad|ipod/ig)
  let isAndroid = !!ua.match(/android/ig)
  // 系统
  if (isIOS) {
    os = 'ios'
    version = ua.match(/os\s([0-9_0-9]*)/)[1].replace('_', '.')
  } else if (isAndroid) {
    os = 'android'
    version = ua.match(/android\s([0-9\.]*)/)[1]
  }
  return {
    partform: os,
    version: parseFloat(version)
  }
}

export const isIPad = () => {
  let u = navigator.userAgent
  return u.indexOf('iPad') > -1
}

// 是否是苹果机
export const isIos = () => {
  return getPlatformInfo().partform === 'ios'
}

//是否是安卓机
export const isAndroid = () => {
  let u = navigator.userAgent
  let isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1 //android终端
  return isAndroid
}

// WeChat
export const isWechat = () => {
  let ua = navigator.userAgent
  let isInWechat = ua.match(/micromessenger/ig)
  return !!isInWechat
}

// weChat 版本
export const weChatVersion = () => {
  let wechatInfo = navigator.userAgent.match(/MicroMessenger\/([\d\.]+)/i)
  let wechatVersion = wechatInfo[1]
  return wechatVersion
}

// QQ
export const isQQBrowser = () => {
  let ua = navigator.userAgent
  let isInWechat = ua.match(/mqqbrowser/ig)
  return !!isInWechat
}

export const second2HMS = (d,str)=>{
  d = parseInt(d, 10);
  var h = Math.floor(d / 3600);
  var m = Math.floor(d % 3600 / 60);
  var s = Math.floor(d % 3600 % 60);
  var times = "";
  function format(num){
      var val = 0;
      if (num > 0){
      if (num >= 10){
              val = num;
          }else{
              val = '0' + num;
          }
      }
      else{
      val = '00';
      }
      return val;
  }
  var hr = format(h);
  var min = format(m);
  var sec = format(s);

  if(str){
      if(str == "total"){
          if(hr > 0){
             
              times =  hr + ':' + min + ':' + sec;
              
          }else{
             
              times =  min + ':' + sec;
          
          }
      }else if(str == "cur"){
          if(hr>0){
                  times =  hr + ':' + min + ':' + sec;
              }else{
                  times ='00:' + min + ':' + sec;
              } 
          
      }
  }
  return times
}

// 数组去重
export const onlyArr = (arr,key) =>{
  var result = [];
  var obj = {};
  for(var i =0; i<arr.length; i++){
      if(!obj[arr[i][key]]){
        result.push(arr[i]);
        obj[arr[i][key]] = true;
      }
  }
  return result
}

