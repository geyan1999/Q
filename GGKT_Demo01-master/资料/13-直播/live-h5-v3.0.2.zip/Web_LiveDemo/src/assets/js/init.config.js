import * as tools from '@/assets/js/util'
let initConfig = {
  $vue: null, // vue
  $getters: null, // vuex store getters
  $commit: null, // vuex store commit
  MEDIA_RADIO: 0.75, // 媒体宽高比
  SMALL_SCREEN_SCALE: 0.5, // 小屏缩放比
  MENU_HEIGHT: 35, // 菜单栏高度
  // 尺寸差异化处理
  sizeHander: {
    // 这里由于转屏后立马获取的宽高是转屏前的宽高 所以用了递归去获取正确的宽高
    normal_vertical(resolve) {
      let h = document.body.clientHeight
      let w = document.body.clientWidth
      if (h < w) {
        setTimeout(() => {
          this.normal_vertical(resolve)
        }, 500)
      } else {
        resolve({h, w})
      }
    },
    // 这里微信浏览器有个问题，显示摄像头时 竖屏 => 横屏 会调用系统的全屏摄像头
    // 导致 clientHeight 获取的是屏幕的高度（包括了上方导航栏）
    // 所以 有摄像头时 计算的横屏播放器尺寸 > 没有摄像头时计算出来的
    normal_horizontal(resolve) {
      let h = document.body.clientHeight
      let w = document.body.clientWidth
      // TODO 这里看看有没有办法禁止横屏时 摄像头自动全屏
      // 当切换横屏 摄像头自动全屏时 用户不退出全屏 会一直递归
      // PC 横屏调试没有工具栏 需要去除 h > window.screen.height 才能正确显示
      if (h > w || h >= window.screen.height) {
        setTimeout(() => {
          this.normal_horizontal(resolve)
        }, 500)
      } else {
        resolve({h, w})
      }
    },
    // ipad wechat 浏览器下横屏有两种情况 左边有聊天列表/左边没有聊天列表 (顶部都有工具栏)
    // 所以和window.screen.width比较来获取真实宽高
    ipad_wechat_vertical(resolve) {
      let h = document.body.clientHeight
      let w = document.body.clientWidth
      if (h < window.screen.width) {
        setTimeout(() => {
          this.ipad_wechat_vertical(resolve)
        }, 500)
      } else {
        resolve({h, w})
      }
    },
    ipad_wechat_horizontal(resolve) {
      let h = document.body.clientHeight
      let w = document.body.clientWidth
      if (h >= window.screen.width) {
        setTimeout(() => {
          this.ipad_wechat_horizontal(resolve)
        }, 500)
      } else {
        resolve({h, w})
      }
    }
  },
  init({ $vue }) {
    this.$vue = $vue
    this.$getters = $vue.$store.getters
    this.$commit = $vue.$store.commit
    this.initScreenStatus()
    this.initVerticalStatus()
    this.initHorizontalSize()
  },
  // 初始化屏幕状态
  initScreenStatus() {
    this.$commit('UPDATE_PAGE_INFO', {screenStatus: tools.isMobileStatus()})
  },
  // 初始化横屏尺寸
  initHorizontalSize() {
    // console.warn(tools.isMobileStatus())
    if (tools.isMobileStatus() === 'vertical') {
      return
    }
    this.getHorizontalSize()
      .then((size) => {
        this.setHorSize(size)
      })
  },
  // 获取横屏尺寸
  getHorizontalSize() {
    return new Promise((resolve, reject) => {
      let hander = 'normal_horizontal'
      if (tools.isIPad() && tools.isWechat()) {
        hander = 'ipad_wechat_horizontal'
      }
      this.sizeHander[hander](resolve)
      // resolve(hander)
    })
  },
  // 设置横屏时播放器尺寸
  setHorSize({w, h}) {
    let layoutMode = this.$getters.getLayoutMode
    let docSize
    // console.error('模式 => ', layoutMode)
    // 大屏
    if (layoutMode === 0) {
      // 播放器盒子的 h / w < this.MEDIA_RADIO => 用盒子的高作为基准计算播放器尺寸
      if ((h / w) < this.MEDIA_RADIO) {
        docSize = {
          width: h / this.MEDIA_RADIO,
          height: h
        }
      } else {
        docSize = {
          width: 100,
          height: 100
        }
      }
    }

    // 中小屏
    if (layoutMode === 1) {
      // 0.7 是横屏时云课堂播放器占屏幕的比例
      let playerBoxWidth = w * 0.7
      // 播放器盒子的 h / w < this.MEDIA_RADIO => 用盒子的高作为基准计算播放器尺寸
      if ((h / playerBoxWidth) < this.MEDIA_RADIO) {
        docSize = {
          width: h / this.MEDIA_RADIO,
          height: h
        }
      } else {
        docSize = {
          width: playerBoxWidth,
          height: playerBoxWidth * this.MEDIA_RADIO
        }
      }
    }
    let { ...sizeInited } = this.$getters.getSizeInited
    // console.warn('doc size ==>', docSize, sizeInited)
    sizeInited.horizontal = true
    this.$commit('UPDATE_PAGE_INFO', {sizeInited, horizontalSize: docSize })
  },
  // 初始化竖屏状态
  initVerticalStatus() {
    if (tools.isMobileStatus() !== 'vertical') {
      return
    }
    // 获取竖屏的width height
    // 设置竖屏时上方播放器的高度
    // 初始化上下播放器的size
    this.getVerticalSize()
      .then((size) => {
        this.initTopBoxHeight(size)
        return size
      })
      .then((size) => {
        this.setVerDocSize(size)
      })
  },
  // 获取竖屏尺寸
  getVerticalSize() {
    return new Promise((resolve, reject) => {
      let hander = 'normal_vertical'
      if (tools.isIPad() && tools.isWechat()) {
        hander = 'ipad_wechat_vertical'
      }
      this.sizeHander[hander](resolve)
    })
  },
  // 初始化顶部播放器盒子高度
  initTopBoxHeight(size) {
    let topBoxHeight = size.w * 0.75
    this.$commit('UPDATE_PAGE_INFO', { topPlayerBoxHeight: topBoxHeight })
  },
  // 设置竖屏文档高度
  setVerDocSize(size) {
    // console.warn(this)
    const VERTICAL_WIDTH = size.w
    const VERTICAL_HEIGHT = size.h
    const VIDEO_MODE = this.$getters.getVideoMode
    const TOP_PLAYER_BOX_HEIGHT = this.$getters.getTopBoxHeight
    let topPlayerSize
    let btmPlayerSize
    let docSize

    // 播放器盒子的 h / w < this.MEDIA_RADIO => 用盒子的高作为基准计算播放器尺寸
    if ((TOP_PLAYER_BOX_HEIGHT / VERTICAL_WIDTH) < this.MEDIA_RADIO) {
      topPlayerSize = {
        width: TOP_PLAYER_BOX_HEIGHT / this.MEDIA_RADIO,
        height: TOP_PLAYER_BOX_HEIGHT
      }
    } else {
      topPlayerSize = {
        width: VERTICAL_WIDTH,
        height: VERTICAL_WIDTH * this.MEDIA_RADIO
      }
    }

    // 计算下方播放器尺寸
    switch (VIDEO_MODE) {
      // 小屏
      case 0:
        btmPlayerSize = {
          width: VERTICAL_WIDTH * this.SMALL_SCREEN_SCALE,
          height: VERTICAL_WIDTH * this.SMALL_SCREEN_SCALE * this.MEDIA_RADIO
        }
        break
        // TODO (iphone 华为还要考虑底部虚拟菜单) 可能会有问题
        // 大屏 这里有些手机 底部height/width < 3 / 4
      case 2:
        let btmBoxHeight = VERTICAL_HEIGHT - TOP_PLAYER_BOX_HEIGHT - this.MENU_HEIGHT
        // 播放器盒子的 h / w < this.MEDIA_RADIO => 用盒子的高作为基准计算播放器尺寸
        if ((btmBoxHeight / VERTICAL_WIDTH) < this.MEDIA_RADIO) {
          btmPlayerSize = {
            width: btmBoxHeight / this.MEDIA_RADIO,
            height: btmBoxHeight
          }
        } else {
          btmPlayerSize = {
            width: VERTICAL_WIDTH,
            height: VERTICAL_WIDTH * this.MEDIA_RADIO
          }
        }
        break
      default:
        btmPlayerSize = {}
    }

    docSize = {
      topPlayerSize: topPlayerSize,
      btmPlayerSize: btmPlayerSize
    }
    let { ...sizeInited } = this.$getters.getSizeInited
    sizeInited.vertical = true
    this.$commit('UPDATE_PAGE_INFO', { sizeInited, ...docSize })
  },


}

export default initConfig
