/**
 * @author Marko.king
 * @直播模块
 * @模块初始化配置
 */
export default {
  // 模块设置
  initData: null,
  // 设置
  initSetting(initData, $vue) {
    this.initData = initData
    // 默认配置
    if (window.pageConfig) {
      // 直播
      if (window.isVod == 0) {
        initData.course = initData.course||{}
        // 配置为空或者开启本地配置，设置默认配置
        if ((!initData.course.pageConfig)||window.modeConfig) {
          initData.course.pageConfig = JSON.stringify(window.pageConfig)
        }
      } else {
        // 回放
        if (!initData.pageConfig||window.modeConfig) {
          initData.pageConfig = JSON.stringify(window.pageConfig)
        }
      }
    }
    $vue.$store.commit($vue.TYPES.UPDATE_HT_DATA, initData)
    // chat
    this.chat.setInitList.call($vue, initData)
    // robots
    this.member.setRobots.call($vue, initData)
    // 人气模式
    this.member.popularity.call($vue, initData)
    // notice
    this.notification.public.call($vue, initData)
    this.notification.roll.call($vue, initData)
    // 跑马灯
    this.marker.setMarker.call($vue, initData)
    // 商城
    $vue.$store.commit("SET_PRODUCT", this.store.getStore(initData) && this.store.getStore(initData).goods)
    // 点赞
    $vue.$store.commit("SET_LIKE", initData.likeTimes || 0)
  },
  // setter
  doInitSetter() {
    // 
  },
  store: {
    getStore(initData) {
      if (initData.course) {
        if (initData.course.pageConfig) {
          var config = JSON.parse(initData.course.pageConfig)
          return config
        } else {
          return null
        }
      } else if (initData.pageConfig) {
        var config = JSON.parse(initData.pageConfig)
        return config
      }
      else {
        return null
      }
    }
  },
  // 跑马灯
  marker: {
    setMarker(initData) {
      if (initData.modules && initData.modules.mod_theftproof_live && initData.modules.mod_theftproof_live.enable === '1') {
        let pageMode = this.$store.getters.getPageModel
        let warp = {
          0: '.view_container',
          1: 'body',
          2: '#ht_camera_container'
        }
        let timer = setTimeout(() => {
          if (document.querySelector(warp[pageMode]))
            this.HTSDK.plugins('marker').init(warp[pageMode])
            clearInterval(timer)
        }, 500)
      }
    }
  },
  // 聊天
  chat: {
    // 设置列表S
    setInitList(initData) {
      this.$store.dispatch(this.TYPES.CHAT_INIT_LIST, { chatList: (initData.room && initData.room.chatList) || [] })
    }
  },
  // 用户
  member: {
    setRobots(initData) {
      if (initData.room && initData.room.robotList) {
        this.$store.dispatch(this.TYPES.UPDATE_ROBOTS_TOTAL, { total: initData.room.robotList.total || 0 })
      }
    },
    popularity(initData) {
      if (window.isVod == 0 && initData.room.member && initData.room.member.total) {
        this.$store.commit(this.TYPES.UPDATE_MEMBER_TOTAL, Number(initData.room.member.total))
      }
    }
  },
  // 通知 & 公告
  notification: {
    roll(initData) {
      this.$store.commit(this.TYPES.UPDATE_SCROLL_NOTICE, (initData && initData.announce && initData.announce.roll) || null)
    },
    public(initData) {
      this.$store.commit(this.TYPES.UPDATE_PUBLIC_NOTICE, (initData && initData.announce && initData.announce.notice) || null)
    }
  },
  // 获取模块
  getModuleByName(modName) {
    if (this.modSettings[modName]) {
      return this.modSettings[modName]
    } else {
      // 模块不存在
      // todo...
    }
  },
  // 全部模块
  getModules() {
    return this.modSettings
  }
}