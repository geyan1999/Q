export default {
  // 聊天
  chatSend(SDK, msg, callback) {
    SDK.emit("chat:send", { msg: msg }, (res) => {
      callback && callback(res)
    })
  },
  // 私聊 
  privateChat(SDK, msg, xid, callback) {
    SDK.emit("chat:private", { msg: msg, xid: xid }, (res) => {
      callback && callback(res)
    })
  },
  // 用户列表
  getOnline(SDK,config,callback){
    SDK.emit("member:list", config, (res) => {
      callback && callback(res)
    })
  }
}