import { isMobileStatus } from './util'
import initConfig from './init.config'
export default function pageEventInit({ $vue, sdk }) {
  let $commit = $vue.$store.commit
  let $getters = $vue.$store.getters
  let pid = function () {
    if (window.isVod == 1) {
      if ($getters.getHtData && $getters.getHtData.pid) {
        return $getters.getHtData.pid
      }
    } else {
      if ($getters.getHtData && $getters.getHtData.zhubo && $getters.getHtData.zhubo.partner_id) {
        return $getters.getHtData.zhubo.partner_id
      }
    }
    return false
  }
  // 转屏
  window.addEventListener('orientationchange', () => {
    if (!$getters.getHorSizeIsInited) {
      initConfig.initHorizontalSize()
    }

    if (!$getters.getVerSizeIsInited) {
      initConfig.initVerticalStatus()
    }
    // page 信息更新
    $commit('UPDATE_PAGE_INFO', { screenStatus: isMobileStatus() })
    setTimeout(() => {
      // sdk.play()
    }, 200)
  })

  if (pid() == 13067) {
    if ((/VideoGo\/Android/).test(navigator.appVersion)) {
      window.addEventListener("resize", function () {
        if (document.activeElement.tagName == "INPUT" ||
          document.activeElement.tagName == "TEXTAREA") {
          window.setTimeout(function () {
            document.activeElement.scrollIntoViewIfNeeded();
          }, 0);
        }
      })
    }
  }
}
