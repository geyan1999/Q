/**
 * 直播页事件名称
 * 可能存在遗漏的事件，发现及时补上
 * 具体参数查看文档 http://open.talk-fun.com/docs/js/sdk.js.getstart.html
 */

const EVENTS = {
  AlERT: 'alert', // 窗口提示
  CAMERA: {
    START: 'camera:start', // 摄像头打开
    STOP: 'camera:stop', // 摄像头关闭
  },
  CONNECT: 'connect', // 连接完成
  CONNECT_FAILED: 'connect_failed', // 连接失败
  CONNECT_ERROR: 'connect_error', // 连接出现错误
  DISCONNECT: 'disconnect', // 连接已断开
  RECONNECT: 'reconnect', // 重新连接
  RECONNECTING: 'reconnecting', // 重新连接中
  RECONNECT_ERROR: 'reconnect_error', // 重新连接错误
  RECONNECT_FAILED: 'reconnect_failed', // 重新连接失败
  // 聊天
  CHAT: {
    SEND: 'chat:send', // 发送/接收文本信息
    SCREEN: {
      CLEAR: 'chat:screen:clear' // 文字聊天区域全局清屏
    },
    GROUP: {
      CREATE: 'chat:group:create', // 创建一个群组
      SEND: 'chat:group:send', // 发送/接受一个群组消息
      REMOVE: 'chat:group:remove', // 销毁一个群组
    },
    PRIVATE: 'chat:private', //发起/接收私聊
    DISABLE:'chat:disable', //禁止发言
    ENABLE: 'chat:enable' //解除禁言
  },
  // 红包
  REWARD:{
    SEND:'hongbao:send', //收到红包消息
    GET:'hongbao:received',//红包被领取
    END:'hongbao:received:done',//红包被领取完
    success:'hongbao:send:success'//发送红包成功
  },
  // 通知
  NOTICE: {
    PUBLIC: 'announce:notice',
    SCROLL: 'announce:roll'
  },
  ERROR: 'error', // 错误提示
  // 直播
  LIVE: {
    CAMERA: {
      PLAY: 'camera:play', // 摄像头是否播放
    },
    MODE_CHANGE: 'live:mode:change', //模式切换
    COURSE: 'live:course', // 课程相关
    COURSE_ERROR: 'live:course:access:error', // 课程验证失败
    // COURSE: {
    //   ACCESS: {
    //     ERROR: 'live:course:access:error', // 课程验证失败
    //   }
    // },
    ROBOTS: {
      USERS: 'live:robots:users' // 初始化返回虚拟用户(只执行一次)
    },
    SET: {
      PAGE: 'live:set:page', // 切换页码
    },
    START: 'live:start', // 开始直播
    STOP: 'live:stop', // 直播结束
    WAIT: 'live:wait', // 直播未开始,
    UPDATA: 'live:data:update' ,// 直播数据更新
    UPDATE_WB : 'video:whiteboard'
  },
  // 点赞
  LIKE:{
    TOTAL:'like:put'
  },
  // 摇奖
  LOTTERY: {
    START: 'lottery:start', // 摇奖开始
    STOP: 'lottery:stop', // 摇奖结束
  },
  // 用户
  MEMBER: {
    KICK: 'member:kick', // 将用户踢出房间
    JOIN: {
      ME: 'member:join:me', // 用户进入房间，自己会收到的消息
      OTHER: 'member:join:other', // 他人进入房间，用户会收到的消息
    },
    ROBOTS: 'member:robots', // 以广播形式返回虚拟用户
    TOTAL: 'member:total', // 在线人数
    LEAVE: 'member:leave', // 用户离开房间
    FORCEOUT: 'member:forceout', // 用户被强制离开房间，有相同的账号进入
    LIST: 'member:list', // 用户列表
    KICK: 'member:kick', // 用户被踢出房间,
    FORBIDDEN: 'member:forbidden', // 用户被禁止进入房间
  },
  // 网络
  NETWORK: {
    STATUS: 'network:status' // 监听当前用户网络状态
  },
  // 问答
  QUESTION: {
    APPLY: 'question:audit', //通过
    ERROR: 'live:question:error', //错误
    ASK: 'question:ask', // 发问
    REPLY: 'question:reply', // 回复提问
    DELETE: 'question:delete', // 删除提问
  },
  // 房间
  ROOM: {
    INIT: 'room:init', // 房间初始化
  },
  // 系统
  SYSTEM: {
    ROOM: {
      ERROR: 'system:room:error', // 系统 & 网络错误 callback => res.code
    }
  },
  // 语音
  VOICE: {
    BUTTON: {
      CHANGE: 'voice:button:change', // 设置他人说话的方式
    },
    MODE: {
      CHANGE: 'voice:mode:change', // 改变语音模式
    },
    POWER: {
      ALLOW: 'voice:power:allow', // 恢复当前模式下的默认权限
      FORBID: 'voice:power:forbid' // 禁止某人说话
    },
    QUEUE: {
      CLEAR: 'voice:queue:clear', // 清空麦序列表
      CONNECT: {
        APPLY: 'voice:connect:apply', // 邀请连麦
        CANCEL: 'voice:connect:cancel', // 取消连麦
        OPERATE: 'voice:connect:operate', // 针对邀请连麦的操作
      },
      CONTROL: 'voice:queue:control', // 控制麦序状态
      HAND: {
        ALLOW: 'voice:hand:allow', // 举手允许发言
        CLEAR: 'voice:hand:clear', // 清空举手列表
        FORBID: 'voice:hand:forbid', // 举手关闭发言
        LEAVE: 'voice:hand:leave', // 用户退出举手列表
        UP: 'voice:hand:up', // 麦序举手
        REMOVE: 'voice:hand:remove', // 从举手列表中移除
      },
      MOVE: 'voice:queue:move', // 移动麦序位置
      MOVETO: 'voice:queue:moveto', // 移动到麦序第二位
      TIME: 'voice:queue:time', // 设置麦序的时间
    }
  },
  // 投票
  VOTE: {
    NEW: 'vote:new', // 发起投票的广播
    PUB: 'vote:pub', // 公布投票结果
  },
  // 签到
  SIGN:{
    NEW:'sign:new',
    END:'sign:end'
  }
}

export default EVENTS
