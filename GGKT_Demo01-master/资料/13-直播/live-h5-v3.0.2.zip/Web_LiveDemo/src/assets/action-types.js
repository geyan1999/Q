/**
 * KEY FOR VUEX
 */
// 全局
export const UPDATE_TEST = 'UPDATE_TEST'
export const UPDATE_HT_DATA = 'UPDATE_HT_DATA'
export const UPDATE_LIVEID = 'UPDATE_LIVEID'
export const UPDATE_WHITEBOARD = 'UPDATE_WHITEBOARD'
// 问答相关
export const UPDATE_QUESTION_LIST = 'UPDATE_QUESTION_LIST' // 更新问答列表
export const UPDATE_QUESTION_TIP = 'UPDATE_QUESTION_TIP' 

// 聊天信息
export const CHAT_UPDATE_LIST = 'CHAT_UPDATE_LIST'
export const CHAT_INIT_LIST = 'CHAT_INIT_LIST'
export const CHAT_SET_LIST = 'CHAT_SET_LIST'
export const CHAT_SET_LOCK = 'CHAT_SET_LOCK'

// 直播
export const UPDATE_WATER_MARKER = 'UPDATE_WATER_MARKER'
export const UPDATE_LIVE_STATE = 'UPDATE_LIVE_STATE'
export const UPDATE_MODE_CHANGE = 'UPDATE_MODE_CHANGE'
export const UPDATE_LIVE_VOD = 'UPDATE_LIVE_VOD'

// 更新页面信息
export const UPDATE_PAGE_INFO = 'UPDATE_PAGE_INFO'

// 更新选项卡
export const UPDATE_PAGE_TAB = 'UPDATE_PAGE_TAB'

// 更新视频切换
export const UPDATE_VIEWO_MODE = 'UPDATE_VIEWO_MODE'

// 更新侧边栏模块
export const UPDATE_SIDE_MODE = 'UPDATE_SIDE_MODE'
 
// 更新总人数
export const UPDATE_MEMBER_TOTAL = 'UPDATE_MEMBER_TOTAL'
export const UPDATE_ROBOTS_TOTAL = 'UPDATE_ROBOTS_TOTAL'

// 投票
export const UPDATE_VOTE_STATUS = 'UPDATE_VOTE_STATUS'
export const UPDATE_NEW_VOTE = 'UPDATE_NEW_VOTE'
export const UPDATE_VOTE_RESULT = 'UPDATE_VOTE_RESULT'
export const UPDATE_VOTE_POP_STATUS = 'UPDATE_VOTE_POP_STATUS'

// 更新播放器状态
export const UPDATE_VIDEO_STATUS = 'UPDATE_VIDEO_STATUS'

// 抽奖
export const UPDATE_LOTTERY_STATUS = 'UPDATE_LOTTERY_STATUS'

// 邀请排行榜
export const UPDATE_RANK_LIST = 'UPDATE_RANK_LIST'
export const GET_RANK_LIST = 'GET_RANK_LIST'

// 通知
export const UPDATE_PUBLIC_NOTICE = 'UPDATE_PUBLIC_NOTICE'
export const UPDATE_SCROLL_NOTICE = 'UPDATE_SCROLL_NOTICE'

// 进入直播
export const UPDATE_CHAT_INTOROOM = 'UPDATE_CHAT_INTOROOM'

// 购买消息
export const UPDATE_SHOP = 'UPDATE_SHOP'

// 更新课程状态
export const UPDATE_COURSEStAtUS = 'UPDATE_COURSEStAtUS'

// 红包相关
export const SEND_REWARD = 'SEND_REWARD'
export const GER_REWARD = 'GER_REWARD'
export const CHECK_REWARD = 'CHECK_REWARD'
export const VIEW_REWARD = 'VIEW_REWARD'
export const LIST_REWARD = 'LIST_REWARD'
export const INDEX_CASH_REWARD = 'INDEX_CASH_REWARD'
export const CASH_REWARD = 'CASH_REWARD'
export const DETAIL_REWARD = 'DETAIL_REWARD'
export const UPDATE_REWARD_STATUS= 'UPDATE_REWARD_STATUS'
export const UPDATE_REWARD_SEND = 'UPDATE_REWARD_SEND'
export const UPDATE_REWARD_GET = 'UPDATE_REWARD_GET'
export const UPDATE_REWARD_OPEN = 'UPDATE_REWARD_OPEN'
export const UPDATE_REWARD_LIST = 'UPDATE_REWARD_LIST'
export const UPDATE_REWARD_TIMER = 'UPDATE_REWARD_TIMER'
export const UPDATE_REWARD_CASH = 'UPDATE_REWARD_CASH'
export const UPDATE_REWARD_DETAIL = 'UPDATE_REWARD_DETAIL'

// 回放相关
export const DURATION_DATA = 'DURATION_DATA' // 时间点数据
export const UPDATE_HTSDK = 'UPDATE_HTSDK' //HTSDK更新
export const UPDATE_ROOM_MODE = 'UPDATE_ROOM_MODE' //HTSDK更新

// 商品相关
export const UPDATE_PRODUCT = 'UPDATE_PRODUCT'
export const SET_PRODUCT = 'SET_PRODUCT'
export const UPDATE_ADD_PRODUCT = 'UPDATE_ADD_PRODUCT'
export const UPDATE_CANCEL_PRODUCT = 'UPDATE_CANCEL_PRODUCT'

// 优惠劵相关
export const UPDATE_POP_CARD = 'UPDATE_POP_CARD'

// 更新播放线路
export const UPDATE_LIVE_LINE = 'UPDATE_LIVE_LINE'

// 主播打赏
export const POST_REWARD = 'POST_REWARD'
export const UPDATE_REWARD = 'UPDATE_REWARD'
export const UPDATE_REWARD_MSG = 'UPDATE_REWARD_MSG'

// 工具栏
export const UPDATE_TOOLS_MODE = 'UPDATE_TOOLS_MODE'

// 点赞
export const SET_LIKE = 'SET_LIKE'
export const UPDATA_LIKE = 'UPDATA_LIKE'
export const UPDATA_LIKE_TIME = 'UPDATA_LIKE_TIME'
export const POST_LIKE = 'POST_LIKE'

// 签到
export const UPDATA_SIGN_STATUS = 'UPDATA_SIGN_STATUS'
export const UPDATA_NEW_SIGN = 'UPDATA_NEW_SIGN'
export const POST_SIGN = 'POST_SIGN'