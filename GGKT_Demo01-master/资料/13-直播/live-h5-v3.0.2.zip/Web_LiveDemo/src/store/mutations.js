import * as TYPES from '../assets/action-types'
export default {
  // update test
  [TYPES.UPDATE_TEST](state, data) {
    state.global = data
  },
  [TYPES.UPDATE_HT_DATA](state, data) {
    state.htData = data
  },
  [TYPES.UPDATE_LIVEID](state, data) {
    if (!state.htData.live) {
      state.htData.live = { liveid: data }
    }
  },
  // 模式切换
  [TYPES.UPDATE_MODE_CHANGE](state, mode) {
    // console.log(mode)
    state.liveCurMode = Number(mode)
  },
  // 只传要更新的字段
  [TYPES.UPDATE_PAGE_INFO](state, data) {
    let { ...pageInfo } = state.pageInfo
    let keys = Object.keys(data)
    for (let i = 0; i < keys.length; i++) {
      let key = keys[i]
      pageInfo[key] = data[key]
    }
    // console.warn('pageinfo===>', pageInfo)
    state.pageInfo = pageInfo
  },
  // 公告消息
  [TYPES.UPDATE_PUBLIC_NOTICE](state, notification) {
    state.notifications.publicNotice = notification
  },
  // 滚动消息
  [TYPES.UPDATE_SCROLL_NOTICE](state, rollNotice) {
    state.notifications.scrollNotice = rollNotice
  },
  // 视频切换
  [TYPES.UPDATE_VIEWO_MODE](state, mode) {
    state.VideoCurMode = mode
  },
  [TYPES.UPDATE_COURSEStAtUS](state, course) {
    state.courseStatus = course
  },
  [TYPES.UPDATE_PAGE_TAB](state, tab) {
    state.actModule = tab
  },
  // 保存上架商品
  [TYPES.SET_PRODUCT](state, product) {
    state.productIdList = product
  },
  // 更新上架商品
  [TYPES.UPDATE_PRODUCT](state, list) {
    state.productIdList = list
  },
  // 更新推荐商品
  [TYPES.UPDATE_ADD_PRODUCT](state, list) {
    state.addProductList = list
  },
  // 更新取消推荐商品
  [TYPES.UPDATE_CANCEL_PRODUCT](state, list) {
    state.cancelProductList = list
  },
  // 更新推送优惠劵
  [TYPES.UPDATE_POP_CARD](state, card) {
    state.popCard = card
  },
  // 初始化点赞数
  [TYPES.SET_LIKE](state, like) {
    state.likeCount = like
  },
  //  更新点赞数
  [TYPES.UPDATA_LIKE](state, like) {
    state.likeCount = like
  },
  // 更新点赞刷新时间
  [TYPES.UPDATA_LIKE_TIME](state, time) {
    if (state.likeIntervalTimer) {
      clearTimeout(state.likeIntervalTimer)
      state.likeIntervalTimer = null
    } else {
      state.likeIntervalTimer = setTimeout(() => {
        state.likeIntervalTime = new Date().getTime() - state.likeIntervalTime
        clearTimeout(state.likeIntervalTimer)
        state.likeIntervalTimer = null
      }, 60 * 1000)
    }
    state.likeIntervalTime = state.likeIntervalTime == 0 ? time : time - state.likeIntervalTime
  }
}
