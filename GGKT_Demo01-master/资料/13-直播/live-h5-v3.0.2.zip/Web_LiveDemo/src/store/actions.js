import * as TYPES from '@/assets/action-types'
import axios from 'axios'
export default {
  // update test
  [TYPES.UPDATE_TEST] (store, data) {
    store.commit(TYPES.UPDATE_TEST, data)
  },
  // [TYPES.MENU_INDEX] (store, data) {
  //   store.commit(TYPES.MENU_INDEX, data)
  // }
  // 滚动消息
  [TYPES.UPDATE_SCROLL_NOTICE] (store, data) {
    // state.notifications.scrollNotice = rollNotice
    store.commit(TYPES.UPDATE_SCROLL_NOTICE, data)
  },
  [TYPES.POST_LIKE]({commit},data){
    axios.get('//open.talk-fun.com/live/like.php?act=click',{
      params:{
        times:data.times,
        access_token:data.access_token
      }
    }).then((res)=>{
      if(res.data.code==0){
        commit(TYPES.UPDATA_LIKE,res.data.data.times)
      }
    })
  }
}
