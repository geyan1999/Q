export default {
  global: 'Welcome To TalkFun Live Room!',
  htData: {live:false},
  // 用户配置: 用户`直播间设置`提交的配置，从后台获取数据设置好后，只可以读取，不可以因为操作页面修改
  userConfig: {
    // 视频的模式 
    // 0 => 小屏 
    // 1 => 中屏 
    // 2 => 大屏
    // 3 => 全屏
    videoMode: 3,
    // 直播布局模式
    /**
     * 0 => 教育场景
     * 1 => 金融场景
     * 2 => 电商场景
     * 4 => 大会场景
     */
    layoutMode: 2,
  },
  // 模式切换 [0 => 教育场景, 2 => 视频分享]
  liveCurMode: 0,
  // 消息通知
  notifications: {
    scrollNotice: null,
    publicNotice: null
  },
  likeCount:0,// 点赞数
  likeIntervalTime:0,//点赞更新时间间隔
  likeIntervalTimer:null,//点赞更新时间刷新
  // 页面信息
  pageInfo: {
    actModule: '', // 当前激活的模块
    // 播放器的状态 open => 开启 close => 未开启
    playerStatus: {
      course: 'close', // 画板、PPT、视频
      camera: 'close' // 摄像头
    },
    // 顶部播放器盒子的高度 期望是40%
    topPlayerBoxHeight: 290,
    // 当前在上面位置的播放器 course => PPT / camera => 摄像头
    topPlayer: 'course',
    btmPlayer: 'camera',
    topPlayerSize: {
      width: '100%',
      height: 'auto'
    },
    btmPlayerSize: {
      width: '100%',
      height: 'auto'
    },
    horizontalSize: {
      width: '100%',
      height: '100%'
    },
    // 屏幕状态 horizontal => 横屏 vertical => 竖屏
    screenStatus: 'horizontal',
    // 播放器size初始化完成
    sizeInited: {
      vertical: false,
      horizontal: false
    }
  },
  actModule:'',
  // 视频切换 [0 => 正在播放, 1 => 切换模块]
  VideoCurMode:0,
  // 课程状态
  courseStatus:true,
  // 商品
  productIdList:[],
  // 新增/推荐 商品
  addProductList:[],
  // 取消推荐商品
  cancelProductList:[],
  // 推荐优惠劵
  popCard:{}
}
