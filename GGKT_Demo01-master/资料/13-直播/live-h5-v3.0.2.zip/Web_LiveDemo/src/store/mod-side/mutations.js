import * as TYPES from '@/assets/action-types'
export default {
  // 更新侧边栏模块
  [TYPES.UPDATE_SIDE_MODE] (state, type) {
    state.sideMode = type
  },

}