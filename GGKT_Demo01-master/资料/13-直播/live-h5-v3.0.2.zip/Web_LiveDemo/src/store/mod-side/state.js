export default {
  sideMode: 0, // 默认0  1 关注二维码  2 分享卡
}