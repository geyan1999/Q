export default {
  getSideMode(state){
    return state.sideMode
  }
}