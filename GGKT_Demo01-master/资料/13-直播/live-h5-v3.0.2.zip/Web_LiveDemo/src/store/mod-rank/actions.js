import * as TYPES from '@/assets/action-types'
const baseUrl = '//' + (window.apiHost || '//open.talk-fun.com')
export default {
  // update rank state
  [TYPES.GET_RANK_LIST]({ commit },{ vm , data }) {
    vm.$http.get( baseUrl + '/live/invite.php', {
      params:{
        access_token: data.access_token,
        act: data.rank,
        page: data.page
     }
    }).then(function (res) {
      commit("UPDATE_REWARD_DEBUG",{req:data,res:res.data})
      if(res.data.code==0){
        commit(TYPES.UPDATE_RANK_LIST,{
          data: res.data.data,
          total: res.data.total? Math.ceil(res.data.total/10) : 1,
          page: data.page
        })
      }else{
        vm.$vux.loading.hide()
        vm.$vux.alert.show({
          title: '错误提示',
          content: res.data.msg
        })
      }
    })
    .catch(function(err){
      // console.log(err)
      vm.$vux.alert.show({
        title: '错误提示',
        content: '网络请求错误'
      })
    })
    .finally(function(){
      vm.$vux.loading.hide()
    })
  },
}