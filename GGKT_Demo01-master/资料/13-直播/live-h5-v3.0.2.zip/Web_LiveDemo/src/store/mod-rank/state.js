export default {
  listRank:{
    data:[],
    total:null,
    page:1
  },
}