import * as TYPES from '@/assets/action-types'
export default {
  // 更新邀请排行榜
  [TYPES.UPDATE_RANK_LIST] (state, resdata) {
    state.listRank.page = resdata.page
        if(resdata.data&&state.listRank.page!==1){
          resdata.data.forEach(element => {
                state.listRank.data.push(element)
            });
        }
        if(resdata.data&&state.listRank.page==1){
            state.listRank.data = resdata.data
        }
        if(resdata.total !== undefined){
            state.listRank.total = resdata.total
        }
  },

}