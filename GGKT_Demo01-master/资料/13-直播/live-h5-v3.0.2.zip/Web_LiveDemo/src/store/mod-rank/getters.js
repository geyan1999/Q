export default {
  getRankList(state){
    return state.listRank
  }
}