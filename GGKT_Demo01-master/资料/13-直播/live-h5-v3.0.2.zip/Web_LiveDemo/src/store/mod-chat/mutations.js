import * as TYPES from '@/assets/action-types'
import Vue from 'vue'
export default {
  // 更新
  [TYPES.CHAT_UPDATE_LIST](state, chaObject) {
    if (state.chat.list.length >= state.chat.maxLength) {
      state.chat.list.shift()
    }
    state.chat.list.push(chaObject)
  },
  // 初始化
  [TYPES.CHAT_INIT_LIST](state, chatList) {
    state.chat.list = state.chat.list.concat(chatList)
  },
  [TYPES.UPDATE_CHAT_INTOROOM](state, room) {
    state.chat.intoRoom = room
  },
  // 设置
  [TYPES.CHAT_SET_LIST](state, chatList) {
    state.chat.list = chatList
  },
  [TYPES.UPDATE_SHOP](state, shop) {
    state.chat.shoping = shop
  },
  [TYPES.CHAT_SET_LOCK](state,lock){
    state.chat.chatLock = lock
  }
}
