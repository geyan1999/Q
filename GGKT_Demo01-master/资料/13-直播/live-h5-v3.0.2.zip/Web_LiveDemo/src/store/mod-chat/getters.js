export default {
  getChatList (state) {
    return state.chat.list
  },
  getintoRoom(state){
    return state.chat.intoRoom
  },
  getShoping(state){
    return state.chat.shoping
  },
  getChatLock(state){
    return state.chat.chatLock
  }
}