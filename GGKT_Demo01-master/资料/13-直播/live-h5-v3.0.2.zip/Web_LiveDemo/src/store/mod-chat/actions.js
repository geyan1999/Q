import * as TYPES from '@/assets/action-types'
export default {
  [TYPES.CHAT_UPDATE_LIST] ({ commit }, { chatObject }) {
    commit(TYPES.CHAT_UPDATE_LIST, chatObject)
  },
  // 列表
  [TYPES.CHAT_INIT_LIST] ({ commit }, { chatList }) {
    commit(TYPES.CHAT_INIT_LIST, chatList)
  }
}
