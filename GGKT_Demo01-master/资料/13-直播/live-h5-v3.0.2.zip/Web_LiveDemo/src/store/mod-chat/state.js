export default {
  chat: {
    list: [],
    setting: {},
    maxLength: 50,
    intoRoom: null,
    shoping: null,
    chatLock: false
  }
}