// import state from './state'
// import mutations from './mutations'
// import actions from './actions'
// import getters from './getters'
/**
 * 私聊数据管理
 * ==> 在20条内的数据, 建议采取单文件模块结构
 * ==> >20 条采用多文件拼装结构
 */
import Vue from 'vue'
// state
const state = {
  maxSize: 1500,
  pvChatList: {},
  pvUserlist: [],
  activeUser: null,
  curtip:0
}
// mutations[update命名]
const mutations = {
  // 更新客服列表
  updatePvUserlist(state, payload) {
    state.pvUserlist = payload
  },
  // 更新当前聊天客服
  updateactiveUser(state, payload) {
    state.activeUser = payload
  },
  // 更新聊天消息
  updatePvChatList(state, payload) {
    if (state.pvChatList[payload.xid]) {
      state.pvChatList[payload.xid].push(payload)
    } else {
      let arr = []
      arr.push(payload)
      Vue.set(state.pvChatList, payload.xid, arr)
    }
  },
  // 更新消息提示,非当前对话
  updateChatTip(state, payload) {
    let arr = []
    state.pvUserlist.forEach(user => {
      if (user.xid === payload.xid && (state.activeUser && (state.activeUser.xid !== payload.xid))) {
        user.tip += 1
      }else{
        user.tip = 0
        state.curtip = true
      }
      arr.push(user)
    });
    state.pvUserlist = arr
  },
  // 更新消息提示,当前对话
  updateCurTip(state,payload){
    if(payload){
      state.curtip+= 1
    }else{
      state.curtip = 0
    }
  }
}
// actions[set命名]
const actions = {
  // 初始化客服列表
  setPvUserlist({ state, commit }, payload) {
    if (!state.activeUser) {
      // 初始化当前聊天客服
      state.activeUser = payload[0] ? payload[0] : null
    }
    if (state.pvUserlist.length === 0) {
      payload.forEach(user => {
        user.tip = 0
      })
      commit("updatePvUserlist", payload)
    }
  },
  // 客服进入
  setIntoUser({ state, commit }, payload) {
    //  console.error(payload)
    // 判断客服是否存在
    if (!state.pvUserlist.some(user => {
      return user && user.xid === payload.xid
    })) {
      state.pvUserlist.push(payload)
    }
    // 当前是否有客服
    if(!state.activeUser){
      payload.tip = 0
      state.activeUser = payload
    }
  }
}

// getters[get命名]
const getters = {
  getPvChatList: state => state.pvChatList,
  getActiveUser: state => state.activeUser,
  getpvUserlist: state => state.pvUserlist,
  getCurTip:state => state.curtip
}

export default {
  state: state,
  mutations: mutations,
  actions: actions,
  getters: getters
}
