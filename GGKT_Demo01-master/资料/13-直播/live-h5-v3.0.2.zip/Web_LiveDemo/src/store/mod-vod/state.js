export default {
  vod:{
    currentTime:null,
    duration:null,
    currentPercent:null
  },
  playStatus:'pause',
  video:null
}