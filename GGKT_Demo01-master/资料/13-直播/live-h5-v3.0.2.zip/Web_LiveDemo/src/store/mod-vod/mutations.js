import * as TYPES from '@/assets/action-types'
export default {
  [TYPES.DURATION_DATA] (state, payload) {
    state.durationData = payload
  },
  [TYPES.UPDATE_HTSDK] (state, payload) {
    state.HTSDK = payload
  },
  [TYPES.UPDATE_ROOM_MODE] (state, payload) {
    state.roomModeData = payload
  },
  //回放状态
  [TYPES.UPDATE_LIVE_VOD] (state, payload) {
    if(typeof payload === "number"){
      state.currentTime = payload
    }else{
      state.vod = payload
    }
  },
  // 是否播放中
  changePlayStatus(state,payload){
    state.playStatus = payload
  },
  setVodPlayVideo(state,_video){
    state.video = _video
  }

}