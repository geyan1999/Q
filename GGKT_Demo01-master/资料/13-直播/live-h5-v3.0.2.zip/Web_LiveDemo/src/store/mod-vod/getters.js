export default {
  getPcVod (state) {
    return state.vod
  },
  getPlayStatus(state){
    return state.playStatus
  },
  getVodPlayVideo(state){
    return state.video
  }
}