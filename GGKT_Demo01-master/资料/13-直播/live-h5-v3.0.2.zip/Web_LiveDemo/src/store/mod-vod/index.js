/***
 * ## 回放 ##
 */
import states from './state'
import mutations from './mutations'
import getters from './getters'
export default {
  state: states,
  mutations: mutations,
  getters: getters
}