import * as TYPES from '@/assets/action-types'
export default {
  [TYPES.UPDATE_NEW_VOTE](state, data) {
    state.newVote = data
  },

  [TYPES.UPDATE_VOTE_POP_STATUS](state, status) {
    state.popStatus = status
  },

  [TYPES.UPDATE_VOTE_STATUS](state, status) {
    state.status = status
  },

  [TYPES.UPDATE_VOTE_RESULT](state, data) {
    state.voteResult = data
  }
}
