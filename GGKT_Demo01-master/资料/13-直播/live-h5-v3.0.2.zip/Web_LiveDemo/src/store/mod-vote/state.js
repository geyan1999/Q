export default {
  popStatus: 'close',
  status: 'start', // 投票状态 start => 发起投票 end => 投票结束
  // 新投票
  newVote: {
    info: {},
    opList: [],
    optional: 1,
    vid: ''
  },
  // 投票结果
  voteResult: {
    info: {},
    statsList: []
  }
}
