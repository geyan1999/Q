export default {
  getNewVote(state) {
    return state.newVote
  },
  getVotePopStatus(state) {
    return state.popStatus
  },
  getVoteStatus(state) {
    return state.status
  },
  getVoteResult(state) {
    return state.voteResult
  }
}
