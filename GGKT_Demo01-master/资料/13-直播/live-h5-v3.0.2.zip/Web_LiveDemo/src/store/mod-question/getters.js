export default {
  getQuesList (state) {
    return state.questionList
  },
  getQuesTip(state){
    return state.curtip
  }
}
