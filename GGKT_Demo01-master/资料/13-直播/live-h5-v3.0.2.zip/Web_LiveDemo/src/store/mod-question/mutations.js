import * as TYPES from '@/assets/action-types'
import Vue from 'vue'
export default {
  [TYPES.UPDATE_QUESTION_LIST](state, { type, data }) {
    let [ ...quesList ] = state.questionList
    // 提问
    if (type === 'question') {
      let d = {
        avatar: data.avatar,
        nickname: data.nickname,
        time: data.time,
        content: data.content,
        role: data.role,
        uid: data.uid,
        xid: data.xid,
        qid: data.qid,
        answers: [],
        originData: data
      }
      state.questionList[data.qid] = d
      state.questionList = Object.assign({}, state.questionList, state.questionList)
    }
    // 列表
    if (type === 'list') {
      Object.keys(data).forEach((qid) => {
          let qData = data[qid]
          let _d = {
            avatar: qData.avatar,
            nickname: qData.nickname,
            time: qData.time,
            content: qData.content,
            role: qData.role,
            uid: qData.uid,
            xid: qData.xid,
            qid: qData.qid,
            answers: qData.answer || [],
            originData: qData
          }
          state.questionList[qData.qid] = _d
      })
      state.questionList = Object.assign({}, state.questionList, state.questionList)
    }
    // 回复
    if (type === 'teacher_reply') {
      if (state.questionList[data.replyId]) {
        state.questionList[data.replyId].answers.push(data)
      }
    }
    // 删除
    if (type === 'delete') {
      if (state.questionList[data.qid]) {
        Vue.delete(state.questionList, data.qid)
      }
    }
  },
  [TYPES.UPDATE_QUESTION_TIP](state,payload){
    if(payload){
      state.curtip+= 1
    }else{
      state.curtip = 0
    }
  }
}
