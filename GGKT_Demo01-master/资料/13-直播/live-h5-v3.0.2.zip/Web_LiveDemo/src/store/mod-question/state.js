export default {
  questionList: {},
  curtip:0
}
