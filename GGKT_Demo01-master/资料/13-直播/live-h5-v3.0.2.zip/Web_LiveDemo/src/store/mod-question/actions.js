import * as TYPES from '@/assets/action-types'
export default {
  [TYPES.UPDATE_QUESTION_LIST] ({ commit }, data) {
    // console.error(commit, data)
    commit(TYPES.UPDATE_QUESTION_LIST, {type: data.type, data: data.data})
  }
}
