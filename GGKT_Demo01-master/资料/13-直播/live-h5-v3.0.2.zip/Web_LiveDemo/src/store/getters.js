export default {
  getGlobal(state) {
    return state.global
  },
  getHtData(state) {
    return state.htData
  },
  liveCurMode(state) {
    return state.liveCurMode
  },
  getUserConfig(state) {
    return state.userConfig
  },
  getPageInfo(state) {
    return state.pageInfo
  },
  getVideoMode(state) {
    return state.userConfig.videoMode
  },
  getActModule(state) {
    return state.actModule
  },
  getTopPlayerSize(state) {
    return state.pageInfo.topPlayerSize
  },
  getBtmPlayerSize(state) {
    return state.pageInfo.btmPlayerSize
  },
  getHorizontalSize(state) {
    return state.pageInfo.horizontalSize
  },
  getTopPlayer(state) {
    return state.pageInfo.topPlayer
  },
  getBtmPlayer(state) {
    return state.pageInfo.btmPlayer
  },
  getScreenStatus(state) {
    return state.pageInfo.screenStatus
  },
  getLayoutMode(state) {
    return state.userConfig.layoutMode
  },
  getPlayerStatus(state) {
    return state.pageInfo.playerStatus
  },
  getCameraStatus(state) {
    return state.pageInfo.playerStatus.camera
  },
  getTopBoxHeight(state) {
    return state.pageInfo.topPlayerBoxHeight
  },
  getSizeInited(state) {
    return state.pageInfo.sizeInited
  },
  getVerSizeIsInited(state) {
    return state.pageInfo.sizeInited.vertical
  },
  getHorSizeIsInited(state) {
    return state.pageInfo.sizeInited.horizontal
  },
  getPublicNotice(state) {
    return state.notifications.publicNotice
  },
  getRollNotice(state) {
    return state.notifications.scrollNotice
  },
  getTabInfo(state) {
    if (state.htData.course) {
      if (state.htData.course.pageConfig) {
        var tabinfo = JSON.parse(state.htData.course.pageConfig)
        var arr = tabinfo.content.tabsData
        arr.shift()
        return arr
      } else {
        return {}
      }
    } else if (state.htData.pageConfig) {
      var tabinfo = JSON.parse(state.htData.pageConfig)
      var arr = tabinfo.content.tabsData
      arr.shift()
      return arr
    } else {
      return {}
    }
  },
  getVideoCurMode(state) {
    return state.VideoCurMode
  },
  getModeSwitch(state) {
    if (state.htData.course) {
      if (state.htData.course.pageConfig) {
        var tabinfo = JSON.parse(state.htData.course.pageConfig)
        var obj = tabinfo.global.switch
        return obj
      } else {
        return {}
      }
    } else if (state.htData.pageConfig) {
      var tabinfo = JSON.parse(state.htData.pageConfig)
      var obj = tabinfo.global.switch
      return obj
    } else {
      return {}
    }
  },
  getShareQrcode(state) {
    if (state.htData.course) {
      if (state.htData.course.pageConfig) {
        var tabinfo = JSON.parse(state.htData.course.pageConfig)
        var qrcode = tabinfo.global.share.qrcode.value
        return qrcode
      } else {
        return ""
      }
    } else if (state.htData.pageConfig) {
      var tabinfo = JSON.parse(state.htData.pageConfig)
      var qrcode = tabinfo.global.share.qrcode.value
      return qrcode
    } else {
      return ""
    }
  },
  getPageModel(state) {
    if (state.htData.course) {
      if (state.htData.course.pageConfig) {
        var tabinfo = JSON.parse(state.htData.course.pageConfig)
        var pageViewMode = tabinfo.global.setting.pageViewMode
        return pageViewMode
      } else {
        return 2
      }
    } else if (state.htData.pageConfig) {
      var tabinfo = JSON.parse(state.htData.pageConfig)
      var pageViewMode = tabinfo.global.setting.pageViewMode
      return pageViewMode
    } else if (window.pageMode) {
      return Number(window.pageMode)
    }
  },
  getPPTModel(state) {
    if (state.htData.course) {
      if (state.htData.course.pageConfig) {
        var tabinfo = JSON.parse(state.htData.course.pageConfig)
        var pptEnable = tabinfo.global.setting.pptEnable
        return pptEnable
      } else {
        return 0
      }
    } else if (state.htData.pageConfig) {
      var tabinfo = JSON.parse(state.htData.pageConfig)
      var pptEnable = tabinfo.global.setting.pptEnable
      return pptEnable
    } else {
      return 0
    }
  },
  getConfig(state) {
    var config = null
    // 直播数据
    if (state.htData.course) {
      if (state.htData.course.pageConfig) {
        config = JSON.parse(state.htData.course.pageConfig)
      }
    }
    // 回放数据
    if (state.htData.pageConfig) {
      config = JSON.parse(state.htData.pageConfig)
    }
    return config
  },
  getPid(state) {
    return state.htData.zhubo ? state.htData.zhubo.partner_id : 0
  },
  getcourseStatus(state) {
    return state.courseStatus
  },
  getAnchorimg(state) {
    if (state.htData.zhubo) {
      if (state.htData.zhubo.p_150) {
        return state.htData.zhubo.p_150
      }
      if (state.htData.zhubo.avatar) {
        return state.htData.zhubo.avatar
      }
    }
  },
  getUser(state) {
    if (state.htData.user) {
      return state.htData.user
    } else {
      return null
    }
  },
  getCouresName(state) {
    if (state.htData.course && state.htData.course.info) {
      return state.htData.course.info.course_name
    }
  },
  getCouresTime(state) {
    if (state.htData.course && state.htData.course.start_time) {
      return state.htData.course.start_time
    }
  },
  getCourseTimeToEnd(state) {
    if (state.htData.course && state.htData.course.info) {
      return state.htData.course.info.timeToEnd
    }
  },
  getProductIdList(state) {
    return state.productIdList
  },
  getProductAddList(state) {
    return state.addProductList
  },
  getCancelProductList(state) {
    return state.cancelProductList
  },
  getLikeCount(state) {
    return state.likeCount
  },
  getLikeIntervalTime(state) {
    return state.likeIntervalTime / 1000
  },
  getPopCard(state) {
    return state.popCard
  }
}
