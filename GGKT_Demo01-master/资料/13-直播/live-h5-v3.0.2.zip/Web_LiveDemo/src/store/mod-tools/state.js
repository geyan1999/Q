export default {
  tools:{
    redAnimation:false,
    rank:false,
    line:false,
    private:false,
    product:false,
    infomation:false,
    more:false,
    redpackPop:false,
    emoji:false,
    menu:false,
    time:false,
    vote:false,
    question:false,
    inputFocus:false
  }
}