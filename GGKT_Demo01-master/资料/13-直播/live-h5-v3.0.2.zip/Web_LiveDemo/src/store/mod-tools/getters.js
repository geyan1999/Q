export default {
  getToolsMore(state){
    return state.tools.more
  },
  getToolsRedAnimation(state){
    return state.tools.redAnimation
  },
  getToolsRank(state){
    return state.tools.rank
  },
  getToolsLine(state){
    return state.tools.line
  },
  getToolsPrivate(state){
    return state.tools.private
  },
  getToolsProduct(state){
    return state.tools.product
  },
  getToolsInfomation(state){
    return state.tools.infomation
  },
  getToolsRedpackPop(state){
    return state.tools.redpackPop
  },
  getToolsEmoji(state){
    return state.tools.emoji
  },
  getToolsMenu(state){
    return state.tools.menu
  },
  getToolsTime(state){
    return state.tools.time
  },
  getToolsVote(state){
    return state.tools.vote
  },
  getToolsQuestion(state){
    return state.tools.question
  },
  getToolsClaer(state){
    let claer =  Object.entries(state.tools).some((item)=>{
      // console.error(item,item[0],item[1])
      if(item[1]){
        return true
      }
    })? false : true
    // console.error(claer)
    return claer  
  }
}