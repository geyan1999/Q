import * as TYPES from '@/assets/action-types'
export default {
  // 更新工具栏状态
  [TYPES.UPDATE_TOOLS_MODE] (state,data) {
    if(state.tools[data.type] !== undefined){
      state.tools[data.type] = data.flag
    }
  },
}