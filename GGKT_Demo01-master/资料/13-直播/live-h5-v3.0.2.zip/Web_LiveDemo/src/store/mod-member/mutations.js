import * as TYPES from '@/assets/action-types'
export default {
  // 更新在线人数
  [TYPES.UPDATE_MEMBER_TOTAL](state, total) {
    // console.error(total)
    state.member.total = total
  },
  // 机器人
  [TYPES.UPDATE_ROBOTS_TOTAL](state, total) {
    state.member.robotTotal = total
  }
}
