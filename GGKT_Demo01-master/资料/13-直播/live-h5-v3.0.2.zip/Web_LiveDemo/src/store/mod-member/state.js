export default {
  // 在线成员
  member: {
    total: 0,
    robotTotal: 0
  }
}