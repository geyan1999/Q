export default {
  getMemberTotal(state) {
    return state.member.total
  },
  getRobotTotal (state) {
    return state.member.robotTotal
  }
}