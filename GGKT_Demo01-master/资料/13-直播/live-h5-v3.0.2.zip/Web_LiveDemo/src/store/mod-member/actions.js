import * as TYPES from '@/assets/action-types'
export default {
  // 机器人
  [TYPES.UPDATE_ROBOTS_TOTAL]({ commit }, { total }) {
    // state.member.robotTotal = total
    commit(TYPES.UPDATE_ROBOTS_TOTAL, total)
  }
}
