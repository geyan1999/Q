export default {
  getSign(state){
    return state.sign
  },
  getSignStatus(state){
    return state.status
  }
}