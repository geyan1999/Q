import * as TYPES from '@/assets/action-types'
export default {
  // 更新签到
  [TYPES.UPDATA_SIGN_STATUS](state,data){
    state.status = data
  },
  // 更新签到状态
  [TYPES.UPDATA_NEW_SIGN](state,data){
    state.sign = data
  } 
}