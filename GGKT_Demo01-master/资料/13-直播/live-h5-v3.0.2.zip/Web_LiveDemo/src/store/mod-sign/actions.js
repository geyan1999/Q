import * as TYPES from '@/assets/action-types'
const baseUrl = '//' + (window.apiHost || '//open.talk-fun.com')
export default {
  // update rank state
  [TYPES.POST_SIGN]({ commit },{ vm , data }) {
    vm.$http.get( baseUrl + '/live/sign.php', {
      params:{
        access_token: data.access_token,
        action: 'sign',
        signId: data.signId
     }
    }).then(function (res) {
      if(res.data.code==0){
        commit(TYPES.UPDATA_SIGN_STATUS,'success')
      }else{
        vm.$vux.alert.show({
          title: '错误提示',
          content: res.data.msg
        })
      }
    })
    .catch(function(err){
      // console.log(err)
      vm.$vux.alert.show({
        title: '错误提示',
        content: '网络请求错误'
      })
    })
    .finally(function(){
      vm.$vux.loading.hide()
    })
  },
}