export default {
  timer:false,
  rewardState: 0, // 0 不显示红包（默认值）  1 发红包   2 打开红包   3 红包详情  4 历史红包  5 红包提现  6 零钱明细
  listReward:{
    show:false,
    data:[],
    total:null,
    page:1
  },
  getReward:{
    isget : false, // 红包是否领取过
    hasget : false, // 红包是否领取完
    isend: false, // 红包是否过期
    data : null,  // 领红包数据
    reward : null, // 红包详情
  },
  sendReward:{
    data:null
  },
  openReward:{
    isget : false, // 红包是否领取过
    hasget : false, // 红包是否领取完
    isend: false, // 红包是否过期
    reward : null // 红包详情
  },
  cashReward:{},// 我的钱包
  cashDetail:{ // 红包明细
    data:[],
    total:null,
    page:1
  },
  debug:{}, // debug模式
  curHid:0,
  zhuboReward:{
    data:null,
    price:''
  },
  zhuboRewardMsg:null
}
