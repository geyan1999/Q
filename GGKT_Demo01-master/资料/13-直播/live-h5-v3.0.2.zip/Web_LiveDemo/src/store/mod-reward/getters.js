export default {
  getRewardState(state){
      return state.rewardState
  },
  getReward(state){
    return state.getReward
  },
  getSendReward(state){
    return state.sendReward.data
  },
  getListReward(state){
    return state.listReward
  },
  getOpenReward(state){
    return state.openReward
  },
  getRewardTimer(state){
    return state.timer
  },
  getFlagReward(state){
    return state.FlagReaward
  },
  getRewardDebug(state){
    return JSON.stringify(state.debug)
  },
  getRewardCurhid(state){
    return state.curHid
  },
  getCashReward(state){
    return state.cashReward
  },
  getCashDetail(state){
    return state.cashDetail
  },
  getZhuboReward(state){
    return state.zhuboReward
  },
  getZhuboRewardPlay(state){
    return state.zhuboReward.data
  },
  getZhuboRewardMsg(state){
    return state.zhuboRewardMsg
  }
}
