import * as TYPES from '@/assets/action-types'
import Vue from 'vue'
export default {
    [TYPES.UPDATE_REWARD_STATUS](state, data) {
        state.rewardState = data
    },
    [TYPES.UPDATE_REWARD_SEND](state,data){
        state.sendReward.data = data
    },
    [TYPES.UPDATE_REWARD_GET](state, resData){
        // console.error('getting datas =>', data)
        state.getReward.hasget = false
        state.getReward.isget = false
        state.getReward.isend = false
        if(resData.code == 0){
            state.getReward.hasget = false
            state.getReward.isget = false
            state.getReward.isend = false
        }else if(resData.code == 600){
            state.getReward.hasget = true
        }else if(resData.code == 601){
            state.getReward.isend = true
        }else if(resData.code == 602){
            // 已领取过
            state.getReward.isget = true
        }
        state.getReward.data = resData.data
        // console.error(data)
        // TODO...
        // state.getReward.data.reward = resData
        state.getReward.reward = resData.reward
    },
    [TYPES.UPDATE_REWARD_OPEN](state,data){
        // console.log(data)
        if(data.code == 0){
            state.openReward.hasget = false
            state.openReward.isget = false
            state.openReward.isend = false
        }else if(data.code == 600){
            state.openReward.hasget = true
        }else if(data.code == 601){
            state.openReward.isend = true
        }else if(data.code == 602){
            state.openReward.isget = true
        }
        state.openReward.reward = data.reward
    },
    [TYPES.UPDATE_REWARD_LIST](state,data){
        state.listReward.page = data.page
        if(data.show !== undefined){
            state.listReward.show = data.show
            setTimeout(function(){
                data.vm.jquery("#loading").addClass("hidden")
            },0)
        }
        if(data.data&&state.listReward.page!==1){
            data.data.forEach(element => {
                state.listReward.data.push(element)
            });
        }
        if(data.data&&state.listReward.page==1){
            state.listReward.data = data.data
        }
        if(data.total !== undefined){
            state.listReward.total = data.total
        }
    },
    [TYPES.UPDATE_REWARD_TIMER](state){
        // console.log("计时结束")
        state.timer = true
    },
    [TYPES.UPDATE_REWARD_CASH](state,data){
        state.cashReward = data
    },
    [TYPES.UPDATE_REWARD_DETAIL](state,data){
        state.cashDetail.page = data.page
        if(data.data&&state.cashDetail.page!==1){
            data.data.forEach(element => {
                state.cashDetail.data.push(element)
            });
        }
        if(data.data&&state.cashDetail.page==1){
            state.cashDetail.data = data.data
        }
        if(data.total !== undefined){
            state.cashDetail.total = data.total
        }
    },
    UPDATE_REWARD_FLAG(state){
        // console.log("flag")
        state.FlagReaward = false
    },
    UPDATE_REWARD_DEBUG(state,data){
        state.debug = data
    },
    UPDATE_REWARD_HID(state,data){
        state.curHid = data
    },
    [TYPES.UPDATE_REWARD](state,data){
        state.zhuboReward.data = data.data
        state.zhuboReward.price = data.price
    },
    [TYPES.UPDATE_REWARD_MSG](state,data){
        state.zhuboRewardMsg = data
    }
}
