import * as TYPES from '@/assets/action-types'
const baseUrl = '//' + (window.apiHost || '//open.talk-fun.com')
export default {
  // 抢红包
  [TYPES.GER_REWARD]({ commit }, { vm, data, reward }) {
    var fromdata = new FormData()
    for(let item in data){
      fromdata.append(item,data[item])
    }
    if(window.access_token){
      fromdata.append("access_token",window.access_token)
    }
    var config = {
      headers:{
        'Content-Type': 'multipart/form-data'
      }
    }
    vm.$http.post(baseUrl + '/live/hongbao.php?action=grab', fromdata,config)
    .then(function (res) {
      commit("UPDATE_REWARD_DEBUG",{req:data,res:res.data})
      if (res.data.code == 0) {
        // 领取成功
        // console.log(reward)
        commit(TYPES.UPDATE_REWARD_GET, {
          code: 0,
          data: res.data.data,
          reward: reward
        })
        commit(TYPES.UPDATE_REWARD_STATUS, 3)
        vm.$vux.loading.hide()
      } else if (res.data.code == 600) {
        // 已领取完
        vm.$http.get(baseUrl + '/live/hongbao.php?action=record', {
          params:{
            liveid: data.liveid,
            hid: reward.hid,
            access_token:window.access_token?window.access_token:''
          }
        }).then(function (res) {
          if (res.data.code == 0) {
            commit(TYPES.UPDATE_REWARD_GET, {
              code: 600,
              data: res.data.data,
              reward: reward
            })
            commit(TYPES.UPDATE_REWARD_STATUS, 3)
          } else {
            vm.$vux.alert.show({
              title: '错误提示',
              content: res.data.msg
            })
          }
          vm.$vux.loading.hide()
        })
        .catch(function(err){
          // console.log(err)
          vm.$vux.alert.show({
            title: '错误提示',
            content: '网络请求错误'
          })
          commit(TYPES.UPDATE_REWARD_STATUS, 0)
          commit(TYPES.UPDATE_VIEWO_MODE, 0)
          vm.$vux.loading.hide()
        })
      } else if (res.data.code == 601) {
        // 已过期
        vm.$http.get(baseUrl + '/live/hongbao.php?action=record', {
          params:{
            liveid: data.liveid,
            hid: reward.hid,
            access_token:window.access_token?window.access_token:''
          }
        }).then(function (res) {
          if (res.data.code == 0) {
            commit(TYPES.UPDATE_REWARD_GET, {
              code: 601,
              data: res.data.data,
              reward: reward
            })
            commit(TYPES.UPDATE_REWARD_STATUS, 3)
          } else {
            vm.$vux.alert.show({
              title: '错误提示',
              content: res.data.msg
            })
          }
          vm.$vux.loading.hide()
        })
        .catch(function(err){
          // console.log(err)
          vm.$vux.alert.show({
            title: '错误提示',
            content: '网络请求错误'
          })
          commit(TYPES.UPDATE_REWARD_STATUS, 0)
          commit(TYPES.UPDATE_VIEWO_MODE, 0)
          vm.$vux.loading.hide()
        })
      } else if (res.data.code == 602) {
        // 已领取过
        // console.log("602")
        vm.$http.get(baseUrl + '/live/hongbao.php?action=record', {
          params:{
            liveid: data.liveid,
            hid: reward.hid,
            access_token:window.access_token?window.access_token:''
          }
        }).then(function (res) {
          if (res.data.code == 0) {
            commit(TYPES.UPDATE_REWARD_GET, {
              code: 602,
              data: res.data.data,
              reward: reward
            })
            commit(TYPES.UPDATE_REWARD_STATUS, 3)
            // commit(TYPES.UPDATE_VIEWO_MODE, 0)
          } else {
            vm.$vux.alert.show({
              title: '错误提示',
              content: res.data.msg
            })
          }
          vm.$vux.loading.hide()
        })
        .catch(function(err){
          // console.log(err)
          vm.$vux.alert.show({
            title: '错误提示',
            content: '网络请求错误'
          })
          commit(TYPES.UPDATE_REWARD_STATUS, 0)
          commit(TYPES.UPDATE_VIEWO_MODE, 0)
          vm.$vux.loading.hide()
        })
      } else {
        // 失败
        vm.$vux.alert.show({
          title: '错误提示',
          content: res.data.msg
        })
        commit(TYPES.UPDATE_REWARD_STATUS, 0)
        commit(TYPES.UPDATE_VIEWO_MODE, 0)
        vm.$vux.loading.hide()
      }
    })
    .catch(function(err){
      // console.log(err)
      vm.$vux.alert.show({
        title: '错误提示',
        content: '网络请求错误'
      })
      commit(TYPES.UPDATE_REWARD_STATUS, 0)
      commit(TYPES.UPDATE_VIEWO_MODE, 0)
      vm.$vux.loading.hide()
    })
    .finally(function(){
      // vm.$vux.loading.hide()
    })
  },
  // 发红包
  [TYPES.SEND_REWARD]({ commit }, { vm, data }) {
    var fromdata = new FormData()
    for(let item in data){
      fromdata.append(item,data[item])
    }
    if(window.access_token){
      fromdata.append("access_token",window.access_token)
    }
    var config = {
      headers:{
        'Content-Type': 'multipart/form-data'
      }
    }
    vm.$http.post(baseUrl + '/live/pay.php?action=hongbao',fromdata,config)
    .then(function (res) {
      commit("UPDATE_REWARD_DEBUG",{req:data,res:res.data})
      if (res.data.code == 0) {
        // 发红包成功
        commit(TYPES.UPDATE_REWARD_SEND, res.data.data)
      } else {
        vm.$vux.alert.show({
          title: '错误提示',
          content: res.data.msg
        })
      }
    })
    .catch(function(err){
      // console.log(err)
      vm.$vux.alert.show({
        title: '错误提示',
        content: '网络请求错误'
      })
      commit(TYPES.UPDATE_REWARD_STATUS, 0)
      commit(TYPES.UPDATE_VIEWO_MODE, 0)
    })
    .finally(function(){
      vm.$vux.loading.hide()
    })
  },
  // 检查红包
  [TYPES.CHECK_REWARD]({ commit }, { vm, data, reward }) {
    vm.$http.get(baseUrl + '/live/hongbao.php?action=check', {
      params:{
        liveid: data.liveid,
        hid: data.hid,
        access_token:window.access_token?window.access_token:''
      }
    }).then(function (res) {
      commit("UPDATE_REWARD_DEBUG",{req:data,res:res.data})
      if (res.data.code == 0) {
        // 领取成功
        commit(TYPES.UPDATE_REWARD_OPEN, {
          code: 0,
          reward: reward
        })
        commit(TYPES.UPDATE_REWARD_STATUS, 2)
        commit(TYPES.UPDATE_VIEWO_MODE, 0)
        vm.$vux.loading.hide()
      } else if(res.data.code==600||res.data.code==601||res.data.code==602){
        vm.$http.get(baseUrl + '/live/hongbao.php?action=record', {
          params:{
            liveid: data.liveid,
            hid: data.hid,
            access_token:window.access_token?window.access_token:''
          }
        }).then(function (res) {
          if (res.data.code == 0) {
            commit(TYPES.UPDATE_REWARD_GET, {
              code: 600,
              data: res.data.data,
              reward: reward
            })
            commit(TYPES.UPDATE_REWARD_STATUS, 3)
          } else {
            vm.$vux.alert.show({
              title: '错误提示',
              content: res.data.msg
            })
          }
          vm.$vux.loading.hide()
        })
      } else {
        vm.$vux.alert.show({
          title: '错误提示',
          content: '网络请求错误'
        })
        commit(TYPES.UPDATE_REWARD_STATUS, 0)
        commit(TYPES.UPDATE_VIEWO_MODE, 0)
        vm.$vux.loading.hide()
      } 
    })
    .catch(function(err){
      // console.log(err)
      vm.$vux.alert.show({
        title: '错误提示',
        content: '网络请求错误'
      })
      commit(TYPES.UPDATE_REWARD_STATUS, 0)
      commit(TYPES.UPDATE_VIEWO_MODE, 0)
      vm.$vux.loading.hide()
    })
    .finally(function(){
      // vm.$vux.loading.hide()
    })
  },
  // 查看红包
  [TYPES.VIEW_REWARD]({ commit }, { vm, data, reward }) {
    vm.$http.get(baseUrl + '/live/hongbao.php?action=record', {
      params: {
        liveid: data.liveid,
        hid: data.hid,
        access_token:window.access_token?window.access_token:''
     }
    }).then(function (res) {
      commit("UPDATE_REWARD_DEBUG",{req:data,res:res.data})
      if (res.data.code == 0) {
        commit(TYPES.UPDATE_REWARD_GET, {
          code:0,
          data: res.data.data,
          reward: reward
        })
        commit(TYPES.UPDATE_REWARD_STATUS, 3)
      } else {
        vm.$vux.alert.show({
          title: '错误提示',
          content: res.data.msg
        })
      }
    })
    .catch(function(err){
      // console.log(err)
      vm.$vux.alert.show({
        title: '错误提示',
        content: '网络请求错误'
      })
      commit(TYPES.UPDATE_REWARD_STATUS, 0)
      commit(TYPES.UPDATE_VIEWO_MODE, 0)
    })
    .finally(function(){
      vm.$vux.loading.hide()
    })
  },
  // 获取红包列表
  [TYPES.LIST_REWARD]({ commit },{ vm , data }) {
    vm.$http.get( baseUrl + '/live/hongbao.php?action=list', {
      params:{
        liveid:data.liveid,
        page:data.page,
        access_token:window.access_token?window.access_token:''
     }
    }).then(function (res) {
      commit("UPDATE_REWARD_DEBUG",{req:data,res:res.data})
      if(res.data.code==0){
        commit(TYPES.UPDATE_REWARD_LIST,{
          data:res.data.data,
          total:Math.ceil(res.data.total/10),
          page:data.page
        })
        commit(TYPES.UPDATE_REWARD_STATUS,4)
      }else{
        vm.$vux.alert.show({
          title: '错误提示',
          content: res.data.msg
        })
        commit(TYPES.UPDATE_REWARD_STATUS, 0)
        commit(TYPES.UPDATE_VIEWO_MODE, 0)
      }
    })
    .catch(function(err){
      // console.log(err)
      vm.$vux.alert.show({
        title: '错误提示',
        content: '网络请求错误'
      })
      commit(TYPES.UPDATE_REWARD_STATUS, 0)
      commit(TYPES.UPDATE_VIEWO_MODE, 0)
    })
    .finally(function(){
      vm.$vux.loading.hide()
      vm.$vux.loading.hide()
    })
  },
  // 我的钱包
  [TYPES.INDEX_CASH_REWARD]({ commit },{ vm }){
    let parm = 'access_token=' + window.access_token
    vm.$http.get( baseUrl + '/live/wallet.php?action=index&' + parm)
    .then(function(res){
      if(res.data.code==0){
        commit(TYPES.UPDATE_REWARD_CASH,res.data.data)
        commit(TYPES.UPDATE_REWARD_STATUS,5)
      }else{
        vm.$vux.alert.show({
          title: '错误提示',
          content: res.data.msg
        })
        commit(TYPES.UPDATE_REWARD_STATUS, 0)
        commit(TYPES.UPDATE_VIEWO_MODE, 0)
      }
    })
    .catch(function(err){
      // console.log(err)
      vm.$vux.alert.show({
        title: '错误提示',
        content: '网络请求错误'
      })
      commit(TYPES.UPDATE_REWARD_STATUS, 0)
      commit(TYPES.UPDATE_VIEWO_MODE, 0)
    })
    .finally(function(){
      vm.$vux.loading.hide()
    })
  },
  // 红包提现
  [TYPES.CASH_REWARD]({ commit },{ vm , url }){
    var fromdata = new FormData()
    if(window.access_token){
      fromdata.append("access_token",window.access_token)
    }
    var config = {
      headers:{
        'Content-Type': 'multipart/form-data'
      }
    }
    vm.$http.post( baseUrl + url, fromdata, config)
    .then(function(res){
      if(res.data.code==0){
        vm.$vux.toast.text("操作成功", "middle");
        commit(TYPES.UPDATE_REWARD_STATUS, 0)
        commit(TYPES.UPDATE_VIEWO_MODE, 0)
      }else{
        vm.$vux.toast.text("提现失败", "middle");
        commit(TYPES.UPDATE_REWARD_STATUS, 0)
        commit(TYPES.UPDATE_VIEWO_MODE, 0)
      }
      vm.cash_confimr = false
    })
    .catch(function(err){
      // console.log(err)
      vm.$vux.alert.show({
        title: '错误提示',
        content: '网络请求错误'
      })
      commit(TYPES.UPDATE_REWARD_STATUS, 0)
      commit(TYPES.UPDATE_VIEWO_MODE, 0)
    })
    .finally(function(){
      vm.$vux.loading.hide()
    })
  },
  // 红包明细
  [TYPES.DETAIL_REWARD]({ commit },{ vm ,data }){
    vm.$http.get( baseUrl + "/live/wallet.php?action=detail",{
      params:{
        page:data.page,
        access_token:window.access_token?window.access_token:''
      }
    })
    .then(function(res){
      if(res.data.code==0){
        commit(TYPES.UPDATE_REWARD_DETAIL,{
          data:res.data.data,
          total:Math.ceil(res.data.total/20),
          page:data.page
        })
        commit(TYPES.UPDATE_REWARD_STATUS,6)
      }else{
        vm.$vux.alert.show({
          title: '错误提示',
          content: res.data.msg
        })
      }
    })
    .catch(function(err){
      // console.log(err)
      vm.$vux.alert.show({
        title: '错误提示',
        content: '网络请求错误'
      })
    })
    .finally(function(){
      vm.$vux.loading.hide()
      // vm.$vux.loading.hide()
    })
  },
  // 主播打赏
  [TYPES.POST_REWARD]({ commit },{ vm , data, price }){
    var fromdata = new FormData()
    for(let item in data){
      fromdata.append(item,data[item])
    }
    if(window.access_token){
      fromdata.append("access_token",window.access_token)
    }
    var config = {
      headers:{
        'Content-Type': 'multipart/form-data'
      }
    }
    vm.$http.post(baseUrl + '/live/pay.php?action=reward',fromdata,config)
    .then(function (res) {
      // commit("UPDATE_REWARD_DEBUG",{req:data,res:res.data})
      if (res.data.code == 0) {
        // 打赏成功
        commit(TYPES.UPDATE_REWARD, {
          data:res.data.data,
          price:price
        })
      } else {
        vm.$vux.alert.show({
          title: '错误提示',
          content: res.data.msg
        })
      }
    })
    .catch(function(err){
      // console.log(err)
      vm.$vux.alert.show({
        title: '错误提示',
        content: '网络请求错误'
      })
      commit(TYPES.UPDATE_SIDE_MODE, 0)
    })
    .finally(function(){
      vm.$vux.loading.hide()
    })
  }
}
