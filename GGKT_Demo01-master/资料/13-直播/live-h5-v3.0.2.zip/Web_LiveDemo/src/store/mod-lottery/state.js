export default {
  staus: -1, // -1 隐藏（默认值） 0 抽奖中  1 抽奖结束
  data: {},
  isStart: false
}