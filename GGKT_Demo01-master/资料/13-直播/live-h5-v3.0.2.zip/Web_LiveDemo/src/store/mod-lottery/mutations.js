import * as TYPES from '@/assets/action-types'
export default {
  // 更新抽奖状态
  [TYPES.UPDATE_LOTTERY_STATUS] (state, resdata) {
    state.staus = resdata.staus
    state.data = resdata.data
  },
  updataAnimaton (state,isStart){
    state.isStart = isStart
  }
}