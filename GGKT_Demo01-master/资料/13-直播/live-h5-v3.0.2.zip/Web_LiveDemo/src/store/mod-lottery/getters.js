export default {
  getLottery(state){
    return state
  },
  getLotteryStaus(state){
    return state.staus
  }
}