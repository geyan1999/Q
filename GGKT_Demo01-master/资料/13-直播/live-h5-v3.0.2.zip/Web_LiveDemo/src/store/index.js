import Vue from 'vue'
import Vuex from 'vuex'
import states from './state'
import actions from './actions'
import mutations from './mutations'
import getters from './getters'
// 模块
import question from './mod-question'
import chat from './mod-chat'
import live from './mod-live'
import vote from './mod-vote'
import member from './mod-member'
import reward from './mod-reward'
import lottery from './mod-lottery'
import rank from './mod-rank'
import side from './mod-side'
import vod from './mod-vod'
import privateChat from './mod-privateChat'
import tools from './mod-tools'
import sign from './mod-sign'
// import live from './mod-live'
// todos...
// vuex
Vue.use(Vuex)
export default new Vuex.Store({
  state: states,
  actions: actions,
  mutations: mutations,
  getters: getters,
  // 模块加载
  modules: {
    question: question,
    chat: chat,
    vote: vote,
    member: member,
    live: live,
    reward: reward,
    lottery: lottery,
    rank: rank,
    side: side,
    vod: vod,
    privateChat: privateChat,
    tools: tools,
    sign:sign
  }
})
