import * as TYPES from '@/assets/action-types'
export default {
  // 水印
  [TYPES.UPDATE_WATER_MARKER] (state, payload) {
    state.watermark = payload
  },
  // 直播状态
  [TYPES.UPDATE_LIVE_STATE] (state, payload) {
    state.liveState = payload
  },
  //回放状态
  [TYPES.UPDATE_LIVE_VOD] (state, payload) {
    if(typeof payload === "number"){
      state.currentTime = payload
    }else{
      state.vod = payload
    }
  },
  // 播放器状态
  [TYPES.UPDATE_VIDEO_STATUS] (state,data) {
    if(data==='pause'){
      state.videoPause = true
    }else{
      state.videoPause = false
    }
    state.videoState = data
  },
  // 播放线路
  [TYPES.UPDATE_LIVE_LINE] (state,data) {
    state.liveLine = data
  },
  [TYPES.UPDATE_WHITEBOARD] (state,data){
    state.whiteboard = data
  },
}