import * as TYPES from '@/assets/action-types'
export default {
  // update live state
  [TYPES.UPDATE_LIVE_STATE] (store, data) {
    store.commit(TYPES.UPDATE_LIVE_STATE, data)
  }
}