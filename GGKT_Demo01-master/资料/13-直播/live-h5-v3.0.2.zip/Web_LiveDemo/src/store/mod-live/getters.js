export default {
  getWatermarker (state) {
    return state.watermark
  },
  getLiveState (state) {
    return state.liveState
  },
  getVod(state){
    return state.vod
  },
  getCurrentTime(state){
    return state.currentTime
  },
  getVideoStatus(state){
    return state.videoState
  },
  getVideoPause(state){
    return state.videoPause
  },
  getLiveLine(state){
    return state.liveLine
  },
  getWhiteBoard(state){
    return state.whiteboard
  },
}