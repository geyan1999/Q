export default {
  watermark: null,
  liveState: 'loading',
  liveLine:[],
  vod:{
    currentTime:null,
    duration:null,
    currentPercent:null
  },
  currentTime:null,
  videoState: '',
  videoPause:null,
  whiteboard:null //画板状态
}