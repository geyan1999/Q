<template>
<div id="app" style="position:fixed; user-select: none;" :class="{'isWX':isWx}" @click="clear">
  <!-- #全屏模板 -->
  <mod-ecom-view v-if="vodpack == 0 && getPageModel==1"></mod-ecom-view>
  <!-- #半屏模板-->
  <mod-company-view v-if="vodpack == 0 && getPageModel == 0"></mod-company-view>
  <!-- 课件模板 -->
  <mod-coures-view v-if="vodpack == 0 && getPageModel == 2"></mod-coures-view>
  <!-- #回放模板半屏模板 -->
  <mod-replay-view v-if="vodpack == 1 && pageModel==0"></mod-replay-view>
  <!-- #回放全屏模板 -->
  <mod-full-replay-view v-if="vodpack == 1 && pageModel==1"></mod-full-replay-view>
  <!-- #回放课件模板 -->
  <mod-coures-replay-view v-if="vodpack == 1 && pageModel==2"></mod-coures-replay-view>
  <!-- #固定链接模板 -->
  <course-error v-if="!getcourseStatus"></course-error>
</div>
</template>

<script>
/**
 * @live-h5 直播观看端 v3.0
 * @Api文档 => http://open.talk-fun.com/docs/js/sdk.js.getstart.html
 * @模块设置文档
 * @功能模块文档
 * @操作文档
 */
import Vue from 'vue'
import ModEcomView from './components/mod-full/ModEcomView'
import ModCouresView from './components/mod-full/ModCouresView'
import CourseError from './components/mod-full/CourseError'
import ModCompanyView from './components/mod-company/ModCompanyView'
import ModReplayView from './components/mod-playback/ReplayView'
import ModFullReplayView from './components/mod-playback/FullReplayView'
import ModCouresReplayView from './components/mod-playback/CouresReplayView'
import * as tools from "./assets/js/util"
import {
  mapActions,
  mapState,
  mapGetters
} from 'vuex'
import {
  loader
} from 'vue-m-loader'
import sdkInit from './assets/js/sdk.cmd'
import initConfig from './assets/js/init.config'
import sdkSettings from './assets/js/sdk.settings'
import pageEventInit from './assets/js/page.event.init'
import * as TYPES from "@/assets/action-types";
export default {
  name: 'TalkFunLiveApp',
  components: {
    ModEcomView,
    ModCompanyView,
    ModReplayView,
    CourseError,
    ModCouresView,
    ModFullReplayView,
    ModCouresReplayView
  },
  data() {
    return {
      isLoading: true,
      vodpack: window.isVod || 0,
      isWx: true,
      pageModel: window.pageMode || 0
    }
  },
  computed: {
    ...mapGetters([
      'getLayoutMode',
      'getPageModel',
      'getcourseStatus'
    ]),
  },
  methods: {
    getSdk() {
      this.HTSDK
    },
    timer() {
      setTimeout(() => {
        this.$store.commit(TYPES.UPDATE_REWARD_TIMER);
      }, 1000 * 60)
    },
    clear() {
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'more',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'redAnimation',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'rank',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'line',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'private',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'product',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'infomation',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'redpackPop',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'emoji',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'menu',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'vote',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'question',
        flag: false
      })
    }
  },

  beforeCreate() {},

  beforeMount() {

  },
  mounted() {
    // 回放SDK 
    let vodpack = window.isVod == 1 ? (window.vodSdk||'//static-1.talk-fun.com/open/maituo_v2/dist/vod/sdk-vod.3.8.min.js') : ''
    // 直播SDK
    let sdkPath = window.sdkUrl || 'https://static-1.talk-fun.com/open/maituo_v2/dist/live/pc/sdk-pc.5.1.min.js'
    this.isWx = tools.getIsWxClient()
    let _token = window.access_token || ''
    loader({
      url: vodpack !== '' ? vodpack : sdkPath
    }).then(() => {
      let HTSDK = new window.MT.SDK.main(_token,window.sdkConfig,(initData) => {
        // 初始化设置
        sdkSettings.initSetting(initData, this)
        // 初始化页面绑定事件
        pageEventInit({
          $vue: this,
          sdk: HTSDK
        })
        if (document.getElementById("talkfun_loading")) {
          document.body.removeChild(document.getElementById("talkfun_loading"));
        }
      })
      // 注入HTSDK对象
      Vue.prototype.HTSDK = HTSDK
      // 监听事件
      sdkInit({
        sdk: HTSDK,
        $vue: this
      })
      // 初始化配置
      initConfig.init({
        $vue: this
      })
      this.$nextTick(() => {
        this.jquery("input,textarea,select").blur(function () {
          document.body.scrollTop = document.documentElement.scrollTop = 0;
        })
        this.jquery("input,textarea,select").on('blur', () => {
          document.body.scrollTop = document.documentElement.scrollTop = 0;
        })
      })
      // timer
      this.timer()
    })
  }
}
</script>

<style lang="less">
@import "~@/assets/less/reset.less";

#app {
  width: 100%;
  height: 100%;
  max-width: 750px;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;

  #tf-xplay-icon {
    position: absolute !important;
  }

  // 合作方对接处理
  .go_back {
    position: absolute;
    top: .3rem;
    right: .5rem/2;
    z-index: 400;
    width: 1rem/2;
    height: 1rem/2;
    background: rgba(0, 0, 0, .3) url(~@/assets/images/live-v2/close.svg) no-repeat;
    background-size: 60% 60%;
    background-position: center center;
    border-radius: 50%;
  }
}
</style>
