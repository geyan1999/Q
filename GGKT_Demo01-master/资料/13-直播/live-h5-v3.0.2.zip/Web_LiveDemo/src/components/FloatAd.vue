<template>
<!-- 浮动广告 -->
<div class="ad_warp" v-if="getLiveState === 'start' && adlist.length && adConfig">
  <img :src="item.img" alt="" v-for="(item, index) in adlist" :key="index" :style="{
      zIndex:index+1,
      top:((contentSize.height-(contentSize.width*(item.scale/100)*(item.height/item.width)))*((item.position.top)/100) )+'px',
      left:((contentSize.width*(1-(item.scale/100)))*(item.position.left/100))+'px',
      width:item.scale+'%',
      position:'absolute'
    }" @click.stop="goAdLink(item)">
</div>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
export default {
  data() {
    return {
      isVod: window.isVod && window.isVod == 1 ? true : false,
    }
  },
  computed: {
    ...mapGetters([
      "getLiveState",
      "getConfig",
      "getHtData"
    ]),
    pid() {
      if (this.isVod) {
        if (this.getHtData && this.getHtData.pid) {
          return this.getHtData.pid
        }
      } else {
        if (this.getHtData && this.getHtData.zhubo && this.getHtData.zhubo.partner_id) {
          return this.getHtData.zhubo.partner_id
        }
      }
      return false
    },
    adConfig() {
      return (this.getConfig && this.getConfig.global.switcher.ad && this.getConfig.global.switcher.ad.enable == 1) ? true : false
    },
    adlist() {
      return (this.getConfig && this.getConfig.adlist) || []
    },
    contentSize() {
      let _app = document.querySelector('#app')
      return {
        width: _app.clientWidth,
        height: _app.clientHeight
      }
    }
  },
  methods: {
    goAdLink(good) {
      let url = good.link || ''
      if (url===''){
        return
      }
      // 小程序跳转
      if (url.match(/\[wx\]/)) {
        url = url.replace('[wx]', '')
        if (window.wx) {
          window.wx.miniProgram.navigateTo({
            url: url
          })
        }
        return false
      } else {
        window.location.href = url
      }

    }
  },
}
</script>

<style lang="less" scoped>
.ad_warp {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  height: 100vh;
}
</style>
