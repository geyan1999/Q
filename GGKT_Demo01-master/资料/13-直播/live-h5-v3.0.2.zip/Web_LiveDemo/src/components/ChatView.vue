<template>
<div id="chat" class="mod_chat_hall" :class="{full_mode:getPageModel!=0,coures_mod:getPageModel==2,red:styleRed}" @click="blur">
  <!-- #消息 -->
  <div ref="chat_scroller" id="chat_hall" class="mod_chat_list mod_com_scroller wrapper" v-if="config('chat')" @scroll="scroll">
    <ul class="chat_inner content">
      <li class="chat-item" :id="'item_' + index" v-for="(item, index) in chatList" :key="index">
        <!-- #聊天消息 -->
        <div class="pub_msg" :class="{role:item.role == 'admin' || item.role == 'spadmin'}" v-if="!item.type">
          <div class="avatar_warp">
            <img :src="item.avatar" alt class="avatar" />
            <span class="role_icon" v-show="item.role == 'admin' || item.role == 'spadmin'"></span>
          </div>
          <div class="chat_right">
            <div class="chat_head_com">
              <span class="nickname">{{item.nickname}}：</span>
              <span v-html="renderMsg(item.msg,item.role)?renderMsg(item.msg,item.role):renderMsg(item.message,item.role)" v-if="!item.image"></span>
              <img :src="item.image" alt v-gallery:group1 v-else />
            </div>
          </div>
        </div>
        <!-- #红包信息 -->
        <div class="pub_msg reward_msg" v-if="item.type === 'notify_reward' && isWx" :class="{get:!item.reward.get}">
          <div v-if="!item.reward.get" style="display:flex;">
            <img :src="item.reward.avatar" alt class="avatar" />
            <div class="chat_right spadmin">
              <div class="chat_head_com">
                <span class="nickname">{{item.reward.nickname}}</span>
              </div>
              <div class="reward_bg" @click.stop="changeRewardState(2, index, item.reward)">
                <div class="reward_title">{{item.reward.title}}</div>
                <div class="reward_type">普通红包</div>
              </div>
            </div>
          </div>
          <div class="reward_getlist" v-if="item.reward.get">
            <span class="getlist_icon"></span>
            <span>{{item.reward.get === '红包已被领取完'? '红包已被领取完':item.reward.get + '领取了你的红包'}}</span>
          </div>
        </div>
        <!-- #打赏消息 -->
        <div class="pub_msg reward_zhubo_msg" v-if="item.type === 'notify_reward_zhubo'">
          <div class="inner_warp">
            <span class="nickname">{{item.nickname}}</span>打赏了主播一个<span class="pirce">{{item.money}}</span>元的红包
          </div>
        </div>
      </li>
    </ul>
  </div>
  <!-- 消息提示 -->
  <div class="tips" v-if="chatTips" @click.stop="upChatList">{{chatTipsCount>99?'999':chatTipsCount}}条新消息</div>
  <!-- #进入直播消息 -->
  <div class="into_msg" v-if="getConfig&&getConfig.global.switch.entranceTips.enable == 1">
    <transition name="fade">
      <div class="into_msg_warp" v-if="roomData">
        <div class="avatar">
          <img :src="roomData.member.avatar" :alt="roomData.member.nickname" />
        </div>
        <div class="msg">{{roomData.member.nickname}}</div>
        <div class="msg_placeholder">进入</div>
      </div>
    </transition>
  </div>
  <!-- 弹出推荐商品 -->
  <product-pop v-if="getConfig && getConfig.global.setting.pageViewMode != 0 && !isVod && getConfig.global.switch.store.enable == 1"></product-pop>
  <!-- 直播倒计时 -->
  <timer-count v-if="getPageModel==0"></timer-count>
</div>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
import SDKEMIT from "@/assets/js/sdk.emit";
import jQuery from "jquery";
import * as tools from "@/assets/js/util";
import * as TYPES from "@/assets/action-types";
import fixOverflowScroll from "fix-overflow-scroll";
import BScroll from "better-scroll";
import IScroll from "iscroll";
import TimerCount from "@/components/TimerCount"
import Infomation from "@/components/Infomation"
import NetwordLine from "@/components/NetwordLine"
import MoreView from "@/components/MoreView"
import ChatPost from "@/components/ChatPost"
import ProductPop from "@/components/ProductPop"
export default {
  components: {
    TimerCount,
    Infomation,
    NetwordLine,
    MoreView,
    ChatPost,
    ProductPop
  },
  data() {
    return {
      emojiPack: {
        "[微笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon1.png",
        "[调皮]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon2.png",
        "[害羞]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon3.png",
        "[奸笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon4.png",
        "[憨笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon5.png",
        "[尴尬]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon6.png",
        "[鼓掌]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon7.png",
        "[惊讶]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon8.png",
        "[闭嘴]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon9.png",
        "[呲牙]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon10.png",
        "[大哭]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon11.png",
        "[大笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon12.png",
        "[得意]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon13.png",
        "[囧]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon14.png",
        "[难过]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon15.png",
        "[敲打]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon16.png",
        "[色]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon17.png",
        "[委屈]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon18.png",
        "[疑问]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon19.png",
        "[郁闷]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon20.png",
        "[再见]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon21.png",
        "[可怜]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon22.png",
        "[捂脸]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon23.png",
        "[笑哭]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon24.png",
        "[安慰]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon25.png"
      },
      isWx: true,
      timer: null,
      intoroomlist: [], // 缓存数组
      roomData: null,
      isVod: window.isVod && window.isVod == 1 ? true : false,
      scrollTimer: null,
      scrollTop: 0,
      chatTips: false,
      chatTipsCount: 0,
      shoplist: [],
      shopData: null,
      timerShop: null,
      tmpChatList: [],
      randerChatList: []
    };
  },
  filters: {
    // todo...
    getTime(_time) {
      return tools.convertTimestamp(_time);
    },
    // render
    renderImg(msg) {
      // console.warn(msg)
      msg = '<img src="' + msg.replace(/\[(.+?)\]/g, "") + '" />';
      return msg;
    },
    // emoji
    renderEmoji(msg) {
      // msg = msg.replace(/\[*.\]/, '')
      return msg;
    }
  },
  computed: {
    ...mapGetters([
      "getChatList",
      "getChatLock",
      "getHtData",
      "getRewardTimer",
      "getFlagReward",
      "getRewardCurhid",
      "getModeSwitch",
      "getintoRoom",
      "getLiveState",
      "getConfig",
      "getLiveLine",
      "getUser",
      "getActModule",
      "getpvUserlist",
      "getCurTip",
      "getPageModel",
      "getShoping",
      "getPid"
    ]),
    chatList() {
      // console.error(this.randerChatList)
      if (this.randerChatList.length > 0) {
        // console.error(this.getChatList)
        let result = this.randerChatList.map(item => {
          if (item.type === "notify_reward") {
            item.reward = this.notifyRewardHander(item);
            return item;
          }
          if (item.msg && item.msg.indexOf("[IMG]") > -1) {
            item.image = item.msg
              .replace(/\[(.+?)\]/g, "")
              .replace(/_s\.jpg/, ".jpg");
            //  .replace(/_s\.jpg/, '.jpg')
          }
          return item;
        });
        return result;
      } else {
        return []
      }
    },
    liveid() {
      if (this.getHtData.live) {
        return this.getHtData.live.liveid;
      } else {
        return 0;
      }
    },
    pid() {
      if (this.isVod) {
        if (this.getHtData && this.getHtData.pid) {
          return this.getHtData.pid
        }
      } else {
        if (this.getHtData && this.getHtData.zhubo && this.getHtData.zhubo.partner_id) {
          return this.getHtData.zhubo.partner_id
        }
      }
      return 0
    },
    styleRed() {
      let pids = window.annual_config_pid || []
      return pids.some((pid) => {
        return pid == this.pid
      }) && this.getPageModel == 0
    }
  },
  methods: {
    ...mapActions({
      fireChat: "CHAT_UPDATE_LIST",
      checkReward: "CHECK_REWARD",
      indexCashReward: "INDEX_CASH_REWARD",
    }),
    chatInfo() {
      this.randerChatList = [...this.getChatList]
      if (this.config("chat")) {
        this.$nextTick(() => {
          // 二分屏 计算聊天区高度
          if (this.getPageModel != 1) {
            var mod_modules_wrap = this.jquery(".mod_modules");
            var mod_chat_hall = this.jquery(".mod_chat_hall");
            var mod_modules_wrap_height =
              this.jquery(document).height() - this.jquery("#warp_top").height();
            var mod_chat_hall_height =
              mod_modules_wrap_height - this.jquery("#mode_chat_post").height();
            mod_modules_wrap.css("height", mod_modules_wrap_height + "px");
            mod_chat_hall.css("height", mod_chat_hall_height + "px");
          }
          // 初始化聊天滚动区
          if (this.config('chat')) {
            this.$refs.chat_scroller.scrollTop = this.$refs.chat_scroller.scrollHeight
            this.scrollTop = this.$refs.chat_scroller.scrollTop
          }
        });
      }
    },
    config(type) {
      let flag = false;
      if (this.getConfig) {
        this.getConfig.content.tabsData.forEach((item) => {
          if (item.type === type) {
            flag = true
          }
        })
      }
      return flag
    },
    getIsWxClient() {
      var ua = navigator.userAgent.toLowerCase();
      if (ua.match(/MicroMessenger/i) == "micromessenger") {
        return true;
      }
      return false;
    },
    renderReplyMsg(msg, role) {
      var _span = document.createElement("span");
      _span.innerHTML = msg;
      var rander = msg
      try {
        var d = JSON.parse(_span.innerText)
        if (d.type == 'reply' && role == 'admin') {
          rander = tools.isMe({
            xid: d.xid
          }, this.getHtData.user) ? `<span class='reply'>@你</span> ${d.content}` : `<span class='reply'>@${d.nickname}(${d.xid})</span>${d.content}`
        }
      } catch (err) {
        // console.warn("jons转换错误")
      }
      return rander
    },
    renderMsg(_msg, role) {
      let msg = this.renderReplyMsg(_msg, role)
      if (!msg) {
        return false;
      }
      let _rule = /\[(.+?)\]/g;
      let _list = msg.match(_rule);
      if (_list && _list.length > 0) {
        // 截图
        if (msg.indexOf("[IMG]") > -1) {
          var imgClip = msg.replace(/\[(.+?)\]/g, "");
          return '<img src="' + imgClip + '" />';
        }
        // 表情
        msg = msg.replace(_rule, (r, k) => {
          let emoji = this.emojiPack[r];
          if (emoji) {
            return (
              '<img src="' +
              emoji +
              '"' +
              'class="emoji_img"' +
              "/>"
            );
          } else {
            return r
          }
        });
      }
      return msg;
    },
    seeVoteDetail(vid) {
      this.HTSDK.plugins("vote").getVoteDetail(vid, retval => {
        this.$store.commit("UPDATE_VOTE_STATUS", "end");
        this.$store.commit("UPDATE_VOTE_POP_STATUS", "open");
        this.$store.commit("UPDATE_VOTE_RESULT", retval);
      });
    },
    notifyRewardHander(item) {
      let data = {
        nickname: item.originCnt.nickname,
        avatar: item.originCnt.avatar,
        title: item.originCnt.title,
        time: item.originCnt.time,
        hid: item.originCnt.hid,
        user: item.originCnt.user
      };
      if (item.end == 1) {
        // 领取红包信息
        data = {};
        data.get = item.originCnt.nickname;
      } else if (item.end == 2) {
        // 红包领取完信息
        data = {};
        data.get = "红包已被领取完";
      }
      return data;
    },
    changeRewardState(val, index, reward) {
      if (val == 2) {
        // 打开红包前检查红包是否可以领取
        if (this.getHtData.user.role == 'user') {
          if (
            this.getRewardTimer ||
            tools.isMe(reward.user, this.getHtData.user)
          ) {
            this.$store.commit("UPDATE_REWARD_HID", reward.hid);
              this.checkReward({
                vm: this,
                data: {
                  liveid: this.liveid,
                  hid: this.getRewardCurhid
                },
                reward: reward
              });
            this.$vux.loading.show({
              text: 'loading'
            })
          } else {
            this.$vux.toast.text("观看1分钟后才能参与红包领取", "bottom");
          }
        } else {
          this.$vux.toast.text("管理员不能抢红包", "bottom");
        }
      } else if (val == 5) {
        // 我的钱包
        this.indexCashReward({
          vm: this
        });
        this.$vux.loading.show({
          text: 'loading'
        })
      } else {
        this.$store.commit(TYPES.UPDATE_REWARD_STATUS, val);
      }
    },
    blur() {
      if (document.getElementById("chat_post_txt")) {
        document.getElementById("chat_post_txt").blur()
      }
    },
    scroll() {
      let _element = this.$refs.chat_scroller
      if (this.scrollTop > this.$refs.chat_scroller.scrollTop) {
        // 排除因为输出框聚焦时变化导致的滚动高度变化，首先检查是否在底部
        if (_element.scrollHeight - _element.scrollTop - _element.clientHeight <= 1) {
          // alert("上滑误触底部")
        } else {
          if (this.scrollTop - this.$refs.chat_scroller.scrollTop > 10) {
            // alert("上滑")
            this.$store.commit(TYPES.CHAT_SET_LOCK, true);
            // this.getChatLock = true
          }
        }
      } else {
        // alert(_element.scrollHeight - _element.scrollTop - _element.clientHeight)
        if (_element.scrollHeight - _element.scrollTop - _element.clientHeight <= 1) {
          // alert("底部")
          this.upChatList()
        }
      }
      this.scrollTop = this.$refs.chat_scroller.scrollTop

    },
    upChatList() {
      // this.getChatLock = false
      this.$store.commit(TYPES.CHAT_SET_LOCK, false);
      this.chatTips = false
      this.chatTipsCount = 0
      if (this.tmpChatList.length) {
        this.randerChatList = [...this.tmpChatList]
        this.tmpChatList = []
        this.$nextTick(() => {
          // this.tmpChatList = []
          this.$refs.chat_scroller.scrollTop = this.$refs.chat_scroller.scrollHeight
          this.scrollTop = this.$refs.chat_scroller.scrollTop
        })
      }
    }
  },
  watch: {
    getActModule(nv) {
      if (nv === 'chat' && this.getPageModel != 1) {
        this.$nextTick(() => {
          this.$refs.chat_scroller.scrollTop = this.$refs.chat_scroller.scrollHeight
        });
      }
    },
    getChatList(nv, ov) {
      // console.error(nv,this.getChatLock)
      if (!this.getChatLock) {
        // console.error('randerChatList')
        this.randerChatList = [...nv]
        this.tmpChatList = []
        this.$nextTick(() => {
          this.$refs.chat_scroller.scrollTop = this.$refs.chat_scroller.scrollHeight
          this.scrollTop = this.$refs.chat_scroller.scrollTop
        });
      } else {
        // console.error('tmpChatList')
        this.chatTips = true
        this.chatTipsCount += 1
        this.tmpChatList = [...nv]
      }
    },
    getintoRoom(nv, ov) {
      // this.intoroomlist.some((item) => {
      //   return item.xid == nv.xid
      // })
      if (this.timer) {
        // 添加到缓存数组中
        if (!this.intoroomlist.some((item) => {
            return item.xid == nv.xid
          })) {
          this.intoroomlist.push(nv);
        }
      } else {
        // 设置当前数据
        this.roomData = nv;
        this.timer = true;
        setTimeout(() => {
          this.roomData = null;
          this.timer = false;
        }, 1000);
      }
    },
    roomData(nv, ov) {
      let i = 0,
        list = this.intoroomlist,
        len = this.intoroomlist.length;
      if (!nv && !this.timer) {
        // 当前没有数据的时候，如果数组不为空则循环缓存数组
        if (len > 0) {
          for (i; i < len; i++) {
            let data = list[i];
            setTimeout(
              (function (roomdata, i, len, vm) {
                return function () {
                  vm.roomData = data;
                  // console.error("进入队列", i);
                  if (i === len - 1) {
                    vm.intoroomlist = [];
                    vm.timer = false;
                  }
                  setTimeout(() => {
                    // console.error("队列结束");
                    vm.roomData = null;
                  }, 1000);
                };
              })(list[i], i, len, this),
              (i + 1) * 2000
            );
          }
          this.timer = true;
        }
      }
    },
    getShoping(nv, ov) {
      // this.intoroomlist.some((item) => {
      //   return item.xid == nv.xid
      // })
      if (this.timerShop) {
        // 添加到缓存数组中
        if (!this.shoplist.some((item) => {
            return item.nickname == nv.nickname
          })) {
          this.shoplist.push(nv);
        }
      } else {
        // 设置当前数据
        this.shopData = nv;
        this.timerShop = true;
        setTimeout(() => {
          this.shopData = null;
          this.timerShop = false;
        }, 1000);
      }
    },
    shopData(nv, ov) {
      let i = 0,
        list = this.shoplist,
        len = this.shoplist.length;
      if (!nv && !this.timerShop) {
        // 当前没有数据的时候，如果数组不为空则循环缓存数组
        if (len > 0) {
          for (i; i < len; i++) {
            let data = list[i];
            setTimeout(
              (function (timerShop, i, len, vm) {
                return function () {
                  vm.shopData = data;
                  // console.error("进入队列", i);
                  if (i === len - 1) {
                    vm.shoplist = [];
                    vm.timerShop = false;
                  }
                  setTimeout(() => {
                    // console.error("队列结束");
                    vm.shopData = null;
                  }, 1000);
                };
              })(list[i], i, len, this),
              (i + 1) * 2000
            );
          }
          this.timerShop = true;
        }
      }
    },
  },
  mounted() {
    this.isWx = this.getIsWxClient();
    this.chatInfo()
  }
};
</script>

<style lang="less" scoped>
html {
  &::-webkit-scrollbar {
    width: 0;
  }
}

.mod_chat_hall {
  position: relative;

  &.red {
    background: url(~@/assets/images/live-v3/newyaers.png) no-repeat;
    background-size: cover;
    top: -1px;

    .mod_chat_list {
      .pub_msg {
        background: rgba(0, 0, 0, .16);

        &.role {
          background: rgba(0, 0, 0, .16);
          border: none;

          .avatar {
            border: 1px solid rgba(255, 205, 68, 1);
          }

          .nickname {
            color: #44FFE6 !important;
          }
        }

        .chat_right {
          .chat_head_com {
            color: #ffffff;
          }
        }
      }
    }

    .into_msg {
      .into_msg_warp {
        background: linear-gradient(270deg, rgba(255, 162, 55, .8) 0%, rgba(255, 83, 64, .8) 100%);
        box-shadow: 0px 3px 6px rgba(45, 171, 255, 0.16);
        // opacity: 0.8;
        border-radius: .6rem/2;
      }
    }
  }

  // overflow: hidden;
  &.coures_mod {
    top: 70% !important;

    .avatar {
      width: 0.84rem/2 !important;
      height: 0.84rem/2 !important;
    }

    .chat_head_com {
      font-size: 12px !important;

      /deep/img {
        width: 26px !important;
        height: 26px !important;
      }
    }

    .pub_msg {
      padding: 5px 8px 5px 5px !important;
    }

    .mod_chat_list {
      -webkit-mask-image: -webkit-gradient(linear, center top, center bottom, color-stop(0, transparent), color-stop(.3, #000), color-stop(1, #000));
    }
  }

  &.full_mode {
    position: absolute;
    top: 60%;
    left: 0;
    right: 0;
    bottom: 1.2rem;

    .mod_chat_list {
      height: 100%;
      -webkit-mask-image: -webkit-gradient(linear, center top, center bottom, color-stop(0, transparent), color-stop(.3, #000), color-stop(1, #000));

      // &::before{
      //   content: "";
      //   position: absolute;
      //   top: 0;
      //   width: 100%;
      //   height: 1.2rem/2;
      //   box-shadow:  0px 20px 10px rgba(0,0,0,0.9);
      // }
      .pub_msg {
        background: rgba(0, 0, 0, .3);

        &.role {
          // background: rgba(255, 205, 68, 0.3);
          // border: 1px solid rgba(255, 205, 68, 1);
          background: rgba(150, 106, 255, 0.5);
          border: 1px solid rgba(108, 46, 255, 1);

          .avatar {
            border: 1px solid rgba(255, 205, 68, 1);
          }

          .nickname {
            color: #44FFE6 !important;
          }
        }
      }

      .chat_head_com {
        color: #ffffff !important;

        /deep/img {
          max-width: 100%;
        }
      }

      .reward_getlist {
        background: none !important;
      }

      .reward_zhubo_msg {
        background: rgba(255, 255, 255, .9);
        border-radius: 8px/2 !important;
      }
    }

    .into_msg {
      top: 0;
      transform: translateY(-200%);

      .into_msg_warp {
        background: linear-gradient(270deg, rgba(255, 162, 55, .8) 0%, rgba(255, 83, 64, .8) 100%);
        box-shadow: 0px 3px 6px rgba(45, 171, 255, 0.16);
        // opacity: 0.8;
        border-radius: .6rem/2;
      }
    }
  }

  .chat-item {
    text-align: left;
    margin-bottom: .2rem/2;

    &:nth-of-type(1) {
      margin-top: .2rem/2;
    }
  }

  .mod_chat_list {
    overflow-y: scroll;
    overflow-x: hidden;
    // position: relative;

    -webkit-overflow-scrolling: touch;

    &::-webkit-scrollbar {
      width: 0;
    }

    // background-color: #f2f2f2;
    padding: 0 .4rem 0 .4rem/2;
    margin-right: -.4rem/2;
    line-height: 0;

    .tips {
      position: absolute;
      bottom: .2rem;
      left: 0.2rem;
      z-index: 100;
      padding: 0 .2rem;
      height: 1.32rem/2;
      font-size: 16px;
      background: #FFFFFF;
      color: #FF5454;
      line-height: 1.32rem/2;
      border-radius: 0.42rem;
      box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
      text-align: center;
    }

    .pub_msg {
      max-width: 10.48rem/2;
      background: #F2F4F6;
      border-radius: .84rem/2;
      display: inline-flex;
      padding: .2rem/2 .4rem/2 .2rem/2 .28rem/2;

      &.role {
        background: rgba(255, 250, 238, 1);
        border: 1px solid rgba(255, 205, 68, 1);

        .avatar {
          border: 1px solid rgba(255, 205, 68, 1);
        }

        .nickname {
          color: #44FFE6 !important;
        }
      }

      .avatar_warp {
        flex: none;
        position: relative;
      }

      .avatar {
        // flex: none;
        width: 0.42rem;
        height: 0.42rem;
        margin: 0;
        border-radius: 50%;
        // margin-right: 0;
        // margin-left: auto;
        // vertical-align: top;
      }

      .role_icon {
        display: inline-block;
        width: .5rem/2;
        height: .5rem/2;
        background: url(~@/assets/images/live-v3/role.png) no-repeat;
        background-size: 100% 100%;
        position: absolute;
        top: -2px;
        right: 0;
      }

      .chat_right {
        flex: 1;
        display: inline-flex;
        align-items: center;

        .chat_time {
          padding-left: 0;
          color: #ececec;
        }

        margin-left: 0;

        .chat_head_com {
          padding: 0 0 0 7px;
          color: #4D5358;
          font-size: 14px;
          line-height: 1.5em;
          word-break: break-all;

          .nickname {
            color: #FFCD44;
            font-weight: bold;
            // vertical-align: super;
          }

          /deep/.reply {
            color: #4D5358;
          }

          /deep/img {
            max-width: 100%;
          }

          .chat_time {
            color: rgba(125, 138, 148, 1);
            font-size: 14px;
          }

          /deep/.emoji_img {
            width: 30px;
            height: 30px;
            vertical-align: middle;
          }
        }
      }

      .reward_bg {
        width: 4.36rem;
        height: 1.74rem;
        background: url(~@/assets/images/live-v3/redpack_bg.png) no-repeat;
        background-size: 100%;
        transition: 0.3s;

        &:active {
          transform: scale(0.9);
        }

        &.get {
          opacity: 0.5;
        }

        .reward_title {
          color: rgba(255, 255, 255, 1);
          font-weight: bold;
          height: 1.2rem;
          margin-left: 0.9rem;
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          padding-top: 0.4rem;
          box-sizing: border-box;
          font-size: 14px;

          span {
            display: block;
          }

          &.get {
            padding-top: 0.2rem;
          }
        }

        .reward_type {
          height: 0.5rem;
          line-height: 0.5rem;
          margin-left: 12px;
          color: rgba(198, 205, 210, 1);
          font-size: 12px;

          &.get {
            vertical-align: -10px;
          }
        }
      }

      .chat_detail {
        margin: 0;
        margin-left: 10px;
        padding: 0.14rem 0.3rem;
        // border-radius: .4rem;
        font-size: 14px;
        background-color: rgba(255, 255, 255, 1);
        color: rgba(67, 79, 88, 1);

        img {
          width: 100%;
          height: 2.3rem;
          object-fit: cover;
          border-radius: 5px;
        }

        /deep/.emoji_img {
          width: 30px;
          height: 30px;
          vertical-align: bottom;
        }

        &.image {
          padding: 0 !important;
          margin-left: 5px;
          background: none !important;

          &::after {
            display: none;
          }
        }

        &::after {
          display: none;
          content: "";
        }
      }
    }

    .reward_msg {
      &.get {
        background: none;
      }

      .chat_right {
        display: block;
      }

      .reward_getlist {
        text-align: center;
        // margin-top: 10px;
        color: rgba(198, 205, 210, 1);
        font-size: 12px;
        background: #F2F4F6;
        // padding: .2rem/2 .4rem/2;
        // border-radius: .84rem/2;
        display: inline-flex;
        align-items: center;

        .getlist_icon {
          display: inline-block;
          width: 18px;
          height: 22px;
          background: url(~@/assets/images/reward_msg_ico.svg) no-repeat;
          background-size: 100% 100%;
          // vertical-align: -0.12rem;
        }
      }
    }

    .reward_zhubo_msg {
      text-align: center;
      padding: 5px 0;
      white-space: normal;
      display: inline-block;

      // position: relative;
      .inner_warp {
        display: inline-flex;
        flex-wrap: wrap;
        line-height: 1.5em;
        // position: absolute;
        // background: rgba(255, 255, 255, .9);
        padding: 0px 12px;
        font-size: 14px;
        border-radius: 8px;
        color: #434f58;

        .nickname {
          color: #FFB444;
        }

        .pirce {
          color: #FF4141;
        }
      }
    }
  }

  .into_msg {
    position: absolute;
    top: 10px;
    left: 10px;
    height: 30px;
    width: 206px;
    overflow: hidden;

    &.shop {
      width: 6.6rem/2;
      top: 16px;
      transform: translateY(-100%);

      .into_msg_warp {
        background: linear-gradient(270deg, rgba(255, 90, 141, .8) 0%, rgba(249, 36, 94, .8) 100%);
        box-shadow: 0px 3px 6px rgba(45, 171, 255, 0.16);

        .avatar {
          width: .72rem/2;
          height: .64rem/2;
          background: url(~@/assets/images/live-v3/shop.png) no-repeat;
          background-size: 80% 80%;
          background-position: center center;
        }

        .msg_placeholder {
          width: auto;
          margin-left: 5px;
        }
      }
    }

    // display: flex;
    .into_msg_warp {
      // position: absolute;
      // height: 30px;
      // top: 10px;
      // left: 10px;
      // flex: 1;
      font-size: 14px;
      color: #ffffff;
      height: 30px;
      padding: 0 10px 0 6px;
      display: flex;
      align-items: center;
      text-align: center;
      background: linear-gradient(270deg,
          rgba(80, 231, 255, 0.8) 0%,
          rgba(64, 179, 255, 0.8) 100%);
      box-shadow: 0px 3px 6px rgba(45, 171, 255, 0.16);
      border-radius: 5px;
      position: absolute;
      max-width: 380px/2;
      line-height: 30px;

      .avatar {
        flex: none;
        width: 25px;
        height: 25px;
        border-radius: 50%;
        overflow: hidden;

        img {
          width: 100%;
          height: 100%;
        }
      }

      .msg {
        // flex: none;
        height: 100%;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        padding-left: 5px;
      }

      .msg_placeholder {
        flex: none;
        width: 32px;
      }
    }
  }

  .tips {
    position: absolute;
    bottom: .2rem;
    left: 0.2rem;
    z-index: 100;
    padding: 0 .2rem;
    height: 1.32rem/2;
    font-size: 16px;
    background: #FFFFFF;
    color: #FF5454;
    line-height: 1.32rem/2;
    border-radius: 0.42rem;
    box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
    text-align: center;
  }

  .fade-enter-active,
  .fade-leave-active {
    transition: 0.5s;
  }

  .fade-enter {
    transform: translate(-100%, 0);
  }

  .fade-enter-to {
    transform: translate(0, 0);
  }

  .fade-leave {
    opacity: 1;
  }

  .fade-leave-to {
    opacity: 0;
  }
}
</style>
