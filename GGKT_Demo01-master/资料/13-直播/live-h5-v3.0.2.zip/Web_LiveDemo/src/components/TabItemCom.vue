<template>
<section class="mod_modules" :class="{modepage:getPageModel == 0 && getActModule === 'chat'}">
  <!-- @聊天 -->
  <keep-alive>
    <chat-view v-if="getActModule === 'chat'" @Tabup="doUp"></chat-view>
  </keep-alive>
  <!-- 提问 -->
  <keep-alive>
    <question-view v-if="getActModule === 'question'&&getPageModel!=1"></question-view>
  </keep-alive>
  <!-- @邀请排行榜 -->
  <rank-view v-show="getActModule === 'invite' && getConfig && getConfig.global.setting.pageViewMode == 0 && config('invite')"></rank-view>
  <!-- PPT模块 -->
  <div class="ppt" v-show="getActModule === 'courseware' && config('courseware')" v-if="getPageModel!=2">
    <div id="ht_course_container"></div>
  </div>
  <!-- @自定义模块 -->
  <template v-for="(item,index) in getConfig.content.tabsData">
    <div :key="index" v-html="item.content" class="tab_content" v-if="!(item.type==='chat'||item.type==='invite'||item.type==='courseware')&&getActModule === (item.title+index)" @click="goLink($event)"></div>
  </template>
  <!-- 暂无数据 -->
  <div class="no_data" v-if="nodata()&&!timerCountFlag">
    <span class="tip">暂无数据</span>
  </div>
  <!-- 商城 -->
  <!-- <product-view :class="{producUp:producUp,no_chat:!config('chat')}" v-if="(getConfig && getConfig.global.setting.pageViewMode == 0 || isVod) && getConfig.global.switch.store.enable == 1 " :popShow="producUp"></product-view> -->
  <!-- 推荐商品弹出 -->
  <product-pop class="half" v-if="getConfig && getConfig.global.setting.pageViewMode == 0 && !isVod && getConfig.global.switch.store.enable == 1"></product-pop>
  <!-- 私聊 -->
  <!-- <private-chat :class="{Up:privateChatUp}" :popShow="privateChatUp" v-if="getConfig && getConfig.global.setting.pageViewMode == 0 && !isVod && getConfig && getConfig.global.switch.service && getConfig.global.switch.service.enable == 1"></private-chat> -->
  <!-- #滚动通知 -->
  <scroll-notice-view v-if="getConfig && getConfig.global.setting.pageViewMode == 0"></scroll-notice-view>
</section>
</template>

<script>
// import ChatView from "./mod-company/ChatCom";
import RankView from "./RankView"
import fixOverflowScroll from "fix-overflow-scroll"
import ScrollNoticeView from "./ScrollNoticeView"
import ProductView from "./ProductView"
import TimerCount from "./TimerCount"
import PrivateChat from "./PrivateChat"
import ProductPop from './ProductPop'
import ChatView from "./ChatView"
import QuestionView from './QuestionView'
import {
  mapGetters
} from "vuex";
export default {
  data() {
    return {
      producUp: false,
      privateChatUp: false,
      timerCountFlag: false,
      isVod: window.isVod && window.isVod == 1 ? true : false,
      num: 0
    };
  },
  computed: {
    ...mapGetters([
      "getActModule",
      "getVideoMode",
      "getVotePopStatus",
      "getTabInfo",
      "getPageModel",
      "getModeSwitch",
      "getLiveState",
      "getConfig",
      "getProductIdList"
    ]),
    showPlayer() {
      if (this.getVotePopStatus === "open") {
        return false;
      }

      if (this.getVideoMode === 2 && this.getActModule === "video") {
        return true;
      }

      if (this.getVideoMode === 0 && this.getActModule === "chat") {
        return true;
      }

      return false;
    },
    modModulesClass() {
      if (this.getVideoMode === 2 && this.getActModule === "video") {
        return "flex_center";
      }
      return "";
    }
  },
  components: {
    ChatView,
    RankView,
    ScrollNoticeView,
    ProductView,
    TimerCount,
    PrivateChat,
    ProductPop,
    QuestionView
  },
  methods: {
    Info() {
        this.$nextTick(() => {
          // 二分屏 计算聊天区高度
          if (this.getPageModel != 1) {
            var mod_modules_wrap = this.jquery(".mod_modules");
            var mod_modules_wrap_height =
              this.jquery(document).height() - this.jquery("#warp_top").height();
            mod_modules_wrap.css("height", mod_modules_wrap_height + "px");
          }
        });
    },
    goLink(event) {
      let url = event.target.href || event.target.parentElement.href || ''
      event.stopPropagation()
      event.preventDefault()
      if (url.match(/\[wx\]/)) {
        url = url.substr(url.indexOf('//')+2).replace('[wx]', '')
        if (window.wx) {
          window.wx.miniProgram.navigateTo({
            url: url
          })
        }
        return false
      }
      if(url!==''){
        window.location.href = url
      }
      return false
    },
    doUp(up) {
      if (up === 'produc') {
        this.producUp = true;
        return
      }
      if (up === 'private_chat') {
        this.privateChatUp = true
      }
    },
    config(type) {
      let flag = false;
      if (this.getConfig) {
        this.getConfig.content.tabsData.forEach((item) => {
          if (item.type === type) {
            flag = true
          }
        })
      }
      return flag
    },
    nodata() {
      let flag = false;
      let curtab = this.getActModule
      curtab === '' ? flag = true : flag = false;
      return flag
    },
    showtime(flag) {
      this.timerCountFlag = flag;
    },
  },
  watch: {
    getActModule(nd, od) {
      if (nd === "courseware") {
        setTimeout(() => {
          if (document.getElementById("canvas-container-inner")) {
            this.HTSDK.playerResize();
          }
        }, 0);
      }
    }
  },
  mounted() {
    this.Info()
  }
};
</script>

<style lang="less">
.mod_modules {
  &.modepage {
    overflow: visible;
  }

  // position: absolute;
  width: 100%;
  height: 100%;
  // min-height: 300px;
  // top:6.4rem;
  // bottom: 0;
  overflow-y: scroll;
  -webkit-overflow-scrolling: touch;
  overflow-x: hidden;
  // position: absolute;
  // bottom: 0;
  background: #ffffff;
  // border-top: 1px solid rgba(0, 0, 0, 0.08);
  border-top: 1px solid #EBEFF2;
  // overflow: auto;

  .ppt {
    height: 100%;
    background: rgba(238, 240, 242, 1);
    overflow: hidden;
    #ht_course_container{
      height: 100%;
    }
  }

  .tab_content {
    font-size: 14px;
    padding: 0;
    // height: 100%;
    box-sizing: border-box;
    background: rgba(238, 240, 242, 1);
    min-height: 100%;
    // -webkit-overflow-scrolling: touch;
    // overflow-y: scroll;
    // overflow-x: hidden;
    p{
      margin: 0;
    }
    img {
      width: 100%;
    }
  }

  .no_data {
    position: absolute;
    width: 100px;
    height: 120px;
    background: url(../assets/images/live/rankdate.svg) no-repeat;
    background-size: 100%;
    top: 1.5rem;
    left: 0;
    right: 0;
    margin: auto;

    .tip {
      width: 100%;
      text-align: center;
      position: absolute;
      font-size: 16px;
      color: rgba(158, 176, 196, 1);
      bottom: -10px;
    }
  }
}
</style>
