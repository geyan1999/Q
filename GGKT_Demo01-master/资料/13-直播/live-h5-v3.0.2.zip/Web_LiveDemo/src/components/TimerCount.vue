<template>
<div class="timer_count" :class="{full:getPageModel!=0,half:getPageModel==0,red:styleRed}" v-show="(getLiveState==='wait'&&show)">
  <div class="bg_icon"></div>
  <div class="_tip">{{getPageModel!=0?'距离直播还有':'直播倒计时:'}}</div>
  <div class="_time">{{totalTimer|formatTimer}}</div>
  <!-- <div class="_time">00 分 00 秒</div>  -->
</div>
</template>

<script>
import {
  mapGetters
} from "vuex";
import * as TYPES from "@/assets/action-types";
export default {
  data() {
    return {
      timer: false,
      totalTimer: 0,
      show: false,
      isVod: window.isVod && window.isVod == 1 ? true : false,
    };
  },
  filters: {
    formatTimer(value) {
      var secondTime = parseInt(value); // 秒
      var minuteTime = 0; // 分
      var hourTime = 0; // 小时
      var day = 0;
      if (secondTime > 60) {
        //如果秒数大于60，将秒数转换成整数
        //获取分钟，除以60取整数，得到整数分钟
        minuteTime = parseInt(secondTime / 60);
        //获取秒数，秒数取佘，得到整数秒数
        secondTime = parseInt(secondTime % 60);
        //如果分钟大于60，将分钟转换成小时
        if (minuteTime > 60) {
          //获取小时，获取分钟除以60，得到整数小时
          hourTime = parseInt(minuteTime / 60);
          //获取小时后取佘的分，获取分钟除以60取佘的分
          minuteTime = parseInt(minuteTime % 60);
        }
        // console.error(hourTime)
        if (hourTime >= 24) {
          //获取天数，获取小时除以24，得到整数天数
          day = parseInt(hourTime / 24);
          //获取天输后取佘的小时，获取天数除以24取佘的小时
          hourTime = parseInt(hourTime % 24);
          // console.error(day,hourTime)
        }
      }
      var result = " " + parseInt(secondTime) + " 秒";

      if (minuteTime > 0) {
        result = " " + parseInt(minuteTime) + " 分" + result;
      } else {
        // result = " " + "00" + "分" + result;
      }
      if (hourTime > 0) {
        result = " " + parseInt(hourTime) + " 时" + result;
      } else {
        // result = " " + "00" + "时" + result;
      }
      if (day > 0) {
        result = " " + parseInt(day) + " 天" + result;
      } else {
        // result = " " + "00" + "天" + result;
      }

      return result;
    }
  },
  computed: {
    ...mapGetters(["getPageModel", "getCouresTime", "getConfig", "getLiveState", "getHtData"]),
    pid() {
      if (this.isVod) {
        if (this.getHtData && this.getHtData.pid) {
          return this.getHtData.pid
        }
      } else {
        if (this.getHtData && this.getHtData.zhubo && this.getHtData.zhubo.partner_id) {
          return this.getHtData.zhubo.partner_id
        }
      }
      return 0
    },
    styleRed() {
      let pids = window.annual_config_pid || []
      return pids.some((pid) => {
        return pid == this.pid
      }) && this.getPageModel == 0
    }
  },
  methods: {
    upTiem() {
      this.timer = setInterval(() => {
        if (this.totalTimer == 0) {
          clearInterval(this.timer);
          this.timer = null;
          this.show = false
          this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
            type: 'time',
            flag: false
          })
        }
        this.totalTimer -= 1;
      }, 1000);
    }
  },
  watch: {
    getLiveState(nv, ov) {
      if (nv !== 'wait') {
        this.show = false
        this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
          type: 'time',
          flag: false
        })
      }
    }
  },
  mounted() {
    let curtime = parseInt(new Date().getTime() / 1000);
    let startime = parseInt(this.getCouresTime);
    // console.error("当前时间",curtime,"开始时间",startime)
    if (this.getConfig) {
      if (this.getConfig.global.switch.countDown.enable == 1) {
        if (startime > curtime) {
          // console.error("计时")
          this.totalTimer = parseInt(this.getCouresTime) - curtime;
          this.upTiem();
          this.show = true
          this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
            type: 'time',
            flag: true
          })
        }
      }
    }
  }
};
</script>

<style lang="less" scoped>
.timer_count {
  width: 8.8rem/2;
  height: 5.6rem/2;
  background: rgba(255, 255, 255, 0.6);
  border-radius: 0.24rem/2;
  text-align: center;
  position: absolute;
  z-index: 0;
  color: #5da8bf;

  // top: 0;
  // bottom: 1rem;
  // left: 0;
  // right: 0;
  // margin: auto;

  &.no_chat {
    top: 5rem;
  }

  &.full {
    top: 0;
    bottom: 2rem;
    left: 0;
    right: 0;
    margin: auto;
    background: none;
    color: #b1d1f8;

    .bg_icon {
      background: url(../assets/images/live-v2/timer.svg) no-repeat;
      background-size: contain;
      background-position: center center;
    }
  }

  &.half {
    // width: 11.2rem/2;
    width: auto;
    height: 1.4rem/2;
    background: linear-gradient(180deg, rgba(97, 217, 255, 1) 0%, rgba(1, 194, 255, 1) 100%);
    box-shadow: 0px 4px 6px rgba(1, 194, 255, 0.4);
    opacity: 1;
    border-radius: 1.2rem/2;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    display: inline-flex;
    align-items: center;
    padding: 0 .72rem/2;
    justify-content: space-between;
    color: #ffffff;

    .bg_icon {
      width: .7rem/2;
      height: .7rem/2;
      background: url(../assets/images/live-v2/timer3.png) no-repeat;
      background-size: contain;
      background-position: center center;
      margin: 0 5px 0 0;
    }

    ._tip {
      margin: 0;
      font-size: 14px;
      white-space: nowrap;
    }

    ._time {
      font-size: 14px;
      white-space: nowrap;
    }
  }

  &.red {
    background: #FFCD8B;
    box-shadow: 0px 4px 6px rgba(255, 205, 139, 0.4);
    color: #AF302C;
  }

  .bg_icon {
    width: 1.4rem/2;
    height: 1.4rem/2;
    margin: 0.6rem/2 auto 0.4rem/2;
    background: url(../assets/images/live-v2/timer2.svg) no-repeat;
    background-size: contain;
    background-position: center center;
  }

  ._tip {
    font-size: 32px/2;
    margin-bottom: 0.48rem/2;
  }

  ._time {
    font-size: 36px/2;
  }
}
</style>
