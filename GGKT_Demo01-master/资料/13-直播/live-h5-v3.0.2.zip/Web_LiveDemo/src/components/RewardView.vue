<template>
<div @click.stop="">
  <!-- 发红包 -->
  <div v-if="getRewardState == 1" class="reward_send">
    <div class="reward-wp">
      <div class="title">
        <div class="back" @click.stop="back('invant_card')">
          <x-icon type="ios-arrow-back"></x-icon>
          <i>返回</i>
        </div>发红包
      </div>
      <div class="reward_item">
        <div class="error_tip" v-if="overAmount||overMoney">
          <div v-if="overMoney" class="error_money">{{type===1?'单次支付总额不可超过20000':'单个红包金额不超过200'}}</div>
          <div v-if="overAmount" class="error_amount">一次最多可发100个红包</div>
        </div>
        <div class="reminder">
          <span>{{type===1?'当前为随机红包':'当前为普通红包'}}</span>
          <span class="red_type" @click.stop="type===1?type=2:type=1">{{type===1?'改为普通红包':'改为随机红包'}}</span>
        </div>
        <div class="item_wp">
          <div class="item" :class="{error:overMoney}">
            <span>
              <span class="reward_icon" v-if="type===1"></span>
              {{type===1?"总金额":"单个金额"}}
            </span>
            <div class="item_input">
              <input type="text" placeholder="0.00" maxlength="8" @blur="onBlur" v-model="money" @input="checkInput('money',$event)" />
              <span>元</span>
            </div>
          </div>

          <div class="item" :class="{error:overAmount}">
            <span>红包个数</span>
            <div class="item_input">
              <input type="text" placeholder="填写个数" :maxlength="getPid==13573||getPid==11306?10:3" v-model="amount" @blur="onBlur" @input="checkInput('amount',$event)" />
              <span>个</span>
            </div>
          </div>

          <div class="item">
            <span>主题</span>
            <div class="item_input descript">
              <textarea maxlength="25" placeholder="恭喜发财，大吉大利" rows="2" v-model.trim="title" @blur="onBlur" @keydown.enter="checkInput('title',$event)"></textarea>
            </div>
          </div>
        </div>
      </div>
      <p class="reward_count">￥{{curmoney | renderMoney}}</p>
      <div id="send_redpack_dom" @click="sendReward" :class="{send:sendFlag}">塞钱进红包</div>
    </div>
  </div>
  <!-- 红包详情 -->
  <div v-if="getRewardState == 3" class="reward_details">
    <div class="_title" @click.stop="back('reward_details')">
      返回直播
      <br />
      <span class="back"></span>
    </div>
    <div class="reward-wp">
      <div class="bg_top">
        <div class="radius"></div>
        <div class="content">
          <img :src="getAvatar(getReward.reward.user)" alt class="avatar" />
          <div class="name">{{getReward.reward.nickname}}</div>
          <div class="descript">{{getReward.reward.title}}</div>
          <div class="count" v-if="getReward.data.money != 0">￥ {{getReward.data.money}}</div>
          <div class="count" v-if="getReward.data.money == 0">未抢到红包</div>
          <!-- <div class="count" v-if="getReward.hasget">已领完</div>
            <div class="count" v-if="getReward.isget">已领取</div>
            <div class="count" v-if="getReward.isend">红包已过期</div>-->
        </div>
      </div>
      <div class="list">
        <div class="total" v-if="getPid!=13573">已领取{{getReward.data.receivedCount}}/{{getReward.data.hongbaoCount}}个,共{{getReward.data.decreaseMoney}}/{{getReward.data.moneyTotal}}元</div>
        <ul>
          <li v-for="(item, index) in getReward.data.list" :key="index">
            <img :src="getAvatar(item)" alt class="avatar" />
            <div class="list_content">
              <span class="name">{{item.nickname}}</span>
              <span class="count">{{getPid==13573?'已领取':item.money}}</span>
              <span class="time">{{item.time | getTime}}</span>
            </div>
          </li>
        </ul>
        <div class="reminder">未被领取的红包将24小时内退款</div>
      </div>
    </div>
  </div>
  <!-- 历史红包 -->
  <div v-if="getRewardState==4" class="reward_list">
    <div class="title">
      <div class="back" @click.stop="back('invant_card')">
        <x-icon type="ios-arrow-back"></x-icon>
        <i>返回</i>
      </div>历史红包
    </div>
    <div class="reward-wp">
      <ul>
        <li v-for="(item, index) in getListReward.data" :key="index">
          <div @click.stop="doCheck($event,{nickname:item.nickname,avatar:item.avatar,title:item.title,hid:item.hid,user:item},item.hid)">
            <img src="../assets/images/reward_msg_ico.svg" alt="123" class="avatar" />
            <div class="list_content">
              <span class="name">{{item.title}}</span>
              <span class="count" v-if="item.status==0">领取</span>
              <span class="end" v-if="item.status==601"></span>
              <span class="get" v-if="item.status==602"></span>
              <span class="none" v-if="item.status==600"></span>
              <span class="time">{{item.time}}</span>
            </div>
          </div>
        </li>
      </ul>
      <div class="reminder" v-if="getListReward.page === getListReward.total && getListReward.data.length !==0">没有更多红包</div>
      <div class="reminder" v-if="getListReward.page !== getListReward.total && getListReward.data.length !==0" @click.stop="viewListMore()">查看更多红包</div>
      <div class="reminder" v-if="getListReward.data.length==0">暂无红包记录</div>
    </div>
  </div>
  <!-- 打开红包 -->
  <div v-show="getRewardState == 2" class="reward_open">
    <div class="reward-wp">
      <div class="reward_bg">
        <div v-if="getOpenReward.reward">
          <img class="avatar" :src="getAvatar(getOpenReward.reward.user)" />
          <div class="name">{{getOpenReward.reward.nickname}}的红包</div>
          <div class="descript">{{getOpenReward.reward.title}}</div>
        </div>
        <div class="open_cion" @click.stop="robReward(getOpenReward.reward)" v-if="!getOpenReward.hasget&&!getOpenReward.isget&&!getOpenReward.isend">
          <span>拆</span>
        </div>
        <div class="over" v-if="getOpenReward.hasget">已领完</div>
        <div class="over" v-if="getOpenReward.isget">已领取</div>
        <div class="over" v-if="getOpenReward.isend">红包已过期</div>
        <div class="look_more" @click.stop="viewReward(getOpenReward.reward,null)">查看大家运气 ></div>
        <div class="reward_close" @click.stop="changeRewardState(0)"></div>
      </div>
    </div>
  </div>
  <!-- 红包提现 -->
  <div v-if="getRewardState == 5" class="reward_cash">
    <div class="reward-wp">
      <div class="cash_content">
        <div class="title">
          <div class="back" @click.stop="back('invant_card')">
            <x-icon type="ios-arrow-back"></x-icon>
            <i>返回</i>
          </div>我的钱包
        </div>
        <div class="cash_details">
          <span @click.stop="getCachList(1)">明细</span>
        </div>
        <div class="cash_money">
          <div class="icon">￥</div>
          <p class="balance_title">余额 （元）</p>
          <p class="balance">{{getCashReward.balance}}</p>
          <span>（单次提现金额至少1元，提现1-3个工作日内到账）</span>
        </div>
        <div class="cash_submit">
          <button @click.stop="cashConfimr()" :class="{disabled:cashState}">{{cashInfo}}</button>
        </div>
      </div>
      <div class="cash_attention" @click.stop="choose=!choose">
        关于提现的注意事项
        <x-icon type="ios-arrow-back" class="back" :class="{choose:choose}"></x-icon>
      </div>
      <div class="cash_help" :class="{show:choose}" v-if="!cash_confimr">
        <p>常见问题：</p>
        <div class="help_content">
          <div>1、提现的钱什么时候到账？</div>
          <div class="help_item">
            <div class="placeholder">1、</div>
            <div class="text">提现的钱将于确认提现后的1~3工作日内到您的微信钱包中，微信钱包需要绑定银行卡，金额才能到账。</div>
          </div>
        </div>

        <div class="help_content">
          <div>2、每天提现的次数有限制么？</div>
          <div class="help_item">
            <div class="placeholder">2、</div>
            <div class="text">每个观众24小时内只可发起一次提现申请。</div>
          </div>
        </div>

        <div class="help_content">
          <div>3、余额的钱与提现中的钱有什么区别？</div>
          <div class="help_item">
            <div class="placeholder">2、</div>
            <div class="text">每次提现都是将当前观众余额中的所有额度进行提现，然后余额清零，系统在处理提现期间，观众抢到新红包的钱会照常进入余额中。</div>
          </div>
        </div>

        <div class="help_content">
          <div>4、为什么提现失败？</div>
          <div class="help_item">
            <div class="placeholder">2、</div>
            <div class="text">观众的微信号没有进行实名认证或微信服务异常问题，会导致提现失败。</div>
          </div>
        </div>

        <div class="help_content">
          <div>5、其他疑惑？</div>
          <div class="help_item">
            <div class="placeholder">2、</div>
            <div class="text">用户出现提现失败，或其他任何疑问，请联系在线客服处理或联系直播发起方寻求帮助。</div>
          </div>
        </div>
      </div>
      <div class="cash_confimr_warp" v-if="cash_confimr">
        <div class="title">
          <x-icon type="ios-arrow-back" class="back" @click.stop="cash_confimr=!cash_confimr"></x-icon>提现
        </div>
        <div class="cash_confimr">
          <div class="top">
            <div class="left">提现到：</div>
            <div class="right">
              <span class="cash_icon"></span>
              零钱
              <br />
              <span class="cash_title">1~3个工作日内到账</span>
            </div>
          </div>
          <div class="money">￥{{getCashReward.balance}}</div>
          <div class="line"></div>
          <div class="service">
            <span>服务费</span>
            <span class="_tip">￥{{getCashReward.balance|rate}}</span>
          </div>
          <div class="rate">
            <span>费率</span>
            <span class="_tip">0.60%</span>
          </div>
          <div class="confimr_submit">
            <button @click.stop="cashReward(getCashReward.withdraw_url)">提现</button>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- 零钱明细 -->
  <div v-if="getRewardState == 6" class="reward_account">
    <div class="reward-wp">
      <div class="title">
        <div class="back" @click.stop="back('invant_card')">
          <x-icon type="ios-arrow-back"></x-icon>
          <i>返回</i>
        </div>零钱明细
      </div>
      <div class="list">
        <ul>
          <li v-for="(item, index) in getCashDetail.data" :key="index">
            <div class="list_content">
              <span class="name">{{item.title}}</span>
              <span class="count" :class="{income:item.type == 1}">{{item.type == 1 ? "+" + item.money : "-" + item.money}}</span>
              <span class="time">{{item.time | getTime}}</span>
            </div>
          </li>
        </ul>
        <div class="reminder" v-if="getCashDetail.page === getCashDetail.total && getCashDetail.data.length !==0">没有更多记录</div>
        <div class="reminder" v-if="getCashDetail.page !== getCashDetail.total && getCashDetail.data.length !==0" @click.stop="getCachList(getCashDetail.page+1)">查看更多记录</div>
        <div class="reminder" v-if="getCashDetail.data.length==0">暂无记录</div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
import * as TYPES from "@/assets/action-types";
import * as tools from "@/assets/js/util";
import {
  isMe
} from "../assets/js/util";
export default {
  name: "RewardView",
  data() {
    return {
      money: "",
      amount: "",
      title: "",
      sendFlag: false,
      overMoney: false,
      overAmount: false,
      choose: true,
      cash_confimr: false,
      type: 1,
      div: null,
      curmoney:0
    };
  },
  filters: {
    renderMoney(money) {
      if (money == "") {
        return "0.00";
      }
      var value = Math.round(parseFloat(money) * 100) / 100;
      var xsd = value.toString().split(".");
      if (xsd.length == 1) {
        value = value.toString() + ".00";
        return value;
      }
      if (xsd.length > 1) {
        if (xsd[1].length < 2) {
          value = value.toString() + "0";
        }
        return value;
      }
    },
    getTime(_time) {
      return tools.convertTimestamp(_time);
    },
    rate(money){
      return (Number(money)*0.006).toFixed(2) >= 0.01 ? (Number(money)*0.006).toFixed(2) : 0.01
    }
  },
  methods: {
    ...mapActions({
      send: "SEND_REWARD",
      get: "GER_REWARD",
      view: "VIEW_REWARD",
      more: "LIST_REWARD",
      check: "CHECK_REWARD",
      cash: "CASH_REWARD",
      lishCash: "DETAIL_REWARD"
    }),
    onBlur() {
      document.body.scrollTop = document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
      this.jquery("#app").scrollTop(0);
      this.jquery(document).scrollTop(0);
    },
    sendReward() {
      if (this.sendFlag) {
        let data = {
          liveid: this.liveid,
          money: this.curmoney,
          number: this.amount,
          title: this.title === "" ? "恭喜发财，大吉大利" : this.title,
          type: this.type
        };
        this.send({
          vm: this,
          data: data
        });
        this.loading();
      }
    },
    robReward(reward) {
      this.$store.commit("UPDATE_REWARD_HID", reward.hid);
      let data = {
        liveid: this.liveid,
        hid: this.getRewardCurhid
      };
      // console.log("抢红包请求参数", data);
      this.get({
        vm: this,
        data: data,
        reward: reward
      });
      this.loading();
    },
    viewReward(reward, _hid) {
      // console.log(reward);
      let data = {
        liveid: this.liveid,
        hid: _hid ? _hid : reward.hid
      };
      this.view({
        vm: this,
        data: data,
        reward: reward
      });
      this.loading();
    },
    viewListMore() {
      this.more({
        vm: this,
        data: {
          liveid: this.liveid,
          page: this.getListReward.page + 1
        }
      });
      this.$vux.loading.show({
        text: "Loading"
      });
    },
    checkReward(reward, _hid) {
      if (this.getRewardTimer || isMe(reward.user, this.getHtData.user)) {
        if (_hid) {
          this.hid = _hid;
        }
        this.check({
          vm: this,
          data: {
            liveid: this.liveid,
            hid: this.getRewardCurhid
          },
          reward: reward
        });
        this.loading();
      } else {
        this.$vux.toast.text("观看1分钟后才能参与红包领取", "bottom");
      }
    },
    checkInput(type, event) {
      // if(this.getPid == 13573 || this.getPid == 11306){
      //   this.overMoney = false
      //   this.overAmount = false
      //   this.sendFlag = true
      //   return
      // }
      if (type == "money") {
        let data = event.target.value
          .replace(/[^\d^\.]+/g, "")
          .replace(".", "$#$")
          .replace(/\./g, "")
          .replace("$#$", ".");
        this.div = event
        if (this.type === 2 && Number(this.amount) > 0) {
          this.curmoney = data * this.amount
          this.curmoney = this.curmoney.toFixed(2)
        } else {
          this.curmoney = this.money
        }
        // 合作商配置
        if(this.bigRedAmount){
          this.overAmount = false
          this.overMoney = false
          this.sendFlag = true
          return
        }
        if ((this.money > 20000 && this.type === 1) || (this.money > 200 && this.type === 2)) {
          this.overMoney = true;
          this.sendFlag = false;
        } else {
          this.overMoney = false;
          if (
            !this.overMoney &&
            !this.overAmount &&
            this.money != "" &&
            this.amount != ""
          ) {
            this.sendFlag = true;
          } else {
            this.sendFlag = false;
          }
        }
      } else if (type == "amount") {
        let _amount = event.target.value
          .replace(/[^\d^\.]+/g, "")
          .replace(".", "$#$")
          .replace(/\./g, "")
          .replace("$#$", ".");
          this.amount = Math.floor(_amount)
        if (this.type === 2) {
          this.curmoney = this.money * this.amount
          this.curmoney = this.curmoney.toFixed(2)
        }
        // 合作商配置
        if(this.bigRedAmount){
          this.overMoney = false
          this.overAmount = false
          this.sendFlag = true
          return
        }
        if (this.amount > 100) {
          this.overAmount = true;
          this.sendFlag = false;
        } else {
          this.overAmount = false;
          if (
            !this.overAmount &&
            !this.overMoney &&
            this.amount != "" &&
            this.money != ""
          ) {
            this.sendFlag = true;
          } else {
            this.sendFlag = false;
          }
        }
      } else if (type == "title") {
        event.preventDefault();
      }
    },
    cashConfimr() {
      if (this.cashInfo == "(至少1元)提现") {
        this.$vux.toast.text("余额不足1元", "middle");
      } else if (this.cashInfo == "提现中...") {
        this.$vux.toast.text("提现成功后,才能进行再次提现", "middle");
      } else {
        this.cash_confimr = true;
      }
    },
    cashReward(_url) {
      this.cash({
        vm: this,
        url: _url
      });
      this.loading();
    },
    getCachList(_page) {
      this.lishCash({
        vm: this,
        data: {
          page: _page
        }
      });
      // this.$vux.loading.show({
      //   text: "Loading"
      // });
      this.loading()
    },
    clearData() {
      this.money = "";
      this.title = "";
      this.amount = "";
      (this.sendFlag = false),
      (this.overMoney = false),
      (this.overAmount = false);
    },
    back(type) {
      if (type == "reward_list") {
        this.$store.commit(TYPES.UPDATE_REWARD_LIST, {
          show: false,
          vm: this
        });
        this.changeRewardState(0);
        this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 0);
      } else if (type == "reward_send") {
        this.clearData();
        this.changeRewardState(0);
        this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 0);
      } else if (type == "reward_details") {
        this.changeRewardState(0);
        this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 0);
      } else if (type == "reward_account") {
        this.changeRewardState(5);
      } else {
        this.changeRewardState(0);
        this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 0);
      }
    },
    changeRewardState(state) {
      this.$store.commit(TYPES.UPDATE_REWARD_STATUS, state);
      this.$store.commit(TYPES.UPDATE_REWARD_LIST, {
        show: false,
        vm: this
      });
    },
    loading() {
      // this.jquery("#loading").removeClass("hidden");
      this.$vux.loading.show({
        text: "Loading"
      });
    },
    getAvatar(_avatar) {
      // console.log(_avatar);
      if (!_avatar.a) {
        _avatar.a = 1;
      }
      let avaObj = this.HTSDK.getAvatar(_avatar);
      return avaObj.avatar;
    },
    doCheck(event, reward, hid) {
      let div = event.currentTarget;
      if (this.jquery(div).find(".count").length !== 0) {
        this.$store.commit("UPDATE_REWARD_HID", hid);
        this.checkReward(reward, hid);
      } else {
        this.viewReward(reward, hid);
      }
    },
    loadImage(){
      // var image= new Image()
      // image.src = require("../assets/images/reward_open.svg")
      // console.error(image.src)
    }
  },
  computed: {
    ...mapGetters([
      "getRewardState",
      "getHtData",
      "getSendReward",
      "getReward",
      "getListReward",
      "getOpenReward",
      "getRewardTimer",
      "getRewardCurhid",
      "getCashReward",
      "getCashDetail",
      "getPid"
    ]),
    liveid() {
      if (this.getHtData.live) {
        return this.getHtData.live.liveid;
      } else {
        return 0;
      }
    },
    cashState() {
      if (
        this.getCashReward.balance < 1 ||
        this.getCashReward.withdrawBalance != 0
      ) {
        return true;
      } else {
        return false;
      }
    },
    cashInfo() {
      if (
        this.getCashReward.balance >= 1 &&
        this.getCashReward.withdrawBalance == 0
      ) {
        return "全部提现";
      } else if (
        this.getCashReward.balance < 1 &&
        this.getCashReward.withdrawBalance == 0
      ) {
        return "(至少1元)提现";
      } else if (this.getCashReward.withdrawBalance != 0) {
        return "提现中...";
      }
    },
    bigRedAmount(){
      let pids = window.red_amount || []
      return pids.some((pid) => {
        return pid == this.getPid
      }) 
    }
  },
  watch: {
    getSendReward(newdata, old) {
      var that = this;
      WeixinJSBridge.invoke(
        "getBrandWCPayRequest",
        newdata.jsapiParams,
        function (res) {
          // console.log("微信支付");
          if (res.err_msg == "get_brand_wcpay_request:ok") {} else {}
          that.clearData();
          that.changeRewardState(0);
          that.$store.commit(TYPES.UPDATE_VIEWO_MODE, 0);
        }
      );
    },
    type(nv) {
      if (this.money && this.amount && this.div) {
        this.checkInput('money', this.div)
        // console.error(this.money,this.amount)
      }
    }
  },
  created() {
    // this.loadImage()
  },
  mounted() {
    // fixOverflowScroll('#redpack_scroller')
  }
};
</script>

<style lang="less" scoped>
@position: fixed;

.reward-wp {
  font-size: 14px;
  position: @position;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  // padding: 0 .2rem;
  box-sizing: border-box;
  z-index: 3000;
  background: rgba(238, 240, 242, 1);
  overflow: auto;
  -webkit-overflow-scrolling: touch;
}

.title {
  height: 0.88rem;
  font-size: 18px;
  text-align: center;
  line-height: 0.88rem;
  position: relative;
  background: white;
  color: rgba(27, 57, 71, 1);
  font-weight: bold;
  box-sizing: border-box;

  .back {
    display: flex;
    position: absolute;
    font-size: 14px;
    top: 0.2rem;
    left: 0.24rem;

    &>i {
      vertical-align: middle;
      font-style: normal;
      line-height: 26px;
    }
  }
}

.reward_send {
  .reward-wp {
    font-size: 14px;
    position: @position;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    // padding: 0 .2rem;
    box-sizing: border-box;
    z-index: 3000;
    background: rgba(238, 240, 242, 1);

    .title {
      height: 0.88rem;
      font-size: 18px;
      text-align: center;
      line-height: 0.88rem;
      position: relative;
      background: white;
      color: rgba(27, 57, 71, 1);
      font-weight: bold;
      box-sizing: border-box;

      .back {
        display: flex;
        position: absolute;
        font-size: 14px;
        top: 0.2rem;
        left: 0.24rem;

        &>i {
          vertical-align: middle;
          font-style: normal;
          line-height: 26px;
        }
      }
    }

    .reward_item {
      padding: 0 0.36rem;

      .error_tip {
        height: 1rem/2;
        // background: #DF922E;
        width: 100vw;
        left: -.36rem;
        position: relative;

        &>div {
          position: absolute;
          height: 100%;
          width: 100%;
          background: #b8945d;
          text-align: center;
          line-height: 1rem/2;
          font-size: 14px;
          color: #FFFFFF;
        }
      }

      .reminder {
        padding: 0.24rem 0;
        color: rgba(128, 135, 141, 1);

        .red_type {
          color: #DF922E;
        }
      }
    }

    .item_wp {
      padding: 0 0.3rem;
      box-sizing: border-box;
      background: white;
      border-radius: 6px;
    }

    .item {
      // background: white;
      // margin-bottom: .6rem;

      line-height: 1.2rem;
      height: 1.2rem;
      border-bottom: 1px solid rgba(0, 0, 0, 0.12);
      font-size: 18px;

      &.error,
      &.error .item_input input {
        color: #FF4E4E;
      }

      &:nth-of-type(n + 3) {
        border-bottom: none;
        height: 1.4rem;
      }

      .reward_icon {
        display: inline-block;
        width: 0.36rem;
        height: 0.44rem;
        background: url("../assets/images/reward_post_icon.svg") no-repeat;
        background-size: 100%;
        vertical-align: -0.11rem;
      }

      .item_input {
        float: right;

        input {
          height: 0.5rem;
          width: 3rem;
          text-align: right;
          outline: none;
          border: none;
          font-size: 18px;
          margin-right: 4px;

          // background: saddlebrown;
          &::placeholder {
            font-size: 18px;
            color: rgba(198, 205, 210, 1);
          }
        }

        &.descript {
          textarea {
            width: 5.2rem;
            border: none;
            outline: none;
            resize: none;
            // background: saddlebrown;
            font-size: 16px;
            height: 36px;
            // margin-top: 8px;
            padding: 0;
            vertical-align: middle;
            margin-top: 14px;
            text-align: right;

            &::placeholder {
              text-align: right;
              font-size: 18px;
              color: rgba(198, 205, 210, 1);
            }

            // line-height: 42px;
          }
        }
      }

      &::after {
        content: "";
        display: block;
        clear: both;
      }
    }

    #send_redpack_dom {
      display: block;
      font-size: 18px;
      width: 5rem;
      font-weight: 400;
      line-height: 0.88rem;
      letter-spacing: 0.1em;
      color: white;
      height: 0.88rem;
      margin: 0.54rem auto 0;
      background: rgba(255, 156, 156, 1);
      border-radius: 6px;
      text-align: center;

      &.send {
        background: #ff4e4e;
      }
    }

    .reward_count {
      text-align: center;
      font-size: 30px;
      font-weight: 1000;
      margin: 0;
      margin-top: 1rem;

      span {
        display: block;
        font-size: 18px;
        width: 5rem;
        font-weight: 400;
        line-height: 0.88rem;
        letter-spacing: 0.1em;
        color: white;
        height: 0.88rem;
        margin: 0.54rem auto 0;
        background: rgba(255, 156, 156, 1);
        border-radius: 6px;

        &.send {
          background: #ff4e4e;
        }
      }
    }
  }
}

.reward_open {
  .reward-wp {
    font-size: 14px;
    position: @position;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    // padding: 0 .2rem;
    box-sizing: border-box;
    z-index: 3000;
    background: rgba(0, 0, 0, 0.6);

    .reward_bg {
      width: 6rem;
      height: 8.6rem;
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0.8rem;
      margin: auto;
      background: url("../assets/images/reward_open.svg") no-repeat;
      background-size: 100% 110%;
      background-position: 0 -0.36rem;
      text-align: center;
      padding: 0.6rem 0.5rem 0;
      box-sizing: border-box;
      color: rgba(170, 118, 40, 1);
      font-size: 16px;
      font-weight: 500;

      .reward_close {
        width: 0.8rem;
        height: 0.8rem;
        background: url("../assets/images/com_cancel.svg") no-repeat;
        background-size: 100%;
        position: absolute;
        bottom: -60px;
        left: 0;
        right: 0;
        margin: auto;
      }

      .avatar {
        width: 0.8rem;
        height: 0.8rem;
        border-radius: 50%;
      }

      .name {
        margin: 0.2rem 0;
      }

      .descript {
        word-wrap: break-word;
        height: 0.84rem;
      }

      .open_cion {
        width: 1.4rem;
        height: 1.4rem;
        background: rgba(255, 213, 151, 1);
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.3);
        border-radius: 50%;
        margin: 100px auto 50px;
        font-size: 40px;
        line-height: 1.4rem;
      }

      .over {
        margin: 3.3rem auto 1.3rem;
        font-size: 20px;
        color: rgba(250, 255, 117, 1);
      }

      .look_more {
        bottom: 20px;
        left: 0;
        right: 0;
        margin: auto;
        position: absolute;
        font-size: 14px;
        color: rgba(250, 255, 117, 1);
      }
    }
  }
}

.reward_details {
  ._title {
    height: 1rem;
    font-size: 16px;
    text-align: center;
    padding-top: 5px;
    // line-height: 0.88rem;
    position: @position;
    top: 0;
    left: 0;
    right: 0;
    z-index: 3004;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    // font-weight: bold;
    box-sizing: border-box;
    letter-spacing: 2px;

    .back {
      display: inline-block;
      box-sizing: border-box;
      padding-top: 5px;
      width: 20px;
      height: 20px;
      background: url(../assets/images/reward_back.svg) no-repeat;
      background-size: 100%;
      background-position: 0 5px;
    }
  }

  .reward-wp {
    font-size: 14px;
    position: @position;
    top: 0;
    left: 0;
    width: 100vw;
    bottom: 0;
    right: 0;
    z-index: 3000;
    background: rgba(238, 240, 242, 1);
    // padding-top: .8rem;
    overflow: auto;
    box-sizing: border-box;

    .bg_top {
      height: 3rem;
      background: rgba(255, 78, 78, 1);
      position: relative;
      padding-top: 0.8rem;

      .radius {
        width: 100%;
        height: 2.44rem;
        background: rgba(255, 78, 78, 1);
        border-radius: 50%;
        position: absolute;
        top: 2.6rem;
      }

      .content {
        width: 100%;
        position: absolute;
        text-align: center;
        color: rgba(250, 255, 117, 1);
        font-size: 16px;
        padding-top: 20px;
        box-sizing: border-box;

        .avatar {
          width: 0.8rem;
          height: 0.8rem;
          border-radius: 50%;
        }

        .name {
          margin: 0.24rem 0;
        }

        .descript {
          margin-bottom: 0.6rem;
        }

        .count {
          font-size: 25px;
        }
      }
    }

    .list {
      margin-top: 80px;
      text-align: center;

      .total {
        color: rgba(125, 138, 148, 1);
      }

      ul {
        margin: 0;
        padding: 0;
        margin-top: 0.3rem;

        li {
          text-align: left;
          height: 1.2rem;
          box-sizing: border-box;
          padding: 0.2rem;
          background: white;
          border-bottom: 1px solid rgba(0, 0, 0, 0.05);
          position: relative;

          .avatar {
            width: 0.8rem;
            height: 0.8rem;
            border-radius: 50%;
          }

          .list_content {
            position: absolute;
            top: 0.2rem;
            left: 1.2rem;
            right: 0.2rem;
            bottom: 0.2rem;

            // background: sandybrown;
            span {
              position: absolute;
              color: rgba(67, 79, 88, 1);
            }

            .count {
              right: 0;
            }

            .time {
              bottom: 0;
              left: 0;
              color: rgba(125, 138, 148, 1);
              font-size: 12px;
            }
          }
        }
      }

      .reminder {
        text-align: center;
        margin-top: 2.2rem;
        padding-bottom: 0.44rem;
        color: rgba(125, 138, 148, 1);
      }
    }
  }
}

.reward_list {
  .title {
    height: 0.88rem;
    font-size: 18px;
    text-align: center;
    line-height: 0.88rem;
    position: @position;
    top: 0;
    left: 0;
    right: 0;
    z-index: 3000;
    background: white;
    color: rgba(27, 57, 71, 1);
    font-weight: bold;
    box-sizing: border-box;

    .back {
      display: flex;
      position: absolute;
      font-size: 14px;
      top: 0.2rem;
      left: 0.24rem;

      &>i {
        vertical-align: middle;
        font-style: normal;
        line-height: 26px;
      }
    }
  }

  .reward-wp {
    font-size: 14px;
    position: @position;
    top: 0.88rem;
    left: 0;
    width: 100vw;
    bottom: 0;
    right: 0;
    height: auto;
    z-index: 3000;
    background: rgba(238, 240, 242, 1);
    padding: 10px;
    overflow: auto;
    box-sizing: border-box;
    -webkit-overflow-scrolling: touch;

    li {
      text-align: left;
      height: 1.2rem;
      box-sizing: border-box;
      padding: 0.2rem;
      background: white;
      border-bottom: 1px solid rgba(0, 0, 0, 0.05);
      position: relative;
      border-radius: 6px;
      margin-bottom: 0.2rem;

      .avatar {
        width: 0.8rem;
        height: 0.8rem;
        box-shadow: 0px 1px 6px rgba(200, 0, 0, 0.3);
      }

      .list_content {
        position: absolute;
        top: 0.2rem;
        left: 1.2rem;
        right: 0.2rem;
        bottom: 0.2rem;

        // background: sandybrown;
        span {
          position: absolute;
          color: rgba(67, 79, 88, 1);
        }

        .name {
          left: 0;
          right: 1rem;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .count {
          width: 1rem;
          height: 1.2rem;
          background: linear-gradient(180deg,
              rgba(252, 84, 67, 1) 0%,
              rgba(248, 106, 52, 1) 100%);
          border-top-right-radius: 6px;
          border-bottom-right-radius: 6px;
          top: -0.2rem;
          right: -0.2rem;
          text-align: center;
          font-size: 14px;
          color: white;
          box-sizing: border-box;
          // padding: .2rem .1rem;
          line-height: 1.2rem;
        }

        .end {
          width: 1rem;
          height: 1.2rem;
          display: inline-block;
          background: url("../assets/images/reward_end.svg") no-repeat;
          background-size: 100%;
          background-position: 0 0.1rem;
          top: -0.2rem;
          right: -0.2rem;
        }

        .get {
          width: 1rem;
          height: 1.2rem;
          display: inline-block;
          background: url("../assets/images/reward_get.svg") no-repeat;
          background-size: 100%;
          background-position: 0 0.1rem;
          top: -0.2rem;
          right: -0.2rem;
        }

        .none {
          width: 1rem;
          height: 1.2rem;
          display: inline-block;
          background: url("../assets/images/reward_none1.svg") no-repeat;
          background-size: 100%;
          background-position: 0 0.1rem;
          top: -0.2rem;
          right: -0.2rem;
        }

        .time {
          bottom: 0;
          left: 0;
          color: rgba(125, 138, 148, 1);
          font-size: 12px;
        }
      }
    }

    .reminder {
      text-align: center;
      margin-top: 0.5rem;
      padding-bottom: 0.44rem;
      color: rgba(125, 138, 148, 1);
    }
  }
}

.reward_cash {
  .cash_content {
    padding-bottom: 0.7rem;
    background: white;

    .cash_details {
      text-align: right;
      font-size: 16px;
      padding: 0 0.3rem;
      box-sizing: border-box;
    }

    .cash_money {
      text-align: center;

      .icon {
        width: 1.2rem;
        height: 1.2rem;
        background: rgba(255, 188, 88, 1);
        border-radius: 50%;
        font-size: 40px;
        line-height: 1.3rem;
        text-align: center;
        color: white;
        margin: 0 auto;
      }

      .balance_title {
        font-size: 18px;
        color: rgba(67, 79, 88, 1);
        font-weight: 800;
      }

      .balance {
        font-size: 45px;
        font-weight: bold;
        color: rgba(27, 57, 71, 1);
        margin: 0;
      }

      span {
        font-size: 14px;
        color: rgba(128, 135, 141, 1);
      }
    }

    .cash_submit {
      margin-top: 0.8rem;

      button {
        &.disabled {
          background: rgba(175, 212, 255, 1);
        }

        margin: 0 auto;
        display: block;
        border: none;
        width: 5rem;
        height: 0.88rem;
        background: rgba(112, 179, 255, 1);
        border-radius: 3px;
        font-size: 18px;
        color: rgba(255, 255, 255, 1);
        letter-spacing: 1px;
        outline: none;
      }
    }
  }

  .cash_attention {
    text-align: center;
    height: 0.8rem;
    line-height: 0.8rem;
    color: rgba(67, 79, 88, 1);

    .back {
      height: 18px;
      vertical-align: middle;
      transform: translateY(-0.04rem) rotate(180deg);
      transition: 0.5s;

      &.choose {
        transform: rotate(270deg);
      }
    }
  }

  .cash_help {
    padding: 0.4rem;
    font-size: 16px;
    display: none;

    &.show {
      display: block;
    }

    background: white;
    float: left;
    color: rgba(23, 39, 46, 1);
    font-weight: bold;

    .help_content {
      margin: 0.4rem 0;

      .help_item {
        display: flex;
        margin-top: 5px;

        .placeholder {
          visibility: hidden;
        }

        .text {
          flex: 1;
          font-weight: 400;
        }
      }
    }
  }

  .cash_confimr_warp {
    position: absolute;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(238, 240, 242, 1);

    .cash_confimr {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      margin: auto;
      width: 6rem;
      height: 6rem;
      background: rgba(255, 255, 255, 1);
      border-radius: 10px;
      .top {
        width: 6rem;
        height: 1.4rem;
        background: rgba(248, 249, 251, 1);
        border-radius: 20px 20px 0px 0px;
        display: flex;
        padding: 0.3rem;
        box-sizing: border-box;

        .left {
          font-size: 16px;
          color: rgba(67, 79, 88, 1);
        }

        .right {
          font-size: 16px;
          color: rgba(67, 79, 88, 1);
          flex: 1;

          .cash_icon {
            display: inline-block;
            width: 15px;
            height: 15px;
            background: url("../assets/images/cash_money.svg") no-repeat;
            background-size: 100%;
            vertical-align: middle;
          }

          .cash_title {
            font-size: 14px;
            color: rgba(128, 135, 141, 1);
            line-height: 0.7rem;
          }
        }
      }

      .money {
        padding: 0 .8rem/2;
        box-sizing: border-box;
        text-align: center;
        font-size: 30px;
        font-weight: bold;
        color: rgba(27, 57, 71, 1);
        height: 3.08rem/2;
        line-height: 3.08rem/2;
      }

      .line{
        height: 1px;
        margin: 0 .8rem/2;
        box-sizing: border-box;
        background: #EEEEEE;
      }

      .service{
        margin: .2rem 0;
      }

      .service,.rate{
        color: #899297;
        font-size: 14px;
        padding: 0 .8rem/2;
        box-sizing: border-box;
        ._tip{
          float: right;
          color: #1B3947;
        }
      }

      .confimr_submit {
        padding-top: 0.6rem;
        text-align: center;

        button {
          width: 5rem;
          height: 0.88rem;
          background: rgba(112, 179, 255, 1);
          border-radius: 3px;
          border: none;
          outline: none;
          font-size: 18px;
          color: white;
        }
      }
    }
  }
}

.reward_account {
  .list {
    text-align: center;

    ul {
      margin: 0;
      padding: 0;

      li {
        text-align: left;
        height: 1.2rem;
        box-sizing: border-box;
        padding: 0.2rem;
        background: white;
        border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        position: relative;

        .list_content {
          position: absolute;
          top: 0.2rem;
          left: 0.2rem;
          right: 0.2rem;
          bottom: 0.2rem;

          span {
            position: absolute;
            color: rgba(67, 79, 88, 1);
          }

          .count {
            right: 0;
            font-size: 18px;

            &.income {
              color: rgba(255, 176, 41, 1);
            }
          }

          .time {
            bottom: 0;
            left: 0;
            color: rgba(125, 138, 148, 1);
            font-size: 12px;
          }
        }
      }
    }

    .reminder {
      text-align: center;
      margin-top: 1.5rem;
      padding-bottom: 0.44rem;
      color: rgba(125, 138, 148, 1);
    }
  }
}
</style>
