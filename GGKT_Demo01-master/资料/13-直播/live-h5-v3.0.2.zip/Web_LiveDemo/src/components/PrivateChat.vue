<template>
<transition name="fade">
  <div class="private_chat_warp" id="private_chat" @click.stop="">
    <div class="com_menu_head">
      <!--导航-->
      <ul class="ht_nav_list">
        <li v-if="getpvUserlist.length===0" class="only">客服</li>
        <li :class="{selected:getActiveUser.xid===item.xid,only:getpvUserlist.length===1}" v-for="(item, index) in getpvUserlist" :key="index" @click.stop="changeChat(item)" v-if="!random">
          {{item.nickname==='助教'?'客服':item.nickname}}
          <div class="chat_num" v-show="item.tip">{{item.tip}}</div>
        </li>
        <li class="selected" v-if="random">
          {{getActiveUser.nickname==='助教'?'客服':getActiveUser.nickname}}
          <div class="chat_num" v-show="getActiveUser.tip">{{getActiveUser.tip}}</div>
        </li>
      </ul>
    </div>
    <!-- #消息 -->
    <div class="mod_chat_list">
      <div class="no_chat" v-if="getpvUserlist.length===0">
        <div class="bg no_online"></div>
        <p class="tip">客服现在不在线<br>
          请在主聊天区与主播沟通</p>
      </div>
      <div class="no_chat" v-if="curchatList.length===0&&getpvUserlist.length>0">
        <div class="bg"></div>
        <p class="tip">请在此咨询客服</p>
      </div>
      <div id="private_chat_scroller">
        <ul class="chat_inner">
          <li class="chat-item" v-for="(item, index) in curchatList" :key="index">
            <!-- #客服消息 -->
            <div class="pub_msg" v-if="item.type==='service'">
              <img :src="item.avatar" alt class="avatar" />
              <div class="chat_right spadmin">
                <div class="chat_head_com">
                  <span class="nickname">{{item.nickname==='助教'?'客服':item.nickname}}</span>
                  <span class="chat_time">{{item.time?item.time:item.timestamp | getTime}}</span>
                </div>
                <p class="chat_detail" v-html="renderMsg(item.msg)?renderMsg(item.msg):renderMsg(item.message)" v-if="!item.image"></p>
                <p class="chat_detail image" v-if="item.image">
                  <img :src="item.image" alt v-gallery:group1 />
                </p>
              </div>
            </div>
            <!-- #本人消息 -->
            <div class="pub_msg self" v-if="item.type==='self'">
              <!-- <img :src="item.avatar" alt class="avatar" /> -->
              <div class="chat_right spadmin">
                <div class="chat_head_com">
                  <span class="chat_time">{{item.time?item.time:item.timestamp | getTime}}</span>
                  <span class="nickname">{{item.nickname}}</span>
                </div>
                <p class="chat_detail" v-html="renderMsg(item.msg)?renderMsg(item.msg):renderMsg(item.message)" v-if="!item.image"></p>
                <p class="chat_detail image" v-if="item.image">
                  <img :src="item.image" alt v-gallery:group1 />
                </p>
              </div>
              <img :src="item.avatar" alt class="avatar" />
            </div>
          </li>
          <li id="pvChatList_bottom"></li>
        </ul>
      </div>
    </div>
    <!-- chat Post -->
    <div class="mod_chat_post_v2">
      <!-- 聊天功能区 -->
      <div class="post_con">
        <span class="mod_chat_ipt">
          <input id="private_chat_post" type="text" placeholder="请输入您要咨询的问题" autocomplete="off" @focus="onChatFocus()" :chatMsg="chatMsg" @blur="onBlur()" v-model.trim="chatMsg" />
        </span>
        <div class="icon_warp">
          <span data-type="chat" @click="chat_send($event)" class="csend" v-if="onSend">发送</span>
        </div>
      </div>
    </div>
  </div>
</transition>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
import BScroll from "better-scroll";
import * as TYPES from "@/assets/action-types";
import SDKEMIT from "@/assets/js/sdk.emit";
import * as tools from "@/assets/js/util";
export default {
  props: ['popShow'],
  data() {
    return {
      onSend: false,
      random:false,
      chatMsg: '',
      emojiPack: {
        "[微笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon1.png",
        "[调皮]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon2.png",
        "[害羞]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon3.png",
        "[奸笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon4.png",
        "[憨笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon5.png",
        "[尴尬]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon6.png",
        "[鼓掌]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon7.png",
        "[惊讶]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon8.png",
        "[闭嘴]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon9.png",
        "[呲牙]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon10.png",
        "[大哭]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon11.png",
        "[大笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon12.png",
        "[得意]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon13.png",
        "[囧]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon14.png",
        "[难过]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon15.png",
        "[敲打]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon16.png",
        "[色]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon17.png",
        "[委屈]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon18.png",
        "[疑问]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon19.png",
        "[郁闷]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon20.png",
        "[再见]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon21.png",
        "[可怜]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon22.png",
        "[捂脸]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon23.png",
        "[笑哭]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon24.png",
        "[安慰]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon25.png"
      },
    };
  },
  watch: {
    getToolsPrivate(nv) {
      // console.error(nv)
      if (!nv) {
        this.bscroller.isScrolled = false
        this.$nextTick(() => {
          let item = document.querySelector("#pvChatList_bottom");
          this.bscroller.refresh();
          this.bscroller.scrollTo(0, -99999);
        })
      }
      this.$store.commit("updateCurTip", false)
    },
    curchatList(nv) {
      if (this.bscroller) {
        this.$nextTick(() => {
          let item = document.querySelector("#pvChatList_bottom");
          this.bscroller.refresh();
          this.bscroller.scrollToElement(item, 100);
        })
      }
    }
  },
  filters: {
    getTime(_time) {
      return tools.convertTimestamp(_time);
    },
  },
  methods: {
    ...mapActions({
      updataUer: "setUserlist"
    }),
    info() {
      this.$nextTick(() => {
        const bscroller = new BScroll("#private_chat_scroller", {
          click: true,
          scrollY: true,
          useTransform: true,
        });
        bscroller.on('beforeScrollStart', function () {
          if (!this.isScrolled) {
            this.refresh()
            this.isScrolled = true
          }
        })
        this.bscroller = bscroller;
        this.bscroller.refresh();
      })
      let that = this;
      let _wrap = this.jquery("#private_chat_scroller");
      _wrap.bind("click", function () {
        that.jquery("#private_chat_post").blur();
      });
      if(this.getPid==13734){
        // 随机客服
        this.randomChat()
      }
    },
    randomChat(){
      this.random = true
      if(this.getpvUserlist.length){
        let index = parseInt(Math.random()*(this.getpvUserlist.length-0)+0) 
        this.$store.commit("updateactiveUser", this.getpvUserlist[index])
      }
    },
    onChatFocus(e) {
      setTimeout(() => {
        this.jquery(document).scrollTop(this.jquery(window).height());
      }, 250);
      this.onSend = true;
    },
    onBlur() {
      document.body.scrollTop = document.documentElement.scrollTop = 0;
      this.jquery("#app").scrollTop(0);
      this.$nextTick(() => {
        this.bscroller.refresh()
      })
      if (this.chatMsg === "") {
        this.onSend = false;
      }
      if (window.parent && window.parent.postMessage) {
        window.parent.postMessage('chat:on:blur', "*");
      }
    },
    renderMsg(msg) {
      if (!msg) {
        return false;
      }
      let _rule = /\[(.+?)\]/g;
      let _list = msg.match(_rule);
      if (_list && _list.length > 0) {
        // 截图
        if (msg.indexOf("[IMG]") > -1) {
          var imgClip = msg.replace(/\[(.+?)\]/g, "");
          return '<img src="' + imgClip + '" />';
        }
        // 表情
        msg = msg.replace(_rule, (r, k) => {
          let emoji = this.emojiPack[r];
          if (emoji) {
            return (
              '<img src="' +
              emoji +
              '"' +
              'style="vertical-align: bottom;"' +
              "/>"
            );
          }else{
            return r
          }
        });
      }
      return msg;
    },
    changeChat(user) {
      if (user.xid !== this.getActiveUser.xid) {
        // 切换当前用户
        this.$store.commit("updateactiveUser", user)
        // 清空当前聊天消息提示
        this.$store.commit("updateChatTip", {
          xid: this.getActiveUser.xid
        })
      }
    },
    chat_send(event) {
      if (this.getActiveUser && this.getActiveUser.xid) {
        SDKEMIT.privateChat(this.HTSDK, this.chatMsg, this.getActiveUser.xid, res => {
          if (res.code !== 0) {
            this.$vux.toast.text(res.msg, "bottom");
            return false;
          }
          this.chatMsg = "";
          res.data.time = tools.convertTimestamp(res.data);
          res.data.type = "self"
          res.data.xid = this.getActiveUser && this.getActiveUser.xid ? this.getActiveUser.xid : 0
          // console.error(res)
          this.$store.commit("updatePvChatList", res.data)
        });
      } else {
        this.$vux.toast.text("当前客服不在线", "bottom");
        this.chatMsg = "";
      }
      document.getElementById("private_chat_post").blur();
      this.onSend = false;
      event.preventDefault();
    },
  },
  computed: {
    ...mapGetters(["getUser", "getHtData", "getPvChatList", "getActiveUser", "getpvUserlist", "getToolsPrivate","getPid"]),
    curchatList() {
      if (this.getActiveUser && this.getPvChatList[this.getActiveUser.xid]) {
        // console.error(this.getPvChatList[this.getActiveUser.xid])
        return this.getPvChatList[this.getActiveUser.xid]
      } else {
        return []
      }
    }
  },
  mounted() {
    this.info()
  }
};
</script>

<style lang="less" scoped>
.private_chat_warp {
  overflow: hidden;
  -webkit-overflow-scrolling: touch;
  position: relative;
  width: 100%;
  position: fixed;
  bottom: 0;
  height: 70vh;
  z-index: 2000;
  transition: 0.5s;
  border-radius: 20px/2 20px/2 0px 0px;
  background: #F6F8F9;
  display: flex;
  flex-direction: column;

  .com_menu_head {
    width: 100vw;
    height: 1.76rem/2;
    overflow: hidden;
    position: relative;
    background: #fff;
    display: flex;

    .ht_nav_list {
      flex: 1;
      height: 100%;
      // box-sizing: border-box;
      padding-bottom: 10px;
      margin: 0 .3rem 0;
      list-style: none;
      font-size: 0;
      white-space: nowrap;
      overflow-x: scroll;
      overflow-y: hidden;
      display: flex;
      // justify-content: center;

      //  box-sizing: border-box;
      li {
        //  position: absolute;
        // flex: 1;
        position: relative;
        background: white;
        // max-width: 50%;
        height: 100%;
        font-size: 14px;
        text-align: center;
        line-height: 0.9rem;
        padding: 0 .6rem/2;
        color: #797979;
        // overflow: hidden;
        // text-overflow: ellipsis;
        white-space: nowrap;

        &.selected {
          // border-bottom: 2px solid #01c2ff;
          background: #F6F8F9;
          color: #4D5358;
        }

        &.only {
          margin: 0 auto;
          background: #FFFFFF;
        }

        .chat_num {
          line-height: .65rem/2;
          position: absolute;
          right: .6rem/2;
          transform: translate(100%, 0);
          top: 2px;
          padding: 1px 4px;
          font-size: 12px;
          background: #FF4747;
          color: #FFFFFF;
          border-radius: .3rem/2 .3rem/2 .3rem/2 2px;
          z-index: 2;
        }
      }
    }

    .focus {
      flex: none;
      width: 2.2rem/2;
      height: 100%;
      background: #01C2FF;
      color: #FFFFFF;
      text-align: center;
      line-height: .8rem;
      font-size: 15px;
    }
  }

  .mod_chat_list {
    background: #F6F8F9;
    flex: 1;
    overflow: hidden;

    .no_chat {
      .bg {
        width: 4.08rem/2;
        height: 3.8rem/2;
        background: url(../assets/images/live-v2/no_private_chat.png) no-repeat;
        background-size: 100% 100%;
        margin: 2.24rem/2 auto .74rem/2;

        &.no_online {
          background: url(../assets/images/live-v2/no_private_online.png) no-repeat;
          background-size: 100% 100%;
        }
      }

      .tip {
        font-size: 16px;
        text-align: center;
        color: #B2BDC4;
      }
    }

    .chat-item {
      text-align: left;

      &:first-child {
        padding-top: 5px;
      }

      &:nth-last-child(1) {
        padding-bottom: 20px;
      }

    }

    .pub_msg {
      padding: 5px 12px 5px;
      font-size: 14px;
      line-height: 20px;
      overflow: hidden;
      clear: both;
      margin-bottom: 10px;

      &.self {
        text-align: right;
        display: flex;

        .chat_right {
          &::after {
            content: "";
            display: block;
            clear: both;
          }
        }

        .chat_head_com {
          padding-right: 10px !important;
        }

        .chat_detail {
          background-color: #01C2FF !important;
          color: #FFFFFF !important;
          float: right;
          margin: 0;
          margin-right: 10px;
        }

        .avatar {
          flex: none;
        }
      }

      .avatar {
        width: 0.8rem;
        height: 0.8rem;
        margin-right: 0;
        margin-left: auto;
        vertical-align: top;
        display: inline-block;
        position: relative;
        bottom: 0px;
        border-radius: 50%;
      }

      .chat_right {
        display: inline-block;
        flex: 1;
        position: relative;
        bottom: 0px;

        .chat_time {
          padding-left: 0;
          color: #ececec;
        }

        margin-left: 0;

        .chat_head_com {
          padding: 0 0 0 8px;

          .nickname {
            color: rgba(125, 138, 148, 1);
            margin-right: 0.05rem;
            font-size: 14px;
          }

          .chat_time {
            color: rgba(125, 138, 148, 1);
            font-size: 14px;
          }
        }
      }

      .chat_detail {
        margin: 0;
        margin-left: 10px;
        padding: 0.14rem 0.3rem;
        // border-radius: .4rem;
        font-size: 14px;
        background-color: rgba(255, 255, 255, 1) !important;
        color: rgba(67, 79, 88, 1) !important;
        word-wrap: break-word;
        word-break: break-all;
        background-color: #FFFFFF;
        padding: 10px;
        border-radius: 5px;
        max-width: 70%;
        position: relative;
        float: left;
        text-align: left;

        img {
          width: 100%;
          height: 2.3rem;
          object-fit: cover;
          border-radius: 5px;
        }

        &.image {
          padding: 0 !important;
          margin-left: 5px;
          background: none !important;

          &::after {
            display: none;
          }
        }
      }
    }

    #private_chat_scroller {
      height: 100%;
      overflow: hidden;
    }
  }

  .mod_chat_post_v2 {
    flex: none;
    height: 1.2rem;
    width: 100%;
    max-width: 750px;
    transition: .5s;
    background: #FFFFFF;

    .post_con {
      display: flex;
      height: 100%;
      align-items: center;
      padding: .4rem/2 1.2rem/2;
      box-sizing: border-box;

      .mod_chat_ipt {
        border: none;
        color: black;
        font-size: 14px;
        flex: 1;
        height: 100%;
        outline: none;
        position: relative;
        line-height: 35px;
        text-align: center;

        input {
          width: 90%;
          height: 90%;
          background-color: rgba(246, 248, 249, 1);
          outline: none;
          text-indent: 1em;
          border: none;
          border-radius: 15px;
        }

        input::placeholder {
          color: #c6cdd2;
        }
      }

      .icon_warp {
        flex: none;
        display: flex;

        .csend {
          width: 1rem;
          height: 0.6rem;
          line-height: 0.6rem;
          text-align: center;
          border-radius: 0.36rem;
          background-color: #70b3ff;
          color: #fff;
          font-size: 16px;
          display: block;
          flex: none;
        }
      }

    }
  }
}

.fade-enter-active,
.fade-leave-active {
  transition: 0.5s;
}

.fade-enter {
  transform: translate(0, 100%);
}

.fade-enter-to {
  transform: translate(0, 0);
}

.fade-leave {
  transform: translate(0, 0);
}

.fade-leave-to {
  transform: translate(0, 100%);
}
</style>
