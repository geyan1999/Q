<template>
<div class="online_total" v-if="getConfig && getConfig.global.switch.number.enable == 1&&isVod===0">
  <span v-show="getMemberTotal">{{ getTotal()|renderTotal}}</span>
</div>
</template>

<script>
import {
  mapGetters
} from 'vuex'
export default {
  name: 'OnlineTotal',
  data() {
    return {
      isVod: window.isVod || 0,
      total: 0
      // todo...
    }
  },
  filters: {
    renderTotal(num) {
      if (num > 9999 && num <= 9999999) {
        num = `${parseInt(num / 10000)}${parseInt((num % 10000) / 1000)>0?'.'+parseInt((num % 10000) / 1000):''}${parseInt((num % 1000) / 100) >0?parseInt((num % 1000) / 100):''}w`
      } else if (num > 9999999) {
        num = '9999w+'
      }
      return num;
    }
  },
  computed: {
    ...mapGetters([
      'getMemberTotal',
      'getRobotTotal',
      'getConfig',
      'getintoRoom'
    ]),
  },
  methods: {
    getTotal() {
      if (this.getConfig && this.getConfig.global.switch.number.popularity && this.getConfig.global.switch.number.popularity.enable == 1 && this.getConfig.global.switch.number.popularity.num) {
        return ((Number(this.getRobotTotal) + Number(this.total)) * this.getConfig.global.switch.number.popularity.num) + ' 人气'
      }
      return (Number(this.getRobotTotal) + Number(this.total)) + ' 观看'
    }
  },
  watch: {
    getMemberTotal: {
      handler: function (nv, ov) {
        // 累加模式
        if (this.getConfig && this.getConfig.global.switch.number.accumulation && this.getConfig.global.switch.number.accumulation.enable == 1) {
          this.total = nv > this.total ? nv : this.total
        } else {
          // 普通模式
          this.total = nv
        }
      },
      immediate: true
    },
    getintoRoom() {
      // 累加模式
      if (this.getConfig && this.getConfig.global.switch.number.accumulation && this.getConfig.global.switch.number.accumulation.enable == 1) {
        this.total = this.total + 1
      }
    }
  },
  mounted() {
    // console.error("加载")
  },
}
</script>

<style lang="less" scoped>

</style>
