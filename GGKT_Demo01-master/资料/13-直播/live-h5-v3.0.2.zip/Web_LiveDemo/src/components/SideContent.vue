<template>
<div class="side-content-wp" @click.stop="">
  <!-- 关注二维码 -->
  <div class="qrcode_warp" v-if="getSideMode==1">
    <div class="qr_code">
      <div class="top">
        <img :src="getConfig&&getConfig.global.switch.focus.data.url" />
      </div>
      <div class="tip">{{pid==13300?'扫码进群了解更多直播资讯':'长按扫码关注公众号'}}</div>
      <div class="close" @click.stop="back()">
        <div class="bt_close"></div>
      </div>
    </div>
  </div>
  <!-- 商城二维码 -->
  <div class="qrcode_warp" v-if="getSideMode==7">
    <div class="qr_code">
      <div class="top">
        <img :src="getConfig.global.switch.store.data.qrcode" />
      </div>
      <div class="tip">长按进入小程序商城</div>
      <div class="close" @click.stop="back()">
        <div class="bt_close"></div>
      </div>
    </div>
  </div>
  <!-- 分享卡 -->
  <div class="invant_card" v-if="getSideMode==2&&share">
    <div class="title">
      <div class="back" @click.stop="back('invant_card')">
        <x-icon type="ios-arrow-back"></x-icon>
        <i>返回</i>
      </div>邀请卡
    </div>
    <div class="canvas_car"></div>
    <article id="invitation_car" class="invitation_car hidden" :class="chooseback()">
      <div class="invitation_content">
        <div class="user_avatar">
          <img :src="share.avatar" alt="用户头像" />
        </div>
        <div class="user_name">{{getHtData.user.nickname}}</div>
        <div class="course_name">邀请您一起来看直播</div>
        <div class="course_introduce">{{getPid==13573?'即刻开启 拼享生活':share.describe}}</div>
        <div class="live_time">
          <span>直播时间：</span>
          {{transtionTime}}
        </div>
        <div class="zhubo_name">

          <span>主播：</span>
          {{getHtData.zhubo.nickname}}
        </div>
        <div class="course_share">
          <img :src="share.qrcodeUrl" alt="分享二维码" class="share" />
          <img src="../assets/images/live/tip.png" alt="长按二维码" class="tip" />
        </div>
      </div>
    </article>
    <div class="invitation_car_tip">长按图片保存，或发送好友</div>
    <div class="background_choose_warp">
      <ul class="background_choose" :class="{'pid': getPid == 12270,'pid_13573':getPid==13573}">
        <li @click.stop="changeCard(7)" v-if="getPid == 12270">
          <div class="choose" v-show="choose==7">
            <span class="choose_icon"></span>
          </div>
        </li>
        <li @click.stop="changeCard(8)" v-if="getPid == 12270">
          <div class="choose" v-show="choose==8">
            <span class="choose_icon"></span>
          </div>
        </li>
        <li @click.stop="changeCard(12)" v-if="getPid == 13573">
          <div class="choose" v-show="choose==12">
            <span class="choose_icon"></span>
          </div>
        </li>
        <li @click.stop="changeCard(9)" v-if="getPid == 13573">
          <div class="choose" v-show="choose==9">
            <span class="choose_icon"></span>
          </div>
        </li>
        <li @click.stop="changeCard(10)" v-if="getPid == 13573">
          <div class="choose" v-show="choose==10">
            <span class="choose_icon"></span>
          </div>
        </li>
        <li @click.stop="changeCard(11)" v-if="getPid == 13573">
          <div class="choose" v-show="choose==11">
            <span class="choose_icon"></span>
          </div>
        </li>
        <li @click.stop="changeCard(1)" v-if="getPid != 13573">
          <div class="choose" v-show="choose==1">
            <span class="choose_icon"></span>
          </div>
        </li>
        <li @click.stop="changeCard(2)" v-if="getPid != 13573">
          <div class="choose" v-show="choose==2">
            <span class="choose_icon"></span>
          </div>
        </li>
        <li @click.stop="changeCard(3)" v-if="getPid != 13573">
          <div class="choose" v-show="choose==3">
            <span class="choose_icon"></span>
          </div>
        </li>
        <li @click.stop="changeCard(4)" v-if="getPid != 13573">
          <div class="choose" v-show="choose==4">
            <span class="choose_icon"></span>
          </div>
        </li>
        <li @click.stop="changeCard(5)" v-if="getPid != 13573">
          <div class="choose" v-show="choose==5">
            <span class="choose_icon"></span>
          </div>
        </li>
        <li @click.stop="changeCard(6)" v-if="getPid != 13573">
          <div class="choose" v-show="choose==6">
            <span class="choose_icon"></span>
          </div>
        </li>
      </ul>
    </div>
  </div>
  <!-- 打赏 -->
  <div class="award_warp" v-if="getSideMode==4">
    <div class="award_content">
      <div class="bg_top">
        <div class="radius"></div>
        <div class="close" @click.stop="back()"></div>
        <div class="content">
          <div class="avatar">
            <img :src="getAnchorimg" alt="欢拓直播" />
          </div>
          <p>赞赏主播一个红包吧</p>
        </div>
      </div>
      <div class="amount_list">
        <div v-for="(item,index) in amountList" :key="index" @click.stop="getaward(item)" class="award_money">{{item}}元</div>
      </div>
    </div>
  </div>
  <!-- 点赞 -->
  <!-- <div class="like_warp" v-show="getSideMode == 6 || status=='动画开始' && getSideMode==0"></div> -->
  <!-- 举报 -->
  <div class="report_warp" v-if="getSideMode==8">
    <div class="inner_warp">
      <div class="reason_item">
        <div class="item_warp">
          <div class="item">
            <div class="radio_warp">
              <input type="radio" name="reason" id="reason1" value="侵权" v-model="reasonType">
              <label for="reason1" class="_radio"></label>
            </div>
            <span>侵权</span>
          </div>
          <div class="item">
            <div class="radio_warp">
              <input type="radio" name="reason" id="reason2" value="色情" v-model="reasonType">
              <label for="reason2" class="_radio"></label>
            </div>
            <span>色情</span>
          </div>
          <div class="item">
            <div class="radio_warp">
              <input type="radio" name="reason" id="reason3" value="反动" v-model="reasonType">
              <label for="reason3" class="_radio"></label>
            </div>
            <span>反动</span>
          </div>
          <div class="item">
            <div class="radio_warp">
              <input type="radio" name="reason" id="reason4" value="违法" v-model="reasonType">
              <label for="reason4" class="_radio"></label>
            </div>
            <span>违法</span>
          </div>
        </div>
        <div class="item">
          <div class="radio_warp">
            <input type="radio" name="reason" id="reason5" value="其它举报原因" v-model="reasonType">
            <label for="reason5" class="_radio"></label>
          </div>
          <div class="text_area">
            <div>其它举报原因</div>
            <textarea maxlength="25" v-model="reasonTest" @keydown.prevent.enter placeholder="详细原因"></textarea>
            <span class="text_acout"><span>{{reasonTest.length}}</span>/25</span>
          </div>

        </div>
      </div>
      <div class="report_post">
        <div class="btn" @click.stop="cancel">取消</div>
        <div class="btn affirm" @click.stop="post">确定</div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
import html2canvas from "../assets/js/html2canvas.min";
// import flutterheart from "../assets/js/flutter-hearts-zmt";
import * as TYPES from "@/assets/action-types";
import {
  mapGetters,
  mapActions
} from "vuex";
export default {
  data() {
    return {
      choose: 1,
      reasonType: '',
      share: window.card ? window.card : {},
      BubbleHearts: null,
      images: null,
      amountList: ["2.2", "8.8", "18.8", "28.8", "88", "188"],
      status: '动画结束',
      reasonTest: '',
      isVod: window.isVod && window.isVod == 1 ? true : false,
    };
  },
  computed: {
    ...mapGetters([
      "getHtData",
      "getShareQrcode",
      "getSideMode",
      "getPid",
      "getAnchorimg",
      "getConfig",
      "getZhuboReward",
      "getZhuboRewardPlay"
    ]),
    transtionTime() {
      if (this.getHtData.course) {
        // console.log(this.getHtData.course.start_time);
        let data = new Date(Number(this.getHtData.course.start_time) * 1000);
        return data.toLocaleString();
      } else {
        return "";
      }
    },
    liveid() {
      if (this.getHtData.live) {
        return this.getHtData.live.liveid;
      } else {
        return 0;
      }
    },
    pid() {
      if (this.isVod) {
        if (this.getHtData && this.getHtData.pid) {
          return this.getHtData.pid
        }
      } else {
        if (this.getHtData && this.getHtData.zhubo && this.getHtData.zhubo.partner_id) {
          return this.getHtData.zhubo.partner_id
        }
      }
      return false
    },
  },
  methods: {
    ...mapActions({
      Reward: "POST_REWARD"
    }),
    cancel() {
      this.$store.commit(TYPES.UPDATE_SIDE_MODE, 0)
      this.reasonType = ''
    },
    post() {
      if (this.reasonType === '') {
        this.$vux.toast.text('请先选择举报原因', 'bottom');
        return
      }
      let baseUrl = '//' + (window.apiHost || '//open.talk-fun.com')
      let access_token = window.access_token || ''
      let data = {
        access_token: access_token,
        action: 'report',
        content: this.reasonType === '其它举报原因' ? this.reasonTest : this.reasonType
      }
      let fromdata = new FormData()
      for (let item in data) {
        fromdata.append(item, data[item])
      }
      let config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      let that = this
      this.$vux.loading.show()
      this.$http.post(baseUrl + '/live/interaction.php', fromdata, config)
        .then(function (res) {
          if (res.data.code == 0) {
            that.$vux.toast.text('举报成功', 'bottom')
          } else {
            that.$vux.toast.text(res.data.msg, 'bottom')
          }
        })
        .catch(function (err) {
          that.$vux.toast.text('网络出现问题', 'bottom')
        })
        .finally(function () {
          that.$vux.loading.hide()
          that.reasonType = ''
          that.$store.commit(TYPES.UPDATE_SIDE_MODE, 0)
        })
    },
    changeCard(type) {
      this.choose = type;
      let event = this.jquery("#invitation_car");
      this.jquery("#loading").removeClass("hidden");
      setTimeout(() => {
        this.toCard(event);
      }, 0);
    },
    chooseback() {
      return "background" + this.choose;
    },
    toCard(event) {
      let that = this;
      this.jquery("#invitation_car").removeClass("hidden");
      document.body.style.minHeight = event.innerHeight() + "px";
      document.body.style.minWidth = event.innerWidth() + "px";
      // console.log(event, window.html2canvas);
      window.html2canvas(event, {
        onrendered: function (canvas) {
          // 跨域时toDataURL方法不能绑定到Elment
          var url = null;
          try {
            url = canvas.toDataURL("image/png");
          } catch (err) {
            alert(err);
          }
          var style = 'style="width:100%;height:100%;object-fit:contain;"';
          var pHtml = "<img src=" + url + " " + style + " />";
          that.jquery(".canvas_car").html(pHtml);
          // 完成后隐藏
          that.jquery(".invitation_car").addClass("hidden");
          that.jquery("#loading").addClass("hidden");
          document.body.style.minHeight = "auto";
          document.body.style.minWidth = "auto";
        },
        useCORS: true
      });
    },
    back(type) {
      this.$store.commit(TYPES.UPDATE_SIDE_MODE, 0);
      this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 0);
      if (type === "invant_card") {
        // this.HTSDK.play();
      }
    },
    initLikeAnimation() {
      var that = this;
      flutterheart();
      // 图片资源;
      var assets = [
        "../assets/images/live-v2/1(1).svg",
        "../assets/images/live-v2/2(1).svg"
      ];
      // 加载图片;
      assets.forEach(function (src, index) {
        assets[index] = new Promise(function (resolve) {
          var img = new Image();
          img.onload = resolve.bind(null, img);
          var str = src;
          if (index == 0) {
            img.src = require("../assets/images/live-v2/1(1).svg");
          }
          if (index == 1) {
            img.src = require("../assets/images/live-v2/2(1).svg");
          }
        });
      });
      Promise.all(assets).then(function (images) {
        var obj = new BubbleHearts();
        that.BubbleHearts = obj;
        that.images = images;
        that.canvas = obj.canvas;
        that.canvas.width = 150;
        that.canvas.height = 400;
        that.canvas.style["width"] = "100%";
        that.canvas.style["height"] = "100%";
        that.canvas.id = "bubble-heart";
      });
    },
    like() {
      if (this.BubbleHearts && this.BubbleHearts.bubble) {
        var random = {
          uniform: function (min, max) {
            return min + (max - min) * Math.random();
          },
          uniformDiscrete: function (i, j) {
            return i + Math.floor((j - i + 1) * random.uniform(0, 1));
          }
        };
        if (!document.querySelector("#bubble-heart")) {
          document.getElementsByClassName("like_warp")[0].append(this.canvas);
          this.BubbleHearts.bubble(
            this.images[random.uniformDiscrete(0, this.images.length - 1)]
          );
        } else {
          this.BubbleHearts.bubble(
            this.images[random.uniformDiscrete(0, this.images.length - 1)]
          );
        }
      }
    },
    getaward(price) {
      // this.jquery("#loading").removeClass("hidden");
      this.$vux.loading.show({
        text: "Loading"
      });
      this.Reward({
        vm: this,
        data: {
          liveid: this.liveid,
          price: price
        },
        price: price
      })
    }
  },
  watch: {
    getSideMode(newdata, old) {
      let that = this;
      // console.error(newdata)
      if (newdata == 2) {
        if (this.share) {
          this.jquery("#loading").removeClass("hidden");
          if (this.getPid == 12270) {
            this.choose = 7;
          }
          setTimeout(() => {
            this.toCard(this.jquery("#invitation_car"));
          }, 0);
        } else {
          this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 0);
          this.$store.commit(TYPES.UPDATE_SIDE_MODE, 0);
          this.$vux.alert.show({
            content: "暂无数据"
          });
        }
      }
      if (newdata == 3) {
        this.like();
        this.$store.commit(TYPES.UPDATE_SIDE_MODE, 6);
        this.status = '动画开始'
      }
    },
    getZhuboRewardPlay(nd, od) {
      var that = this;
      WeixinJSBridge.invoke(
        "getBrandWCPayRequest",
        nd.jsapiParams,
        function (res) {
          // console.warn("微信支付");
          if (res.err_msg == "get_brand_wcpay_request:ok") {
            that.$store.commit(TYPES.UPDATE_SIDE_MODE, 0);
          } else {
            that.$store.commit(TYPES.UPDATE_SIDE_MODE, 0);
          }
        }
      );
    }
  },
  mounted() {
    if (this.getPid == 13573) {
      this.choose = 9
    }
    Date.prototype.toLocaleString = function () {
      // 补0   例如 2018/7/10 14:7:2  补完后为 2018/07/10 14:07:02
      function addZero(num) {
        if (num < 10) return "0" + num;
        return num;
      }
      // 按自定义拼接格式返回
      return (
        this.getFullYear() +
        "年" +
        addZero(this.getMonth() + 1) +
        "月" +
        addZero(this.getDate()) +
        " " +
        addZero(this.getHours()) +
        ":" +
        addZero(this.getMinutes()) +
        ":" +
        addZero(this.getSeconds())
      );
    };
    // 将组件注册到插件中
    // window._myComponent = this
    // this.initLikeAnimation();
    // 初始化后台配置
    if (this.getConfig && this.getConfig.global.switch.focus.data.popUp == 1 && this.getConfig.global.switch.focus.enable == 1) {
      this.$store.commit(TYPES.UPDATE_SIDE_MODE, 1)
    }
  }
};
</script>

<style lang="less" scoped>
.side-content-wp {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 2000;

  .qrcode_warp {
    width: 100vw;
    height: 100vh;
    position: absolute;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);

    .qr_code {
      width: 8.8rem/2;
      height: 8.8rem/2;
      background: rgba(255, 255, 255, 1);
      border-radius: 10px;
      position: absolute;
      overflow: hidden;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      margin: auto;

      .top {
        width: 4.6rem/2;
        height: 4.6rem/2;
        margin: 1.56rem/2 auto 0.64rem/2;

        img {
          width: 100%;
          object-fit: cover;
        }
      }

      .tip {
        color: #6b788b;
        font-size: 14px;
        text-align: center;
      }

      .close {
        position: absolute;
        right: -44px;
        top: -44px;
        width: 0;
        height: 0;
        border: 44px solid transparent;
        // border-bottom-color: #E1E8EE;
        transform: rotate(45deg);
        cursor: pointer;

        .bt_close {
          width: 13px;
          height: 13px;
          background: url(../assets/images/close.png) no-repeat;
          background-size: 100% 100%;
          position: absolute;
          top: 20px;
          left: -8px;
          transform: rotate(-45deg);
        }
      }
    }
  }

  .invant_card {
    width: 100vw;
    height: 100vh;
    position: absolute;
    top: 0;
    left: 0;
    background: #081b2d;

    // overflow: auto;
    .title {
      height: 0.88rem;
      font-size: 18px;
      text-align: center;
      line-height: 0.88rem;
      position: relative;
      background: white;
      color: rgba(27, 57, 71, 1);
      font-weight: bold;
      box-sizing: border-box;

      .back {
        display: flex;
        position: absolute;
        font-size: 14px;
        top: 0.2rem;
        left: 0.24rem;

        &>i {
          vertical-align: middle;
          font-style: normal;
          line-height: 26px;
        }
      }
    }

    .canvas_car {
      position: absolute;
      bottom: 1.92rem;
      top: 0.88rem;
      left: 0;
      right: 0;
      text-align: center;
      padding: 0.2rem 0;
    }

    .invitation_car {
      // display: block;
      flex: none;
      width: 15rem;
      height: 26.68rem;
      background: url(../assets/images/live/back1.png) no-repeat;
      background-size: 100% 100%;
      // border-radius: 12px;
      font-size: 28px;
      border-top: 1px solid transparent;
      position: fixed;
      top: 0;
      left: 0;

      &.background1 {
        background: url(../assets/images/live/back1.png) no-repeat;
        background-size: 100% 100%;
      }

      &.background2 {
        background: url(../assets/images/live/back2.png) no-repeat;
        background-size: 100% 100%;
      }

      &.background3 {
        background: url(../assets/images/live/back3.png) no-repeat;
        background-size: 100% 100%;
      }

      &.background4 {
        background: url(../assets/images/live/back4.png) no-repeat;
        background-size: 100% 100%;
      }

      &.background5 {
        background: url(../assets/images/live/back5.png) no-repeat;
        background-size: 100% 100%;
      }

      &.background6 {
        background: url(../assets/images/live/back6.png) no-repeat;
        background-size: 100% 100%;
      }

      &.background7 {
        background: url(../assets/images/live/back7.png) no-repeat;
        background-size: 100% 100%;
      }

      &.background8 {
        background: url(../assets/images/live/back8.png) no-repeat;
        background-size: 100% 100%;
      }

      &.background9 {
        background: url(../assets/images/live-v3/back9.png) no-repeat;
        background-size: 100% 100%;
      }

      &.background10 {
        background: url(../assets/images/live-v3/back10.png) no-repeat;
        background-size: 100% 100%;
      }

      &.background11 {
        // cooperations\live-h5\src\assets\images\live-v3\invation3.png
        background: url(../assets/images/live-v3/back11.png) no-repeat;
        background-size: 100% 100%;
      }

      &.background12 {
        // cooperations\live-h5\src\assets\images\live-v3\invation3.png
        background: url(../assets/images/live-v3/back12.png) no-repeat;
        background-size: 100% 100%;
      }

      .invitation_content {
        width: 12.8rem;
        height: 18.16rem;
        // background: rgba(255, 255, 255, 1);
        // border-radius: 12px;
        margin: 5.2rem auto 0;
        position: relative;
        border-top: 1px solid transparent;
        // padding: 0 .96rem;
        // box-sizing: border-box;

        .user_avatar {
          position: absolute;
          width: 2.4rem;
          height: 2.4rem;
          border-radius: 1.2rem;
          // background: saddlebrown;
          // border: 1px solid rgba(225,225,225,.6);
          left: 50%;
          margin-left: -2.4rem/2;
          top: -2.4rem/2;

          img {
            width: 100%;
            height: 100%;
            border-radius: 1.2rem;
            object-fit: cover;
          }
        }

        .user_name {
          margin-top: 1.6rem;
          text-align: center;
          font-size: 32px;
          font-weight: 500;
          color: #0f263c;
        }

        .course_name {
          font-size: 32px;
          text-align: center;
          color: #677b8b;
          margin-top: 0.28rem;
        }

        .course_introduce {
          margin-top: 1.4rem;
          max-height: 2.5rem;
          padding: 0 0.8rem;
          overflow: hidden;
          word-break: break-all;
          box-sizing: border-box;
          // background: saddlebrown;
          color: #0f263c;
          font-size: 40px;
          font-weight: 500;
          text-align: center;
        }

        .live_time {
          margin-top: 0.74rem * 2;
          text-align: center;
          color: #677b8b;
          font-size: 32px;
          font-weight: 400px;
        }

        .zhubo_name {
          margin-top: 0.26rem * 2;
          text-align: center;
          color: #677b8b;
          font-size: 32px;
          font-weight: 400px;
        }

        .course_share {
          // height: 3rem;
          // background: saddlebrown;
          width: 5.5rem * 2;
          margin: 0.56rem * 2 auto 0;
          display: flex;
          justify-content: center;
          border-top: 1px dotted rgba(0, 0, 0, 0.08);
          padding-top: 0.66rem * 2;

          img {
            display: block;
            width: 3.6rem;
            height: 3.6rem;
          }

          .share {
            margin-right: 0.72rem * 2;
          }
        }
      }
    }

    .invitation_car_tip {
      width: 100%;
      height: 0.6rem;
      background: #233444;
      text-align: center;
      color: #ffffff;
      font-size: 16px;
      position: absolute;
      line-height: 0.6rem;
      bottom: 1.32rem;
    }

    .background_choose_warp {
      width: 100%;
      overflow: auto;
      position: absolute;
      bottom: 0;
      height: 1.32rem;
      -webkit-overflow-scrolling: touch;

      .background_choose {
        width: 1.2rem * 6+0.8rem+0.1rem;
        height: 100%;
        padding: 0.16rem 0.4rem;
        box-sizing: border-box;

        &.pid {
          width: 1.2rem * 8+0.8rem+0.1rem;

          li {
            &:nth-of-type(1) {
              background: url(../assets/images/live/invation7.png) no-repeat;
              background-size: 100%;
            }

            &:nth-of-type(2) {
              background: url(../assets/images/live/invation8.png) no-repeat;
              background-size: 100%;
            }

            &:nth-of-type(3) {
              background: url(../assets/images/live/invation1.png) no-repeat;
              background-size: 100%;
            }

            &:nth-of-type(4) {
              background: url(../assets/images/live/invation2.png) no-repeat;
              background-size: 100%;
            }

            &:nth-of-type(5) {
              background: url(../assets/images/live/invation3.png) no-repeat;
              background-size: 100%;
            }

            &:nth-of-type(6) {
              background: url(../assets/images/live/invation4.png) no-repeat;
              background-size: 100%;
            }

            &:nth-of-type(7) {
              background: url(../assets/images/live/invation5.png) no-repeat;
              background-size: 100%;
            }

            &:nth-of-type(8) {
              background: url(../assets/images/live/invation6.png) no-repeat;
              background-size: 100%;
            }
          }
        }

        &.pid_13573 {
          width: 1.2rem * 4+0.8rem+0.1rem;

          li {
            &:nth-of-type(1) {
              background: url(../assets/images/live-v3/back12.png) no-repeat;
              background-size: 100%;
            }

            &:nth-of-type(2) {
              background: url(../assets/images/live-v3/back9.png) no-repeat;
              background-size: 100%;
            }

            &:nth-of-type(3) {
              background: url(../assets/images/live-v3/back10.png) no-repeat;
              background-size: 100%;
            }

            &:nth-of-type(4) {
              background: url(../assets/images/live-v3/back11.png) no-repeat;
              background-size: 100%;
            }
          }
        }

        li {
          width: 1rem;
          height: 1rem;
          border-radius: 2px;
          float: left;
          margin-right: 10px;

          &:nth-of-type(1) {
            background: url(../assets/images/live/invation1.png) no-repeat;
            background-size: 100%;
          }

          &:nth-of-type(2) {
            background: url(../assets/images/live/invation2.png) no-repeat;
            background-size: 100%;
          }

          &:nth-of-type(3) {
            background: url(../assets/images/live/invation3.png) no-repeat;
            background-size: 100%;
          }

          &:nth-of-type(4) {
            background: url(../assets/images/live/invation4.png) no-repeat;
            background-size: 100%;
          }

          &:nth-of-type(5) {
            background: url(../assets/images/live/invation5.png) no-repeat;
            background-size: 100%;
          }

          &:nth-of-type(6) {
            background: url(../assets/images/live/invation6.png) no-repeat;
            background-size: 100%;
          }

          &:nth-of-type(7) {
            background: url(../assets/images/live/invation6.png) no-repeat;
            background-size: 100%;
          }

          &:nth-of-type(8) {
            background: url(../assets/images/live/invation6.png) no-repeat;
            background-size: 100%;
          }

          .choose {
            height: 100%;
            background: rgba(0, 0, 0, 0.32);
            border-radius: 2px;
            position: relative;

            .choose_icon {
              display: inline-block;
              position: absolute;
              top: 0;
              bottom: 0;
              left: 0;
              right: 0;
              margin: auto;
              width: 20px;
              height: 20px;
              background: rgba(0, 0, 0, 0.6) url(../assets/images/live/choose.png) no-repeat;
              background-size: 50%;
              background-position: 50%;
              border-radius: 50%;
            }
          }
        }
      }
    }
  }

  .award_warp {
    width: 100vw;
    height: 100vh;
    position: absolute;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);

    .award_content {
      width: 12rem/2;
      height: 11.04rem/2;
      position: absolute;
      bottom: 4rem/2;
      left: 0;
      right: 0;
      margin: auto;
      background: white;
      overflow: hidden;
      border-radius: 12px/2;
    }

    .bg_top {
      height: 3.58rem/2;
      position: relative;

      .radius {
        width: 104%;
        height: 3rem;
        background: linear-gradient(180deg,
            rgba(255, 126, 116, 1) 0%,
            rgba(255, 59, 59, 1) 100%);
        box-shadow: 0px 3px 6px rgba(255, 97, 97, 0.16);
        border-radius: 50%;
        position: absolute;
        top: -60px;
        left: -0.12rem;
      }

      .content {
        width: 100%;
        position: absolute;
        text-align: center;
        color: rgba(250, 255, 117, 1);
        font-size: 16px;
        box-sizing: border-box;
        margin-top: 50px;

        .avatar {
          width: 2.52rem/2;
          height: 2.52rem/2;
          border-radius: 50%;
          padding: 5px;
          overflow: hidden;
          background: white;
          margin: 0 auto 0.3rem/2;

          img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
          }
        }

        &>p {
          color: #4d5358;
          font-size: 32px/2;
        }
      }

      .close {
        width: 0.56rem/2;
        height: 0.56rem/2;
        position: absolute;
        right: 0.4rem/2;
        top: 0.4rem/2;
        background: url(../assets/images/live-v2/close.svg) no-repeat;
        background-size: 80% 80%;
        background-position: center center;
      }
    }

    .amount_list {
      margin-top: 1.6rem;
      font-size: 32px/2;
      color: #eb4d4d;
      display: flex;
      flex-wrap: wrap;
      padding: 0 1rem/2;
      justify-content: space-between;
      align-content: space-between;
      height: 1.8rem;

      .award_money {
        width: 2.8rem/2;
        height: 1.4rem/2;
        background: rgba(255, 255, 255, 1);
        border: 1px solid rgba(235, 77, 77, 1);
        box-shadow: 0px 3px 6px rgba(255, 119, 119, 0.16);
        border-radius: 8px/2;
        line-height: 1.4rem/2;
        text-align: center;
      }
    }
  }

  .like_warp {
    width: 2rem;
    height: 6rem;
    position: fixed;
    bottom: 1rem;
    right: 0rem;
  }

  .report_warp {
    width: 100vw;
    height: 100vh;
    position: absolute;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.6);

    .inner_warp {
      width: 13rem/2;
      height: 9.4rem/2;
      background: rgba(255, 255, 255, 1);
      border-radius: 12px;
      position: absolute;
      overflow: hidden;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      margin: auto;

      .reason_item {
        background: #ffffff;
        height: 7.6rem/2;
        padding: 0 .72rem/2;
        box-sizing: border-box;
        overflow: hidden;

        .item_warp {
          display: flex;
          margin: 1.34rem/2 0 .88rem/2 0;
          justify-content: space-between;
        }

        .item {
          display: flex;

          // height: 20px;
          .radio_warp {
            display: inline-block;
            position: relative;
            width: 20px;
            height: 20px;

            input[type='radio'] {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              visibility: hidden;
            }

            input[type='radio']:checked+label {
              background: #01C2FF url(../assets/images/live-v2/Hook.svg) no-repeat;
              background-size: 100%;
              background-position: center center;
              border-color: #01C2FF;
            }

            label {
              display: inline-block;
              width: 100%;
              height: 100%;
              border-radius: 50%;
              border: 1px solid #7E8084;
              top: 0;
              left: 0;
              background: #ffffff;
              position: absolute;
            }
          }

          &>span {
            // float: left;
            font-size: 16px;
            margin-left: 12px/2;
            color: #4B4F58;
          }

          .text_area {
            flex: 1;
            font-size: 16px;
            color: #4B4F58;
            padding-left: 12px/2;
            position: relative;

            &>div {
              margin-bottom: 4px;
            }

            textarea {
              width: 100%;
              height: 2.4rem/2;
              resize: none;
              outline: none;
              border: 1px solid #D8DBE1;
              color: #4B4F58;
              font-size: 16px;
              padding: 4px;
              box-sizing: border-box;

              &::placeholder {
                color: #E0E2E5;
                font-size: 16px;
              }
            }

            .text_acout {
              position: absolute;
              bottom: 6px;
              right: 4px;
              color: #B5B9BE;
              font-size: 14px;
            }
          }
        }
      }

      .report_post {
        // background: salmon;
        height: 1.8rem/2;
        display: flex;
        border-top: 1px solid #D8DCE2;

        .btn {
          flex: 1;
          text-align: center;
          line-height: 1.8rem/2;
          font-size: 18px;
          color: #696B70;

          &.affirm {
            color: #01C2FF;
            border-left: 1px solid #D8DCE2;
          }
        }
      }
    }
  }
}
</style>
