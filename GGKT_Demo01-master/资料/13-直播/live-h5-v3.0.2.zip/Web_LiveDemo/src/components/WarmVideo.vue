<template>
<div class="warm_vieo_warp">
  <video :src="warmupUrl" playsinline="" :controls="getPageModel==0" webkit-playsinline="true" x5-video-player-type="h5" x5-video-player-fullscreen="true" autoplay="autoplay" loop="loop" style="width:100%;height:100%" ref="warm_video">
    你的浏览器不支持
  </video>
  <div class="play_btn" v-if="!onplay" @click.stop="play">
    <img :src="imgUrl" alt="" v-if="imgUrl" class="img_bg">
  </div>
</div>
</template>

<script>
import {
  mapGetters
} from "vuex";
export default {
  data() {
    return {
      onplay: false
    }
  },
  computed: {
    ...mapGetters([
      "getHtData",
      "getConfig",
      "getPageModel",
      "getLiveState"
    ]),
    warmupUrl() {
      return (this.getHtData && this.getHtData.course && this.getHtData.course.videoUrl) ? this.getHtData.course.videoUrl : ''
    },
    imgUrl() {
      let getConfig = this.getConfig
      if (this.getPageModel == 0) {
        if (getConfig && getConfig.global.switch.intro.url) {
          return getConfig.global.switch.intro.url
        }
      }
      if (this.getPageModel != 0) {
        if (getConfig && getConfig.global.switch.background && getConfig.global.switch.background.enable == 1 && getConfig.global.switch.background.url != '') {
          return getConfig.global.switch.background.url
        }
      }
      return ''
    }
  },
  watch:{
    getLiveState(nv,ov){
      if(nv === 'start'){
        this.$refs.warm_video.pause()
      }
    }
  },
  methods: {
    play() {
      this.$refs.warm_video.play()
    }
  },
  mounted() {
    this.$refs.warm_video.addEventListener('playing', () => {
      this.onplay = true
      if(this.getLiveState==='start'){
        this.$refs.warm_video.pause()
      }
      this.$emit("onplay", true)
    })
  },
}
</script>

<style lang="less" scoped>
.warm_vieo_warp {
  width: 100%;
  height: 100%;
  position: relative;

  .play_btn {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, .8);

    &::after {
      content: '';
      display: block;
      width: 1.2rem;
      height: 1.2rem;
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      margin: auto;
      background: url(~@/assets/images/ico_clickplay.png) no-repeat;
      background-size: 100% 100%;
      border-radius: 50%;
    }

    .img_bg {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }
}
</style>
