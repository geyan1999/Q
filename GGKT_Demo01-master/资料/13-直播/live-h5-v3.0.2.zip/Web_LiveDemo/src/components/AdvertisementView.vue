<template>
<div class="ad_warp" v-if="this.getConfig&&getAdlist.length>0">
  <swiper class="swiper_warp" :options="setSliderOption">
    <swiper-slide v-for="(item, index) in getAdlist" :key="parseInt(index+1)">
      <a :href="getLink(item)">
        <img :src="item.imgurl" alt="欢拓直播" class="ad_bg">
      </a>
    </swiper-slide>
  </swiper>
</div>
</template>

<script>
import {
  mapGetters
} from "vuex";
import BScroll from "better-scroll";
export default {
  data() {
    return {
      // setSliderOption: {
      //   autoplay: true,
      //   loop: true
      // }
    }
  },
  methods: {
    getLink(item) {
      if (item.type == 2) {
        return 'tel:' + item.tel
      } else {
        return item.link
      }
    }
  },
  computed: {
    ...mapGetters([
      "getConfig"
    ]),
    getAdlist() {
      let arr = []
      if (this.getConfig) {
        this.getConfig.global.switch.banner.data.forEach(element => {
          if(element.imgurl){
            arr.push(element)
          }
        });
      }
      return arr
    },
    setSliderOption(){
      let opt = {}
      if(this.getAdlist.length==1){
        opt.allowTouchMove = false
      }else{
        opt.autoplay = true
        opt.loop = true
      }
      return opt
    }
  },
  mounted() {
  }
}
</script>

<style lang="less" scoped>
.ad_warp {
  height: 2.8rem/2;

  // background: salmon;
  .swiper_warp {
    width: 100%;
    height: 100%;
    font-size: 0;
    overflow: hidden;

    .ad_bg {
      width: 100%;
      height: 100%;
      display: block;
      object-fit: cover;
    }
  }
}
</style>
