<template>
<div class="tools_wp">
  <!-- 推送卡 -->
  <card-pop :style="Index(4)" v-if="true"></card-pop>
  <!-- 签到 -->
  <sign-view :style="Index(2)"></sign-view>
  <!-- 抽奖 -->
  <lottery-view :style="Index(2)" v-if="getLottery.staus != -1"></lottery-view>
  <!-- 红包特效 -->
  <red-animation></red-animation>
  <!-- 红包 -->
  <reward-view v-show="getRewardState != 0"></reward-view>
  <!-- 公告 -->
  <notification-view :style="Index(1)"></notification-view>
  <!-- 网络线路 -->
  <netword-line :style="Index(3)" v-if="getToolsLine"></netword-line>
  <!-- 个人信息 -->
  <infomation :style="Index(3)" v-if="getToolsInfomation"></infomation>
  <!-- 投票 -->
  <keep-alive>
    <vote-view :style="Index(2)" v-if="getToolsVote"></vote-view>
  </keep-alive>
  <!-- 私聊 -->
  <keep-alive>
    <private-chat v-if="getToolsPrivate"></private-chat>
  </keep-alive>
  <!-- 商品列表 -->
  <!-- <keep-alive> -->
  <product-view v-if="getToolsProduct"></product-view>
  <!-- </keep-alive> -->
  <!-- 侧边栏工具(打赏/分享卡/点赞/关注二维码/商城二维码/举报) -->
  <side-content :style="sideIndex"></side-content>
  <!-- 全屏模式 直播信息 -->
  <top-infomation v-if="getPageModel!=0" :style="Index(1)"></top-infomation>
  <!-- 滚动通知 -->
  <scroll-notice-view v-if="getPageModel!=0"></scroll-notice-view>
  <!-- 全屏模式 直播倒计时 -->
  <timer-count v-if="getPageModel!=0" :style="Index(2)"></timer-count>
  <!-- 课件模式 暖场视频 -->
  <div class="masker" v-if="getPageModel==2 && getLiveState !== 'start' && getVideoCurMode==0 && getConfig.global.switch.warmup && getConfig.global.switch.warmup.enable==1" :style="[background]">
    <warm-video></warm-video>
  </div>
  <!-- 全屏模式 浮动广告 -->
  <float-ad v-if="getPageModel==1&&!clear"></float-ad>
  <!-- 全屏模式 问答 -->
  <keep-alive>
    <question-view v-if="getPageModel!=0&&getToolsQuestion" :style="Index(2)"></question-view>
  </keep-alive>
  <!-- 全屏模式 邀请榜单 -->
  <rank-view v-if="getPageModel!=0&&getToolsRank" :style="Index(2)"></rank-view>
  <!-- 全屏模式 菜单模块 -->
  <div class="full_tab" :class="{show:getToolsMenu}" v-if="getPageModel!=0" @click.stop="">
    <tab-com class="tab"></tab-com>
    <tab-item-com class="tab_item"></tab-item-com>
  </div>
  <!-- 全屏模式 聊天列表 -->
  <chat-view v-if="getPageModel!=0" :style="Index(0)"></chat-view>
  <!-- 底部控制栏 -->
  <chat-post v-show="(getActModule==='chat'&&getPageModel!=1)||getPageModel!=0" :style="Index(1)"></chat-post>
</div>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex"
import LotteryView from "@/components/LotteryView"
import NetwordLine from "@/components/NetwordLine"
import PrivateChat from "@/components/PrivateChat"
import ProductView from "@/components/ProductView"
import RankView from "@/components/RankView"
import RedAnimation from "@/components/RedAnimation"
import RewardView from "@/components/RewardView"
import Infomation from "@/components/Infomation"
import VoteView from "@/components/VoteView"
import ScrollNoticeView from "@/components/ScrollNoticeView"
import NotificationView from "@/components/NotificationView"
import SideContent from "@/components/SideContent"
import ChatPost from "@/components/ChatPost"
import ChatView from "@/components/ChatView"
import TopInfomation from "@/components/TopInfomation";
import TimerCount from "@/components/TimerCount"
import QuestionView from "@/components/QuestionView"
import SignView from "@/components/SignView";
import TabCom from "@/components/TabCom";
import TabItemCom from "@/components/TabItemCom";
import CardPop from "@/components/CardPop";
import WarmVideo from "@/components/WarmVideo"
import FloatAd from "@/components/FloatAd"
import * as TYPES from "@/assets/action-types"
export default {
  data() {
    return {

    };
  },
  props:['clear'],
  computed: {
    ...mapGetters([
      "getSideMode",
      "getToolsQuestion",
      "getToolsPrivate",
      "getToolsProduct",
      "getToolsLine",
      "getToolsInfomation",
      "getToolsVote",
      "getToolsRank",
      "getToolsRedAnimation",
      "getToolsMenu",
      "getPageModel",
      "getMemberTotal",
      "getHtData",
      "getLiveState",
      "getScreenStatus",
      "getActModule",
      "getRewardState",
      "getListReward",
      "getRewardDebug",
      "getFlagReward",
      "liveCurMode",
      "getLottery",
      "getVideoCurMode",
      "getVideoStatus",
      "getPPTModel",
      "getVideoPause",
      "getConfig",
      "getZhuboRewardMsg",
      "getCameraStatus",
      "getUser",
      "getAnchorimg",
      "getVotePopStatus"
    ]),
    pid() {
      if (this.isVod) {
        if (this.getHtData && this.getHtData.pid) {
          return this.getHtData.pid
        }
      } else {
        if (this.getHtData && this.getHtData.zhubo && this.getHtData.zhubo.partner_id) {
          return this.getHtData.zhubo.partner_id
        }
      }
      return 0
    },
    sideIndex() {
      let index = (this.getSideMode == 0 || this.getSideMode == 6) ? 0 : 4
      return {
        zIndex: index + 200
      }
    },
    background() {
      let getConfig = this.getConfig
      if (getConfig && getConfig.global.switch.background && getConfig.global.switch.background.enable == 1 && getConfig.global.switch.background.url != '') {
        return {
          background: 'url(' + getConfig.global.switch.background.url + ') no-repeat',
          backgroundSize: '100% 100%',
        }
      } else {
        return false
      }
    }
  },
  components: {
    LotteryView,
    NetwordLine,
    PrivateChat,
    ProductView,
    RankView,
    RedAnimation,
    RewardView,
    Infomation,
    SideContent,
    VoteView,
    ChatPost,
    ChatView,
    ScrollNoticeView,
    NotificationView,
    TopInfomation,
    TimerCount,
    QuestionView,
    SignView,
    TabCom,
    TabItemCom,
    CardPop,
    WarmVideo,
    FloatAd
  },
  watch:{
    
  },
  methods: {
    Index(index) {
      return {
        zIndex: index + 200
      }
    }
  },
};
</script>

<style lang="less" scoped>
.full_tab {
  &.show {
    height: 50vh;
  }

  position: absolute;
  bottom: 0;
  width: 100%;
  height: 0;
  z-index: 400;
  display: flex;
  flex-direction: column;
  transition: .5s;
  z-index: 3000;

  .tab {
    width: 100%;
    height: .8rem;
    flex: none;

    .ht_nav_box {
      height: 0;
    }
  }

  .tab_item {
    flex: 1;
  }
}

.masker {
  position: absolute;
  top: 5.6rem;
  left: 0;
  right: 0;
  bottom: 3rem;
}
</style>
