<template>
<div id="petalbox" v-show="getToolsRedAnimation">
</div>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex"
import * as TYPES from "@/assets/action-types"
import red from '@/assets/js/red-animation';
export default {
  data() {
    return {
      red_animation_timer: null
    }
  },
  computed: {
    ...mapGetters(["getToolsRedAnimation", "getZhuboRewardMsg"])
  },
  methods: {
    show() {
      let timer = setInterval(() => {
        this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
          type: 'redAnimation',
          flag: true
        })
      }, 10 * 1000);
    }
  },
  watch: {
    getZhuboRewardMsg(nd, od) {
      if (!this.red_animation_timer) {
        // this.red_animation = true
        this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
          type: 'redAnimation',
          flag: true
        })
        this.red_animation_timer = setTimeout(() => {
          //   this.red_animation = false
          this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
            type: 'redAnimation',
            flag: false
          })
          this.red_animation_timer = null
        }, 8000)
      }
    },
    getToolsRedAnimation(nd, od) {
      if (!nd) {
        if (this.red_animation_timer) {
          clearTimeout(this.red_animation_timer)
          this.red_animation_timer = null
        }
      }
    }
  },
  mounted() {
    red()
    // this.show()
  }
}
</script>

<style src="../assets/less/red_animation.css"></style>
