<template>
<div class="marquee" v-if="isShow" :class="{full:getPageModel!=0,coures_mod:getPageModel==2}">
  <div class="_icon _icon1"></div>
  <div class="_msg">
    <div>
      <span v-if="link===''">{{ content }}</span>
      <a :href="link" v-else>{{ content }}</a>
    </div>
  </div>
  <div class="_icon _icon2" @click.stop="autoHide(0)"></div>
</div>
</template>

<script>
import {
  mapGetters
} from "vuex";
export default {
  name: "ScrollNoticeView",
  data() {
    return {
      content: "",
      isShow: false,
      link: ''
    };
  },
  // 方法
  methods: {
    autoHide(dalay) {
      setTimeout(() => {
        this.isShow = false;
      }, dalay * 1000);
    }
  },
  // 计算
  computed: {
    ...mapGetters(["getRollNotice", "getPageModel", "getHtData"])
  },
  watch: {
    getRollNotice(newVal, oldVal) {
      if (typeof newVal === "object") {
        this.isShow = true;
        this.content = newVal.content;
        this.link = newVal.link;
        this.autoHide(newVal.duration);
      }
    }
  },
  mounted() {
    if (this.getRollNotice && this.getRollNotice.content) {
      this.content = this.getRollNotice.content
      this.link = this.getRollNotice.link
      this.isShow = true;
      this.autoHide(this.getRollNotice.duration)
    }
  },
};
</script>

<style lang="less" scoped>
.marquee {
  width: 100%;
  white-space: nowrap;
  overflow: hidden;
  position: absolute;
  z-index: 200;
  display: flex;
  background: #01C2FF;
  height: 1rem/2;
  padding: 6px;
  box-sizing: border-box;
  top: 0;

  &.full {
    left: 50%;
    transform: translateX(-50%);
    top: 4.4rem/2;
    width: 13rem/2;
    height: 1.2rem/2;
    background: rgba(255, 76, 70, .6);
    border-radius: .4rem;
    overflow: visible;
    padding-left: 0;

    ._msg {
      font-size: 14px;
      margin-left: 4px;

      &>div {
        // line-height: 0.36rem;
        // transform: translate(0,0);
        display: flex;
        align-items: center;
        // background: fuchsia;
      }

      ._icon {
        width: 18px;
        height: 100%;
      }
    }

    ._icon1 {
      width: 1.84rem/2;
      height: 1.6rem/2;
      background: url(../assets/images/live-v3/notice.png) no-repeat !important;
      background-size: 100% 100% !important;
      top: -16px;
      position: relative;

      &::after {
        content: '';
        display: none !important;
      }
    }
  }

  &.coures_mod {
    top: 0;

    ._icon1 {
      width: 1.54rem/2;
      height: 1.2rem/2;
      background: url(../assets/images/live-v3/notice.png) no-repeat !important;
      background-size: 100% 100% !important;
      top: -7px;
      position: relative;

      &::after {
        content: '';
        display: none !important;
      }
    }
  }

  ._icon {
    flex: none;
    width: 16px;
    height: 100%;

    // background: #ffffff;
    &._icon1 {
      background: url(../assets/images/live-v2/notice.svg) no-repeat;
      background-size: 100% 100%;
      position: relative;

      &::after {
        content: '';
        display: block;
        width: 1px;
        height: 100%;
        background: #FFFFFF;
        position: absolute;
        right: -5px;
        top: 0;
      }
    }

    &._icon2 {
      background: url(../assets/images/live-v2/close.svg) no-repeat;
      background-size: 70% 70%;
      background-position: center center;
    }
  }

  ._msg {
    flex: 1;
    margin: 0 2px 0 8px;
    white-space: nowrap;
    font-size: 12px;
    color: #ffffff;
    position: relative;
    overflow: hidden;

    &>div {
      position: absolute;
      padding-left: 100%;
      height: 100%;
      animation: marquee 20s linear infinite;
      line-height: 0.26rem;

      // transform: translate(0,0);
      &>a {
        color: #ffffff;
      }
    }
  }

  @keyframes marquee {
    0% {
      transform: translate(0, 0);
    }

    100% {
      transform: translate(-100%, 0);
    }
  }
}
</style>
