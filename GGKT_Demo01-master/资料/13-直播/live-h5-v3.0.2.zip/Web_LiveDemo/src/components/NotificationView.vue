<template>
  <div class="mod_notification_layer" v-if="isShow">
    <h2>公告</h2>
    <x-icon class="ico_close" type="close" size="10" @click.stop="closeTip"></x-icon>
    <div class="content">
      <pre>{{ noticeContent }}</pre>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  name: 'publicNotification',
  data () {
    return {
      isShow: false,
      noticeContent: ''
    }
  },
  computed: {
    ...mapGetters([
      'getPublicNotice'
    ])
  },
  watch: {
    getPublicNotice (newKey, oldKey) {
      if (newKey.content && newKey.content.length > 0) {
        this.noticeContent = newKey.content
        this.isShow = true
      } else {
        this.isShow = false
      }
    }
  },
  methods: {
    closeTip () {
      this.isShow = !this.isShow
    }
  },
  mounted() {
    if(this.getPublicNotice&&this.getPublicNotice.content){
      this.noticeContent = this.getPublicNotice.content
      this.isShow = true
    }
  },
}
</script>

<style lang="less" scoped>
  .mod_notification_layer {
    .ico_close {
      padding: 5px;
      background: #ffe676;
      border-radius: 50em;
      color: #fffbe7;
      position: absolute;
      right: 10px;
      top: 10px;
    }
    h2 {
      font-size: 14px;
      text-align: center;
      font-weight: bold;
      color: #333333;
    }
    .content {
      font-size: 12px;
      margin-top: 10px;
      max-height: 150px;
      overflow-y: scroll;
      pre {
        white-space: pre-line;
        text-align: center;
      }
    }
    position: absolute;
    margin: 20px;
    padding: 10px 15px;
    border-radius: 5px;
    line-height: 20px;
    z-index: 501;
    background: #fffbe7;
    border: 1px solid #ffd736;
    top: 0;
    right: 0;
    left: 0;
    font-size: 12px;
    box-shadow: 0 0 14px 0px rgba(0, 0, 0, 0.1);
  }
</style>
