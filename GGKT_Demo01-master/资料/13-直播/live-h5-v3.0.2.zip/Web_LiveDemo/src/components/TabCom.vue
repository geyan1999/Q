<template>
<div>
  <nav class="com_menu_head" :class="{red:styleRed}">
    <!--导航-->
    <ul class="ht_nav_list" :class="{full_mode:getPageModel!=0}">
      <template v-for="(item,index) in getConfig.content.tabsData">
        <li :key="index" :class="{selected:getActModule === 'chat'}" @click.stop="toggleMenu('chat')" v-if="getPageModel == 0 && item.type==='chat' || item.type==='chat' && isVod">
          {{item.title}}
          <span v-if="isVod">(<span class="c_num">{{getChatList.length===0?'0':getChatList.length+1}}</span>)</span>
        </li>
        <!-- <li :key="index" :class="{selected:getActModule === 'question'}" @click.stop="toggleMenu('question')" v-if="getPageModel!=1&&item.type==='question'">问答</li> -->
        <li :key="index" :class="{selected:getActModule === 'invite'}" @click.stop="toggleMenu('invite')" v-if="getPageModel == 0&&item.type==='invite'">{{item.title}}</li>
        <li :key="index" :class="{selected:getActModule === 'courseware'}" @click.stop="toggleMenu('courseware')" v-if="item.type==='courseware'&&getPageModel!=2">{{item.title}}</li>
        <li :key="index" :class="{selected:getActModule === (item.title+index)}" @click.stop="toggleMenu(item.title+index)" v-if="item.type==='editor'">{{item.title}}</li>
      </template>
      <li :class="{selected:getActModule === 'question'}" @click.stop="toggleMenu('question')" v-if="getPageModel==0 && !isVod && getConfig && getConfig.global.switch.question &&getConfig.global.switch.question.enable==1">问答</li>
      <li class="placehoder" v-if="getPageModel!=1&&getConfig&&getConfig.global.switch.focus.enable==1"></li>
    </ul>
    <div class="focus" @click.stop="goFocus" v-if="getConfig&&getConfig.global.switch.focus.enable==1&&getPageModel==0" @click="goFocus()">
      <span>关注</span>
      <div class="mask"></div>
    </div>
  </nav>
</div>
</template>

<script>
import {
  mapGetters,
  mapMutations,
  Action,
  mapActions
} from "vuex";
import * as TYPES from "@/assets/action-types";
import fixOverflowScroll from "fix-overflow-scroll";
export default {
  name: "TabCom",
  data() {
    return {
      quesIsLoaded: false,
      isVod: window.isVod && window.isVod == 1 ? true : false,
      tabName: {}
    };
  },
  computed: {
    ...mapGetters([
      "getActModule",
      "getVideoMode",
      "getPageInfo",
      "getTabInfo",
      "getPageModel",
      "getModeSwitch",
      "getPPTModel",
      "getConfig",
      "getChatList",
      "getPageModel",
      "getHtData"
    ]),
    pid() {
      if (this.isVod) {
        if (this.getHtData && this.getHtData.pid) {
          return this.getHtData.pid
        }
      } else {
        if (this.getHtData && this.getHtData.zhubo && this.getHtData.zhubo.partner_id) {
          return this.getHtData.zhubo.partner_id
        }
      }
      return 0
    },
    styleRed() {
      let pids = window.annual_config_pid || []
      return pids.some((pid) => {
        return pid == this.pid
      }) && this.getPageModel == 0
    }
  },
  methods: {
    ...mapActions({
      updateQuesList: "UPDATE_QUESTION_LIST",
      updateRankList: "GET_RANK_LIST"
    }),
    toggleMenu(menu) {
      if (!this.quesIsLoaded && menu === "question") {
        // todo 有问题
        // 初始化问答列表
        this.HTSDK.getQuestion(res => {
          this.quesIsLoaded = true;
          // console.log('[debug]:: res => ', res)
          if (res && res.count > 0) {
            // this.$store.dispatch(types)
            // console.warn(this)
            this.updateQuesList({
              type: "list",
              data: res.data
            });
          }
          this.$store.commit("UPDATE_PAGE_TAB", menu);
          this.$vux.loading.hide()
        });
        this.$vux.loading.show({
          text: "Loading"
        });
      } else if (menu === "invite" && this.getActModule !== "invite") {
        // 加载
        this.updateRankList({
          vm: this,
          data: {
            access_token: window.access_token ||
              "ITN4Q2N5YjZmljY3gDMxMmZ0UTOxkjNmJzNxczYmhjZ8xHf9JSNxgjMyMzX4YDNxIDOiojIl1WYuJnIsEjOiEmIsAjOiQWanJCL1EDOyIzM6ICZp9VZzJXdvNmIsIiI6IichRXY2FmIsAjOiIXZk5WZnJCLzgTO1ITNzYTNxojIlJXawhXZiwyM4MDNwUzM2UTM6ISZtlGdnVmciwSXbpjIyRHdhJCLiIXZzVnI6ISZs9mciwCM5UDMyUzM3ojIklGeiwiIadkTPhURFxkI6ISZtFmbrNWauJCLwojIklmYiwiIxAjN2czXkJXaoRnI6ICZpVnIsgjN0EjM4ojIklWbv9mciwiNwMTMxojIklGciwiNwMTMxojIkl2XyVmb0JXYwJye",
            page: 1,
            rank: "rank"
          }
        });
        this.$vux.loading.show({
          text: "Loading"
        });
        this.$store.commit("UPDATE_PAGE_TAB", menu);
      } else {
        this.$store.commit("UPDATE_PAGE_TAB", menu);
      }
    },
    config(type) {
      let flag = false;
      if (this.getConfig) {
        this.getConfig.content.tabsData.forEach((item) => {
          this.tabName[item.type] = item.title
          if (item.type === type) {
            flag = true
          }
        })
      }
      return flag
    },
    fullInfo(tab) {
      // 全屏默认当前菜单项的加载方法 特殊逻辑--聊天和榜单的菜单配置不在tab的配置里，单独判断
      let tabsData = tab
      let curtab = ''
      for (let i = 0; i < tabsData.length; i++) {
        if (tabsData[i].type !== 'chat' && tabsData[i].type !== 'invite' && !(this.getPageModel == 2 && tabsData[i].type === 'courseware')) {
          curtab = tabsData[i].type === 'editor' ? tabsData[i].title + i : tabsData[i].type
          break
        }
      }
      this.$store.commit("UPDATE_PAGE_TAB", curtab);
    },
    comInfo(tab) {
      // 半屏默认当前菜单项的加载方法 -- 逻辑 半屏当前菜单的所有配置都在tab的配置里,不需要单独判断
      let tabsData = tab
      let curtab = ''
      if (tabsData.length === 0) {
        curtab = 'chat'
      } else {
        curtab = tabsData[0].type === 'editor' ? tabsData[0].title + 0 : tabsData[0].type
      }
      this.$store.commit("UPDATE_PAGE_TAB", curtab);
    },
    tabInfo(config) {
      // 初始化配置加载
      let _tabs = config && config.content.tabsData || []
      let pageMode = config && config.global.setting.pageViewMode || 0 //默认半屏
      pageMode == 0 || this.isVod ? this.comInfo(_tabs) : this.fullInfo(_tabs)
      // if (_tabs instanceof Array && _tabs.length > 0) {
      //   // 回放暂时也用半屏模式
      //   pageMode == 0 || this.isVod ? this.comInfo(_tabs) : this.fullInfo(_tabs)
      // } else {
      //   this.$store.commit("UPDATE_PAGE_TAB", '');
      // }
    },
    goFocus() {
      this.$store.commit(TYPES.UPDATE_SIDE_MODE, 1);
    },
  },
  mounted() {
    this.tabInfo(this.getConfig)
  }
};
</script>

<style lang="less" scoped>
.com_menu_head {
  width: 100vw;
  height: 100%;
  overflow: hidden;
  position: relative;
  background: #fff;
  display: flex;
  align-items: center;
  padding: 0 15px;
  box-sizing: border-box;

  &.red {
    background: #A71A16;
    box-shadow: 0px 1px 0px rgba(0, 0, 0, 0.08);

    .ht_nav_list {
      li {
        background: none;
        color: #FFCD8B;
        opacity: .5;

        &.selected {
          border-bottom: 4px solid #FFCD8B;
          color: #FFCD8B;
          font-weight: bold;
          opacity: 1;
        }
      }
    }

    .focus {
      background: #FFCD8B;
      color: #AC0404;

      .mask {
        background: linear-gradient(90deg, rgba(167, 26, 22, .5) 0%, rgba(167, 26, 22, 1) 100%);
      }
    }
  }

  // background: #A71A16;
  // box-shadow: 0px 1px 0px rgba(0, 0, 0, 0.08);
  // padding-top: 6px;

  .ht_nav_list {
    flex: 1;
    height: 100%;
    list-style: none;
    padding: 0 0 15px 0;
    margin-top: 11px;
    font-size: 0;
    white-space: nowrap;
    overflow-x: scroll;
    overflow-y: hidden;
    display: flex;
    position: relative;

    &.full_mode {
      li {
        // flex: 1;
        // max-width: 50%;
      }
    }

    li {
      //  position: absolute;
      flex: none;
      background: white;
      min-width: 18%;
      height: 100%;
      font-size: 14px;
      text-align: center;
      line-height: 0.9rem;
      margin-right: .64rem/2;
      color: #797979;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;

      // &:nth-last-of-type(2) {
      //   margin: 0;
      // }

      &.selected {
        border-bottom: 2px solid #01c2ff;
        color: #01c2ff;
        font-weight: bold;
      }

      &.placehoder {
        width: 4px;
        margin: 0;
        flex: none;
        min-width: 0;
      }
    }

  }

  .focus {
    flex: none;
    width: 2.2rem/2;
    height: 1.2rem/2;
    background: #01C2FF;
    color: #FFFFFF;
    font-size: 15px;
    border-radius: .44rem;
    // margin-right: 15px;
    position: relative;

    &>span {
      position: absolute;
      top: 4px;
      left: 12px;
    }

    .mask {
      position: absolute;
      width: .8rem/2;
      height: 100%;
      background: linear-gradient(270deg, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 0.5) 100%);
      left: -.8rem/2;
      top: 0;
    }
  }
}
</style>
