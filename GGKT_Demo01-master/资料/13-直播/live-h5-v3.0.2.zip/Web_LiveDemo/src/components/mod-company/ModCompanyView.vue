<template>
<div class="mod-company-wp" :class="getScreenStatus">
  <!-- <textarea name="" cols="30" rows="10" class="log" v-model="getRewardDebug" v-if="getFlagReward"></textarea> -->
  <div id="warp_top">
    <div class="view_container" @click="control">
      <!-- 观看人数 -->
      <online-total :style="Index(4)"></online-total>
      <div class="_masker" :class="{model_16_9:advertisement}" v-if="getConfig&&getConfig.global.switch.warmup&&getConfig.global.switch.warmup.enable==1&&getLiveState !== 'start'" :style="Index(3)">
        <warm-video></warm-video>
      </div>
      <!-- 视频区域 -->
      <div id="ht_camera_container" class="live" :class="{model_16_9:advertisement}" v-show="liveCurMode === 0"></div>
      <!-- 桌面分享 -->
      <div id="ht_player_container" class="live" :class="{model_16_9:advertisement}" v-show="liveCurMode === 2"></div>
      <!-- 摄像头状态 -->
      <div class="camera_status" v-if="getCameraStatus === 'close' && getLiveState === 'start' && liveCurMode === 0" :style="Index(2)">
        <div class="zhubo_image">
          <img :src="getAnchorimg" alt="">
          <div class="loader loader-7">
            <!-- <div class="line line1"></div>
            <div class="line line2"></div>
            <div class="line line3"></div> -->
          </div>
          <div class="tip">语音直播中</div>
        </div>
      </div>
      <!-- 播放器加载动画 -->
      <div class="_masker_loading" v-if="getLiveState === 'start' && getVideoCurMode==0 && getVideoStatus==='waiting' && !getVideoPause && getCameraStatus !== 'close'" :style="Index(1)">
        <div class="loader loader-7">
          <div class="line line1"></div>
          <div class="line line2"></div>
          <div class="line line3"></div>
          <div class="text_line">正在加载直播...</div>
        </div>
      </div>
      <!-- 视频遮罩 -->
      <div class="_masker" :class="{model_16_9:advertisement}" v-if="getLiveState !== 'start' && getVideoCurMode==0 && !(getConfig.global.switch.warmup && getConfig.global.switch.warmup.enable==1)" :style="Index(2)">
        <img :src="getConfig.global.switch.intro.url" alt="" v-if="getConfig&&getConfig.global.switch.intro.url" class="intro">
        <span v-if="!(getConfig&&getConfig.global.switch.intro.url)">{{liveState}}</span>
      </div>
      <div class="control" v-show="controlShow" v-if="getLiveState === 'start'" :style="Index(2)">
        <!-- 刷新视频 -->
        <div class="replay" @click.stop="replay()" :class="{replaying:timer}"></div>
        <!-- 全屏 -->
        <div class="full_screen_btn" @click.stop="full()"></div>
      </div>
    </div>
    <!-- 广告位 -->
    <advertisement-view v-if="getConfig&&getConfig.global.switch.banner.enable==1"></advertisement-view>
    <!-- 导航栏 -->
    <tab-com class="tab"></tab-com>
  </div>
  <!-- 菜单区域 -->
  <tab-item-com></tab-item-com>
  <!-- 工具栏 -->
  <tools-view></tools-view>
  <!-- 加载中动画 -->
  <div class="loading hidden" id="loading">
    <div class="loading_bg">
      正在加载中
      <div class="cicle_warp">
        <div class="cicle1 cicle"></div>
        <div class="cicle2 cicle"></div>
        <div class="cicle3 cicle"></div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
import {
  mapGetters
} from "vuex";
import OnlineTotal from "../OnlineTotal";
import TabItemCom from "../TabItemCom";
import ScrollNoticeView from "../ScrollNoticeView";
import TabCom from "../TabCom";
import RewardView from "../RewardView";
import LotteryView from "../LotteryView";
import Vote from "../VoteView"
import SideContent from "../SideContent";
import RedAnimation from "../RedAnimation"
import AdvertisementView from "../AdvertisementView"
import ToolsView from "@/components/ToolsView"
import WarmVideo from "@/components/WarmVideo"
import * as util from "../../assets/js/util";
export default {
  name: "ModCompanyView",
  data() {
    return {
      maskInfo: "正在加载...",
      re_text: "刷新",
      isreplay: false,
      timer: null,
      advertisement: true,
      isIos: false,
      controlShow: false,
      controlTimer: null,
      onplay:false
    };
  },
  components: {
    OnlineTotal,
    TabItemCom,
    ScrollNoticeView,
    TabCom,
    RewardView,
    LotteryView,
    SideContent,
    RedAnimation,
    AdvertisementView,
    Vote,
    ToolsView,
    WarmVideo
  },
  methods: {
    back() {
      if (window.history) {
        window.history.back()
      }
    },
    control() {
      this.controlShow = true
      if (this.controlTimer) {
        clearTimeout(this.controlTimer);
      }
      this.controlTimer = setTimeout(() => {
        this.controlShow = false
      }, 3000);
    },
    replay() {
      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => {
        if (this.HTSDK) {
          this.HTSDK.reload();
          this.timer = null;
        }
      }, 1000);
    },
    full() {
      let targetDiv = this.liveCurMode == 0 ? document.querySelector("#ht_camera_container") : document.querySelector("#ht_player_container");
      let video = targetDiv.getElementsByTagName("video")[0]
      if (video && video.webkitEnterFullScreen) {
        video.webkitEnterFullScreen()
        if (this.isIos) {
          video.addEventListener('pause', () => {
            video.play()
          })
        }
      }
    },
    config(type) {
      let flag = false;
      if (this.getConfig) {
        this.getConfig.content.tabsData.forEach((item) => {
          if (item.type === type) {
            flag = true
          }
        })
      }
      return flag
    },
    Index(index) {
      return {
        zIndex: index + 100
      }
    }
  },
  computed: {
    ...mapGetters([
      "getMemberTotal",
      "getHtData",
      "getLiveState",
      "getScreenStatus",
      "getActModule",
      "getRewardState",
      "getListReward",
      "getRewardDebug",
      "getFlagReward",
      "liveCurMode",
      "getLottery",
      "getVideoCurMode",
      "getVideoStatus",
      "getPPTModel",
      "getVideoPause",
      "getConfig",
      "getZhuboRewardMsg",
      "getCameraStatus",
      "getUser",
      "getAnchorimg",
      "getCourseTimeToEnd"
    ]),
    isHorizontal() {},
    resizeDoc() {
      if (this.toolsKits.doc) {
        return {
          width: "100%",
          height: "100%"
        };
        this.HTSDK.playerResize();
      } else {
        return "";
      }
    },
    zhuboAvatar() {
      return {
        backgroundImage: "url(" + this.zhubo.p_40 + ")"
      };
    },
    liveState() {
      if (this.getLiveState === "wait") {
        return "主播暂时不在，稍后再来"
      } else if (this.getLiveState === "stop") {
        return "直播已结束"
      }
    },
    warmupUrl() {
      return (this.getHtData && this.getHtData.course && this.getHtData.course.videoUrl) ? this.getHtData.course.videoUrl : ''
    }
  },
  watch: {
    getHtData(nv, ov) {
      this.zhubo = nv.zhubo;
    },
    getVideoStatus(nv, ov) {
      if (nv === "overTime") {
        this.HTSDK.reload();
      }
    },
  },
  mounted() {
    this.isIos = util.isIos()
    this.control()
    if (this.getConfig && this.getConfig.global.switch.banner.enable == 1) {
      this.advertisement = true
    }
  }
};
</script>

<style src='@/assets/less/mod_company.less' lang='less'></style>
