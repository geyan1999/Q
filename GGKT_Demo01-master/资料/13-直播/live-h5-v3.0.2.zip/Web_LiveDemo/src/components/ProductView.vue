<template>
<transition name="fade">
  <div id="wp_product" class="product_warp" @click.stop="">
    <div class="_title">
      商品
      <span v-show="curProductIdList.length>0">
        (<span>{{curProductIdList.length}}</span>)
      </span>
    </div>
    <div class="no_data" v-show="curProductIdList.length==0">
      <span class="tip">暂无商品</span>
    </div>
    <div class="product_list_warp" id="product_scroller" v-show="curProductIdList.length>0">
      <ul>
        <li class="product_list" v-for="(item,index) in curProductIdList" :key="index">
          <div @click.stop="goLink(item)">
            <div class="product_item">
              <div class="product_image">
                <div class="index">{{index+1}}</div>
                <img :src="item.img" alt class="avatar" />
              </div>
              <div class="product_list_data">
                <div class="product_title">{{item.name}}</div>
                <div class="product_infomation">
                  <div class="right">
                    <div class="tag" :class="'type_'+item.tab" v-show="item.tab">{{tabType[item.tab]}}</div>
                    <div class="price">
                      <span class="selling" v-show="item.price">
                        ￥
                        <span>{{item.price}}</span>
                      </span>
                      <span class="original" v-show="item.originalPrice">
                        ￥
                        <span>{{item.originalPrice}}</span>
                      </span>
                    </div>
                  </div>
                  <div class="left" v-if="item.pay==1 || !item.pay">
                    <div class="go_list">{{item.link_text?item.link_text:'去看看'}}</div>
                  </div>
                </div>
              </div>
              <div class="product_qrcode" v-if="item.pay==2">
                <img :src="item.qrcode" alt class="qrcode" />
                <p>长按购买</p>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</transition>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
import BScroll from "better-scroll";
import * as TYPES from "@/assets/action-types";
export default {
  props: ['popShow'],
  data() {
    return {
      tabType: ['', '特价', '限时', '新品', '钜惠', '秒杀'],
      isVod: window.isVod && window.isVod == 1 ? true : false,
      num: 0,
      cms_timer: null,
    };
  },
  watch: {
    getToolsProduct(nv) {
      if (!nv) {
        // this.bscroller.isScrolled = false
      } else {
        this.num += 1
      }
    }
  },
  methods: {
    close() {
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'product',
        flag: false
      })
    },
    // 链接差异化
    goLink(good) {
      let url = good.url || ''
      if (good.pay == 1 || good.pay == undefined) {
        if (url.match(/\[wx\]/)) {
          url = url.replace('[wx]', '')
          if (window.wx) {
            window.wx.miniProgram.navigateTo({
              url: url
            })
          }
          return false
        } else {
          window.location.href = url
        }
      }
    }
  },
  computed: {
    ...mapGetters(["getPageModel", "getConfig", "getProductIdList", "getHtData", "getToolsProduct"]),
    curProductIdList() {
      let arr = []
      this.getProductIdList.forEach((product) => {
        if (product.putaway != 0) {
          arr.push(product)
        }
      })
      return arr
    }
  },
  mounted() {
  }
};
</script>

<style lang="less" scoped>
.product_warp {
  background: rgba(225, 225, 225, 1);
  overflow: hidden;
  position: relative;
  width: 100%;
  position: absolute;
  bottom: 0;
  height: 70vh;
  z-index: 2000;
  // transition: 0.5s;
  border-radius: 20px/2 20px/2 0px 0px;
  background: #ffffff;
  // display: flex;
  // flex-direction: column;

  ._title {
    text-align: center;
    height: 1.76rem/2;
    line-height: 1.76rem/2;
    border-radius: 20px/2 20px/2 0px 0px;
    font-size: 32px/2;
    color: #1b3947;
    border-bottom: 1px solid #EBEFF2;
    // flex: none;
    position: relative;

    .close_btn {
      position: absolute;
      right: .2rem;
    }
  }

  // &.producUp {
  //   height: 70vh;
  // }

  .no_data {
    position: absolute;
    width: 100px;
    height: 120px;
    background: url(~@/assets/images/live-v3/product.png) no-repeat;
    background-size: 100%;
    top: 2.5rem;
    left: 0;
    right: 0;
    margin: auto;

    .tip {
      width: 100%;
      text-align: center;
      position: absolute;
      font-size: 16px;
      color: rgba(158, 176, 196, 1);
      bottom: -10px;
    }
  }

  .product_list_warp {
    position: absolute;
    top: 1.76rem/2;
    bottom: 0;
    left: 0;
    right: 0;
    font-size: 16px;
    // height: 13.5rem/2;
    overflow-y: scroll;
    overflow-x: hidden;
    -webkit-overflow-scrolling: touch;
    // flex: 1;
    padding-right: 10px;
    margin-right: -10px;

    ul {
      list-style: none;
      padding: 0;
    }

    .product_list {
      position: relative;
      box-sizing: border-box;
      padding: 0 0.5rem/2;

      &>a {
        text-decoration: none;
      }

      &:nth-last-of-type(1) .product_item {
        border-bottom: none;
      }

      .product_item {
        border-bottom: 1px solid #EEEEEF;
        padding: 0.5rem/2 0;
        box-sizing: border-box;
        display: flex;
        // align-items: center;

        .product_image {
          flex: none;
          overflow: hidden;
          border-radius: 8px/2;
          width: 3.4rem/2;
          height: 3.4rem/2;
          position: relative;

          .index {
            width: 0.88rem/2;
            height: 0.64rem/2;
            background: rgba(0, 0, 0, 0.45);
            border-radius: 8px/2 0px 8px/2 0px;
            position: absolute;
            top: 0;
            left: 0;
            font-size: 14px;
            color: #ffffff;
            line-height: 0.64rem/2;
            text-align: center;
          }

          .avatar {
            width: 100%;
            height: 100%;
            display: block;
            // background: salmon;
          }
        }

        .product_list_data {
          flex: 1;
          font-size: 14px;
          // height: 3.4rem/2;
          display: flex;
          flex-direction: column;
          margin-left: 0.2rem;

          .product_title {
            flex: none;
            line-height: 1.5em;
            min-height: .7rem;
            color: #4D5358;
          }

          .product_infomation {
            // background: seagreen;
            display: flex;
            flex: 1;
            padding-top: 0.08rem;
            justify-content: space-between;
            align-items: center;

            .right {
              display: flex;

              .tag {
                width: 1.36rem/2;
                height: 0.72rem/2;
                line-height: 0.72rem/2;
                text-align: center;
                // background: rgba(255, 129, 129, 1);
                border-radius: 2px/2;
                // color: #ffffff;
                font-size: 12px;
                margin-bottom: 0.1rem;

                &.type_1 {
                  // background: #FFB881;
                  border: 1px solid #FFB881;
                  color: #FFB881;
                }

                &.type_2 {
                  // background: #FF8181;
                  border: 1px solid #FF8181;
                  color: #FF8181;
                }

                &.type_3 {
                  // background: #FF9F81;
                  border: 1px solid #FF9F81;
                  color: #FF9F81;
                }

                &.type_4 {
                  // background: #FFCD81;
                  border: 1px solid #FFCD81;
                  color: #FFCD81;
                }

                &.type_5 {
                  // background: #FF8A9E;
                  border: 1px solid #FF8A9E;
                  color: #FF8A9E;
                }
              }

              .price {
                display: flex;
                flex-wrap: wrap;
                align-items: center;

                .selling {
                  font-size: 16px;
                  color: #ff7070;
                  margin-right: 5px;
                }

                .original {
                  margin-left: 3px;
                  font-size: 14px;
                  color: #bebebe;
                  position: relative;

                  &::after {
                    content: "";
                    display: inline-block;
                    position: absolute;
                    width: 110%;
                    height: 1px;
                    top: 50%;
                    left: 0;
                    background: #bebebe;
                  }
                }
              }
            }

            .left {
              position: relative;
              width: 1.6rem;
              height: 0.78rem;

              .go_list {

                padding: .1rem .2rem;
                background: rgba(255, 112, 112, 1);
                border-radius: 34px/2;
                color: #FFFFFF;
                // text-align: center;
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
                right: 0;
              }
            }
          }
        }

        .product_qrcode {
          flex: none;
          font-size: 14px;

          .qrcode {
            width: 3.5rem/2;
            height: 3.5rem/2;
            display: block;
            margin: 0 auto;
          }

          p {
            margin: 2px 0 0 0;
            text-align: center;
            color: #ff7070;
          }
        }

      }

      .financial_item {
        border-bottom: 1px solid #EEEEEF;
        overflow: hidden;

        &>div {
          margin: .2rem 0;
        }

        .financial_title {
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          color: #4D5358;
          font-size: 16px;
        }

        .financial_tab {
          &>span {
            font-size: 12px;
            color: #39A2E9;
            border: 1px solid #39A2E9;
            padding: 2px 4px;
            border-radius: 2px;
          }
        }

        .financial_detail {
          position: relative;
          margin-top: 14px;

          .financial_left {
            .financial_price {
              color: #FF5E61;
              font-size: 16px;
              margin-bottom: .1rem;
            }

            .financial_income {
              color: #ACB1BA;
              font-size: 14px;
            }
          }

          .financial_right {
            position: absolute;
            bottom: 0;
            right: 0;
            padding: 5px 8px;
            background: rgba(1, 194, 255, 1);
            border-radius: 8px/2;
            font-size: 14px;
            color: #ffffff;
          }
        }
      }
    }

    .reminder {
      text-align: center;
      margin-top: 0.5rem;
      padding-bottom: 0.44rem;
      color: rgba(125, 138, 148, 1);
      font-size: 14px;
    }
  }
}

.fade-enter-active,
.fade-leave-active {
  transition: 0.5s;
}

.fade-enter {
  transform: translate(0, 100%);
}

.fade-enter-to {
  transform: translate(0, 0);
}

.fade-leave {
  transform: translate(0, 0);
}

.fade-leave-to {
  transform: translate(0, 100%);
}
</style>
