<template>
<transition :name="getPageModel!=0?'fade':''">
  <div id="ask" class="mod_menu_question" :class="{full:getPageModel!=0}" @click.stop="">
    <div class="_title" v-if="getPageModel!=0">提问</div>
    <div id="question_hall" class="mod_ques_hall">
      <div id="question_inner_hall">
        <div>
          <dl v-for="(item, index) in getQuesList" :key="index">
            <dd>
              <img :src="item.avatar" class="avatar">
              <div class="q_t">
                <div class="uname">
                  <div class="que_right">
                    <!-- 头部 -->
                    <div class="ques_head">
                      <span class="nickname">{{item.nickname}}</span>
                      <span class="role" v-if="item.role=='admin'||item.role=='spadmin'">{{item.role=='admin'?'管理员':'主播'}}</span>
                      <span class="chat_time">{{item.time | timeCover}}</span>
                    </div>
                    <!-- 问答详情 -->
                    <div class="ques_detail">
                      <!-- 问题 -->
                      <p class="main_ques">{{item.content}}</p>
                      <!-- 回答列表 -->
                      <div class="reques" v-show="item.answers && item.answers.length > 0" v-for="(ans, aIndex) in item.answers" :key="aIndex">
                        <img :src="ans.avatar" class="avatar">
                        <div class="uname">
                          <div class="que_right">
                            <!-- 头部 -->
                            <div class="ques_head">
                              <span class="nickname">{{ans.nickname}}</span>
                              <span class="role" v-if="ans.role==='admin'||ans.role==='spadmin'">{{ans.role=='admin'?'管理员':'主播'}}</span>
                              <span class="chat_time">{{ans.time | timeCover}}</span>
                            </div>
                            <!-- 问答详情 -->
                            <div class="ques_detail">
                              <!-- 问题 -->
                              <p class="main_ques">{{ans.content}}</p>
                              <!-- 回答列表 -->
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </dd>
          </dl>
          <dl id="question_bottom"></dl>
        </div>
      </div>
      <div class="no_data" v-if="!no_data">
        <span class="tip">暂无提问</span>
      </div>
    </div>
    <!-- 提问Post -->
    <div id="mod_ques_post" class="mod_ques_post">
      <div class="post_con">
        <span class="mod_chat_ipt">
          <input id="ques_post_txt" type="text" placeholder="我要提问" autocomplete="off" @focus="onChatFocus()" @blur="onBlur()" v-model.trim="cntTxt" />
        </span>
        <div class="icon_warp">
          <span data-type="chat" @click.stop="sendTxt($event)" class="csend" v-if="onSend">提问</span>
        </div>
      </div>
    </div>
  </div>
</transition>
</template>

<script>
import {
  mapGetters
} from 'vuex'
import * as tools from '@/assets/js/util'
import BScroll from "better-scroll";
export default {
  name: 'QuestionView',
  components: {

  },
  data() {
    return {
      cntTxt: '', // 内容
      setBlock: false, // 发送限制
      timeToUnlock: 0, // 解锁时间
      onSend: false
    }
  },
  filters: {
    timeCover(time) {
      // this.tools
      // console.warn(time)
      return tools.convertTimestamp(time)
    }
  },
  computed: {
    ...mapGetters([
      'getQuesList',
      'getPageModel',
      'getToolsQuestion'
    ]),
    no_data() {
      return Object.keys(this.getQuesList).length
    }
  },
  watch: {
    getToolsQuestion(nv) {
      if (nv) {
        this.bscroller.isScrolled = false
        this.$nextTick(() => {
          let item = document.querySelector("#question_bottom");
          this.bscroller.refresh();
          this.bscroller.scrollTo(0, -99999);
        })
      }
    },
    getQuesList: {
      deep: true,
      handler: function (nv, ov) {
        if (this.bscroller) {
          this.$nextTick(() => {
            let item = document.querySelector("#question_bottom");
            this.bscroller.refresh();
            this.bscroller.scrollToElement(item, 100);
          })
        }
      }
    }
  },
  methods: {
    onChatFocus(e) {
      setTimeout(() => {
        this.jquery(document).scrollTop(this.jquery(window).height());
      }, 250);
      this.onSend = true;
    },
    // 倒计时
    onDelay(time) {
      if (this.blockTimer) {
        window.clearInterval(this.blockTimer)
      }
      this.timeToUnlock = time
      this.blockTimer = window.setInterval(() => {
        if (this.timeToUnlock === 0) {
          window.clearInterval(this.blockTimer)
          this.setBlock = false
          this.timeToUnlock = 0
          return false
        }
        this.setBlock = true
        this.timeToUnlock = this.timeToUnlock -= 1
      }, 1000)
    },
    // 发送
    sendTxt(event) {
      if (this.cntTxt.length === 0) {
        this.$vux.toast.text('问答内容不能为空', 'bottom')
        return false
      }
      // 倒计时
      if (this.setBlock) {
        this.$vux.toast.text('请在' + this.timeToUnlock + '秒后再发言', 'bottom')
        return false
      }
      this.HTSDK.emit('question:ask', {
        msg: this.cntTxt
      }, (retval) => {
        // console.log('[debug]::retval => ', retval)
        if (retval.code == 0) {
          this.cntTxt = ''
        } else {
          if (retval.data && retval.data.qaSecond) {
            this.setBlock = true
            this.onDelay(retval.data.qaSecond)
          }
        }
      })
      document.getElementById("ques_post_txt").blur();
      this.onSend = false;
      event.preventDefault();
    },
    onBlur() {
      document.body.scrollTop = document.documentElement.scrollTop = 0;
      this.jquery("#app").scrollTop(0);
      this.$nextTick(() => {
        this.bscroller.refresh()
      })
      if (this.cntTxt === "") {
        this.onSend = false;
      }
      if (window.parent && window.parent.postMessage) {
        window.parent.postMessage('chat:on:blur', "*");
      }
    },
    info() {
      this.$nextTick(() => {
        const bscroller = new BScroll("#question_inner_hall", {
          click: true,
          scrollY: true,
          useTransform: true,
        });
        bscroller.on('beforeScrollStart', function () {
          if (!this.isScrolled) {
            this.refresh()
            this.isScrolled = true
          }
        })
        this.bscroller = bscroller;
        this.bscroller.refresh();
      })
      let that = this;
      let _wrap = this.jquery("#question_inner_hall");
      _wrap.bind("click", function () {
        that.jquery("#ques_post_txt").blur();
      });
    },
    init() {
      let url = '//open.talk-fun.com/live/questions.php?access_token=' + (window.access_token || '')
      this.$http.get(url).then((res) => {
        if (res.data.code == 0) {
          this.$store.commit("UPDATE_QUESTION_LIST", {
            type: 'list',
            data: res.data.data
          })
          this.info()
        }
      })
    }
  },
  mounted() {
    // this.init()
    this.info()
  }
}
</script>

<style lang="less" scoped>
.mod_menu_question {
  height: 100%;
  position: relative;
  // display: flex;
  // flex-direction: column;
  // overflow: hidden;

  &.full {
    width: 100%;
    position: absolute;
    bottom: 0;
    height: 70vh;
    border-radius: 20px/2 20px/2 0px 0px;
    background: #ffffff;

    ._title {
      text-align: center;
      height: 1.76rem/2;
      line-height: 1.76rem/2;
      border-radius: 20px/2 20px/2 0px 0px;
      font-size: 32px/2;
      color: #1b3947;
      border-bottom: 1px solid #d8dce2;
      flex: none;
      position: relative;
    }
    .mod_ques_hall{
      top: 1.76rem/2;
    }
  }

  .mod_ques_hall {
    // flex: 1;
    overflow: hidden;
    position: absolute;
    width: 100%;
    top: 0;
    bottom: 1.2rem;

    #question_inner_hall {
      height: 100%;
      overflow: hidden;

      &>div {
        padding: .76rem/2 0 0 .6rem/2;
        box-sizing: border-box;
      }

      dd {
        display: flex;
        margin-bottom: .2rem;

        .avatar {
          flex: none;
          width: 1.2rem/2;
          height: 1.2rem/2;
          border-radius: 50%;
          margin-right: .28rem/2;
        }

        .q_t {
          flex: 1;

          .uname {
            border-bottom: 1px solid #EBEFF2;
            padding-bottom: .2rem;

            .que_right {
              .ques_head {
                height: 1.2rem/2;
                display: flex;
                align-items: center;

                .nickname {
                  font-size: 18px;
                  font-weight: bold;
                  color: #1B3947;
                  max-width: 4rem;
                  overflow: hidden;
                  white-space: nowrap;
                  text-overflow: ellipsis;
                  margin-right: .4rem/2;
                }

                .role {
                  border-radius: .4rem/2;
                  color: #01C2FF;
                  background: #DFF7FF;
                  font-size: 12px;
                  margin-right: .4rem/2;
                  padding: 2px 6px;
                }

                .chat_time {
                  font-size: 14px;
                  color: #89969E;
                }
              }

              .ques_detail {
                .main_ques {
                  font-size: 16px;
                  color: #4D5358;
                  margin: 0;
                  word-break: break-all;
                  padding-right: .4rem/2;
                  box-sizing: border-box;
                }
              }
            }
          }
        }

        .reques {
          display: flex;
          margin-top: .2rem/2;

          .uname {
            border: none !important;
            padding: 0 !important;
          }

          .nickname {
            max-width: 3rem !important;
          }
        }
      }
    }

    .no_data {
      position: absolute;
      width: 100px;
      height: 120px;
      background: url(~@/assets/images/live-v3/no_question.png) no-repeat;
      background-size: 100%;
      top: 1.5rem;
      left: 0;
      right: 0;
      margin: auto;

      .tip {
        width: 100%;
        text-align: center;
        position: absolute;
        font-size: 16px;
        color: rgba(158, 176, 196, 1);
        bottom: -10px;
      }
    }
  }

  .mod_ques_post {
    // flex: none;
    position: fixed;
    bottom: 0;
    height: 1.2rem;
    width: 100%;
    max-width: 750px;
    transition: .5s;
    background: #FFFFFF;
    // background: blueviolet;

    .post_con {
      display: flex;
      height: 100%;
      align-items: center;
      padding: .4rem/2 1rem/2;
      box-sizing: border-box;

      .mod_chat_ipt {
        border: none;
        color: black;
        font-size: 14px;
        flex: 1;
        height: 100%;
        outline: none;
        position: relative;
        line-height: 35px;
        text-align: center;

        input {
          width: 100%;
          height: 100%;
          background-color: rgba(246, 248, 249, 1);
          outline: none;
          text-indent: 1em;
          border: none;
          border-radius: .7rem/2;
        }

        input::placeholder {
          color: #c6cdd2;
        }
      }

      .icon_warp {
        flex: none;
        display: flex;

        .csend {
          width: 1rem;
          height: 0.6rem;
          line-height: 0.6rem;
          text-align: center;
          border-radius: 0.36rem;
          background-color: #70b3ff;
          color: #fff;
          font-size: 16px;
          display: block;
          margin-left: .3rem;
          flex: none;
        }
      }

    }
  }
}

.fade-enter-active,
.fade-leave-active {
  transition: 0.5s;
}

.fade-enter {
  transform: translate(0, 100%);
}

.fade-enter-to {
  transform: translate(0, 0);
}

.fade-leave {
  transform: translate(0, 0);
}

.fade-leave-to {
  transform: translate(0, 100%);
}
</style>
