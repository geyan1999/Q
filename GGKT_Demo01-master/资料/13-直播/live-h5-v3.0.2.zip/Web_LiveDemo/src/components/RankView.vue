<template>
<transition :name="getPageModel!=0?'fade':''">
  <div class="rank" :class="{full_screen:getPageModel!=0}" @click.stop="">
    <div class="_title" v-if="getPageModel!=0">邀请榜单</div>
    <div class="no_data" v-if="getRankList.data.length == 0">
      <span class="tip">暂无数据</span>
    </div>
    <div class="rank_list_warp" v-if="getRankList.data.length !==0">
      <ul>
        <li class="rank_list" v-for="(item,index) in getRankList.data" :key="index">
          <div class="index">{{index>=3?index+1:''}}</div>
          <img :src="item.avatar" alt class="avatar" />
          <div class="rank_list_data">
            <span class="name">{{item.nickname}}</span>
            <span class="invite">
              邀请
              <span class="num">{{item.inviteCount}}</span>
              人
            </span>
          </div>
        </li>
      </ul>
      <div class="reminder" @click="updataRankPage()" v-if="getRankList.page !== getRankList.total && getRankList.data.length !==0">查看更多数据</div>
      <div class="reminder" v-else>暂无更多数据</div>
    </div>
  </div>
</transition>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
import * as TYPES from "@/assets/action-types";
export default {
  data() {
    return {
      a: ""
    };
  },
  methods: {
    ...mapActions({
      getMore: "GET_RANK_LIST"
    }),
    updataRankPage() {
      this.getMore({
        vm: this,
        data: {
          access_token: window.access_token ||
            "ITN4Q2N5YjZmljY3gDMxMmZ0UTOxkjNmJzNxczYmhjZ8xHf9JSNxgjMyMzX4YDNxIDOiojIl1WYuJnIsEjOiEmIsAjOiQWanJCL1EDOyIzM6ICZp9VZzJXdvNmIsIiI6IichRXY2FmIsAjOiIXZk5WZnJCLzgTO1ITNzYTNxojIlJXawhXZiwyM4MDNwUzM2UTM6ISZtlGdnVmciwSXbpjIyRHdhJCLiIXZzVnI6ISZs9mciwCM5UDMyUzM3ojIklGeiwiIadkTPhURFxkI6ISZtFmbrNWauJCLwojIklmYiwiIxAjN2czXkJXaoRnI6ICZpVnIsgjN0EjM4ojIklWbv9mciwiNwMTMxojIklGciwiNwMTMxojIkl2XyVmb0JXYwJye",
          page: this.getRankList.page + 1,
          rank: "rank"
        }
      });
      this.$vux.loading.show({
        text: "Loading"
      });
    }
  },
  computed: {
    ...mapGetters(["getRankList", "getPageModel", "getToolsRank"])
  }
};
</script>

<style lang="less" scoped>
.rank {
  background: #ffffff;
  height: 100%;
  overflow: auto;
  -webkit-overflow-scrolling: touch;
  position: relative;

  &.full_screen {
    width: 100%;
    position: absolute;
    bottom: 0;
    height: 60vh;
    z-index: 2500;
    transition: 0.5s;
    border-radius: 20px/2 20px/2 0px 0px;
    background: #ffffff;

    .no_data {
      top: 3rem;
    }

    ._title {
      text-align: center;
      height: 1.76rem/2;
      line-height: 1.76rem/2;
      border-radius: 20px/2 20px/2 0px 0px;
      font-size: 32px/2;
      color: #1b3947;
      border-bottom: 1px solid #d8dce2;
    }
  }

  // &.rankUp {
  //   height: 60vh;
  // }
  .no_data {
    position: absolute;
    width: 100px;
    height: 120px;
    background: url(../assets/images/live/rankdate.svg) no-repeat;
    background-size: 100%;
    top: 60px;
    left: 0;
    right: 0;
    margin: auto;

    .tip {
      width: 100%;
      text-align: center;
      position: absolute;
      font-size: 16px;
      color: rgba(158, 176, 196, 1);
      bottom: -10px;
    }
  }

  .rank_list_warp {
    font-size: 16px;
    padding: 0.2rem 0.3rem 0;
    box-sizing: border-box;

    .rank_list {
      position: relative;
      box-sizing: border-box;
      padding: 0.2rem 0;
      display: flex;
      align-items: center;

      &:nth-of-type(1) {
        .index {
          background: url(../assets/images/live-v2/rank1.svg) no-repeat;
          background-size: 100% 100%;
        }
      }

      &:nth-of-type(2) {
        .index {
          background: url(../assets/images/live-v2/rank2.svg) no-repeat;
          background-size: 100% 100%;
        }
      }

      &:nth-of-type(3) {
        .index {
          background: url(../assets/images/live-v2/rank3.svg) no-repeat;
          background-size: 100% 100%;
        }
      }

      .index {
        color: #b3bac1;
        font-size: 14px;
        width: 0.4rem;
        height: 0.6rem;
        line-height: 0.6rem;
        text-align: center;
        margin-right: 0.2rem;
      }

      .avatar {
        width: 0.7rem;
        height: 0.7rem;
        border-radius: 50%;
        display: block;
      }

      .rank_list_data {
        flex: 1;
        display: flex;
        font-size: 16px;

        .name {
          margin-left: .2rem;
          color: #4D5358;
        }

        .invite {
          flex: 1;
          text-align: right;
          color: #B0B7BE;
        }
      }
    }

    .reminder {
      text-align: center;
      margin-top: 0.5rem;
      padding-bottom: 0.44rem;
      color: rgba(125, 138, 148, 1);
      font-size: 14px;
    }
  }
}
.fade-enter-active,
.fade-leave-active {
  transition: 0.5s;
}

.fade-enter {
  transform: translate(0, 100%);
}

.fade-enter-to {
  transform: translate(0, 0);
}

.fade-leave {
  transform: translate(0, 0);
}

.fade-leave-to {
  transform: translate(0, 100%);
}
</style>
