<template>
<div class="card_warp" v-if="curIndex!=popList.length">
  <transition name="fade">
    <template v-for="(item, index) in popList">
      <div :key="index" v-if="item.show" class="card_content">
        <div class="tip"><span class="second">{{item.duration}}s</span>后<span>关闭</span></div>
        <img :src="item.img" alt="图片加载错误..." class="card_bg" @click="goLink(item)">
        <div class="close" @click="close"></div>
      </div>
    </template>
  </transition>
</div>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
export default {
  data() {
    return {
      popList: [],
      curIndex: 0,
      timer: null,
      timer_cout: null,
    }
  },
  computed: {
    ...mapGetters(["getPageModel", "getConfig", "getPopCard"]),
  },
  methods: {
    // 链接差异化
    goLink(card) {
      let url = card.url || ''
      if (url) {
        if (url.match(/\[wx\]/)) {
          url = url.replace('[wx]', '')
          if (window.wx) {
            window.wx.miniProgram.navigateTo({
              url: url
            })
          }
          return false
        } else {
          window.location.href = url
        }
      }
    },
    // 推送
    push(item) {
      // console.error(item)
      this.popList.push({
        show: false,
        img: item.img,
        duration: item.duration,
        url: item.url
      })
      this.timeOut()
    },
    // 关闭
    close() {
      clearTimeout(this.timer)
      this.timer = null
      clearInterval(this.timer_cout)
      this.timer_cout = null
      this.popList[this.curIndex].show = false
      this.curIndex = this.curIndex + 1
      this.timeOut()
    },
    // 倒计时
    timeOut() {
      if (this.popList[this.curIndex] && !this.timer && !this.timer_cout) {
        this.popList[this.curIndex].show = true
        this.timer_cout = setInterval(() => {
          if (this.popList[this.curIndex]) {
            if (this.popList[this.curIndex].duration == 0) {
              clearInterval(this.timer_cout)
              this.timer_cout = null
            } else {
              this.popList[this.curIndex].duration -= 1
            }
          }
        }, 1000);
        this.timer = setTimeout(() => {
          this.popList[this.curIndex].show = false
          this.curIndex = this.curIndex + 1
          clearTimeout(this.timer)
          clearInterval(this.timer_cout)
          this.timer = null
          this.timer_cout = null
          this.timeOut()
        }, 1000 * this.popList[this.curIndex].duration)
      }
    },
    // 初始化
    init() {
      let that = this
      // Array.forEach
      if (this.getConfig.popUp && this.getConfig.popUp.length) {
        this.getConfig.popUp.forEach((item) => {
          if (item.type == 2 && item.status == 1) {
            that.popList.push({
              show: false,
              img: item.img,
              duration: item.duration,
              url: item.url,
              pushtime: item.pushTime,
              title: item.title
            })
          }
        })
        this.popList.sort((a, b) => {
          if (typeof a.pushtime === 'string') {
            return new Date(b.pushtime).getTime() - new Date(a.pushtime).getTime()
          } else {
            return b.pushtime - a.pushtime
          }
        })
      }
      this.timeOut()
    }
  },
  watch: {
    getPopCard(nv, ov) {
      this.push(nv)
    }
  },
  created() {

  },
  mounted() {
    this.init()
  },
}
</script>

<style lang="less" scoped>
.card_warp {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.6);

  .card_content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #ffffff;

    .tip {
      position: absolute;
      top: -10px;
      right: 0;
      transform: translateY(-100%);
      padding: 0.1rem 0.2rem;
      background: rgba(0, 0, 0, 0.5);
      border-radius: 8px/2;
      font-size: 14px;
      white-space: nowrap;

      .second {
        margin-right: 4px;
      }
    }

    .card_bg {
      max-width: 85vw;
      max-height: 70vh;
      object-fit: cover;
      font-size: 14px;
    }

    .close {
      position: absolute;
      bottom: -0.4rem;
      left: 50%;
      transform: translate(-50%, 100%);
      background: url(~@/assets/images/live-v3/sign_close.png);
      background-size: 100% 100%;
      width: 1.6rem/2;
      height: 1.6rem/2;
      border-radius: 50%;
    }
  }
}

.fade-enter-active,
.fade-leave-active {
  transition: 0.5s;
}

.fade-enter {
  opacity: 0;
}

.fade-enter-to {
  opacity: 1;
}

.fade-leave {
  opacity: 1;
}

.fade-leave-to {
  opacity: 0;
}
</style>
