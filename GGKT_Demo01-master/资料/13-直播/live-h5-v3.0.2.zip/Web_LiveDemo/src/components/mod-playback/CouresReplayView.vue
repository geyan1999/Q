<template>
<!--#全屏模式 -->
<div class="mod-ecom-wp" :class="getScreenStatus" @click="control()">
  <!-- 播放器加载动画 -->
  <div class="_masker_loading" v-show="getPlayStatus==='waiting'">
    <div class="loader loader-7">
      <div class="line line1"></div>
      <div class="line line2"></div>
      <div class="line line3"></div>
      <div class="text_line">正在加载...</div>
    </div>
  </div>
  <!-- 直播信息 -->
  <TopInfomation @Tab="tabchoose" v-if="getConfig"></TopInfomation>
  <!-- 默认播放按钮 -->
  <div class="play" @click.stop="play()" v-show="getPlayStatus==='pause'"></div>
  <div class="play stop" @click.stop="stop()" v-show="toolsUp&&getPlayStatus!=='pause'"></div>
  <!-- ppt全屏 -->
  <div class="ppt_full" @click.stop="pptFull" :class="{full:ppt_full}"></div>
  <!-- 刷新按钮 -->
  <div class="replay" @click.stop="replay()" :class="{replaying:timer}" v-show="on_replay"></div>
  <!-- <div class="full_screen_btn" @click.stop="full()">全屏</div> -->
  <!-- #课件模块 -->
  <div id="ht_course_container" class="ppt_media" :style="[pptbackground,pptfull]" :class="{full:ppt_full}"></div>
  <!-- #全屏摄像头 -->
  <div id="ht_camera_container" class="live_media" :style="background" v-show="liveCurMode === 0"></div>
  <!-- #外部推流模块 -->
  <div id="ht_player_container" class="live_media" :style="background" v-show="liveCurMode === 2"></div>
  <!-- 侧边栏工具 -->
  <side-content></side-content>
  <!-- 邀请榜单 -->
  <rank-view v-show="getToolsRank"></rank-view>
  <!-- 加载中动画 -->
  <div class="loading hidden" id="loading">
    <div class="loading_bg">
      正在加载中
      <div class="cicle_warp">
        <div class="cicle1 cicle"></div>
        <div class="cicle2 cicle"></div>
        <div class="cicle3 cicle"></div>
      </div>
    </div>
  </div>
  <!-- 底部工具栏 -->
  <div class="bttom_tools" :class="{up:toolsUp}">
    <div class="tools_warp">
      <div class="left">
        <div class="product_icon" @click.stop="doProduct()" v-if="getConfig&&getConfig.global.switch.store.enable == 1"></div>
      </div>
      <div class="right">
        <div class="chat_icon" @click.stop="chatUp=!chatUp" v-if="config('chat')"></div>
        <div class="tab_icon" @click.stop="tabInfo(getConfig)" v-if="getConfig && getConfig.global.switch.menu.enable == 1&&pulldownShwo"></div>
        <div class="like_icon" @click.stop="like()" v-if="getConfig && getConfig.global.switch.like.enable==1 && false">
        </div>
      </div>
    </div>
    <!-- 控制栏 -->
    <control @Time="timeChang" :toolsUp="toolsUp"></control>
  </div>
  <!-- 聊天列表 -->
  <div class="mod_chat_list" v-if="getConfig" :class="{chatUp:chatUp}">
    <div class="_title">聊天(<span>{{chatList.length>99?'99+':chatList.length}}</span>)</div>
    <ul id="chat_hall" class="chat_inner content">
      <li class="chat-item" :id="'item_' + index" v-for="(item, index) in chatList" :key="index">
        <!-- #聊天消息 -->
        <div class="pub_msg" v-if="!item.type">
          <img :src="item.avatar" alt class="avatar" />
          <div class="chat_right spadmin">
            <div class="chat_head_com">
              <span class="nickname">{{item.nickname}}</span>
              <span class="chat_time" v-if="getConfig&&getConfig.global.switch.chatTime.enable == 1">{{item.time?item.time:item.timestamp | getTime | getTime}}</span>
            </div>
            <p class="chat_detail" v-html="renderMsg(item.message)" v-if="!item.image"></p>
            <p class="chat_detail image" v-if="item.image">
              <img :src="item.image" alt v-gallery:group1 />
            </p>
          </div>
        </div>
      </li>
    </ul>
  </div>
  <!-- 功能菜单 -->
  <div class="tab_menu" v-if="getConfig" :class="{tabUp:tabUp}">
    <nav class="com_menu_head">
      <!--导航-->
      <ul class="ht_nav_list">
        <li class="apply" :class="{selected:getActModule === 'apply'}" v-if="pulldownShwo" @click.stop="toggleMenu('apply')">应用</li>
        <template v-for="(item,index) in getConfig.content.tabsData">
          <li :key="index" :class="{selected:getActModule === (item.title+index)}" @click.stop="toggleMenu(item.title+index)" v-if="item.type==='editor'">{{item.title}}</li>
        </template>
      </ul>
    </nav>
    <section class="mod_modules">
      <div class="tab_content apply" v-if="pulldownShwo" v-show="getActModule === 'apply'">
        <ul>
          <li @click.stop="openTools('info')" v-if="!(getConfig&&getConfig.global.switch.more.data.info == 0) && isWx ">
            <div class="item info_icon">
              <span></span>
            </div>
            <span>个人中心</span>
          </li>
          <li @click.stop="openTools('line')" v-if="!(getConfig&&getConfig.global.switch.more.data.liveLine == 0)">
            <div class="item line_icon">
              <span></span>
            </div>
            <span>线路切换</span>
          </li>
          <li @click.stop="changeRewardState(5)" v-if="!(getConfig&&getConfig.global.switch.more.data.withdraw == 0) && isWx">
            <div class="item reward_cash">
              <span></span>
            </div>
            <span>提现</span>
          </li>
          <li @click.stop="openTools('product',getConfig.global.switch.more.data.store.url)" v-if="getConfig&&getConfig.global.switch.more.data.store.enable == 1">
            <div class="item product_icon">
              <span></span>
            </div>
            <span>商城</span>
          </li>
          <li @click.stop="openTools('report')" v-if="!(getConfig&&getConfig.global.switch.more.data.report == 0)">
            <div class="item report_icon">
              <span></span>
            </div>
            <span>举报</span>
          </li>
        </ul>
      </div>
      <!-- PPT模块 -->
      <div id="ht_player_container" class="ppt" v-show="getActModule === 'courseware' && config('courseware')"></div>
      <!-- @自定义模块 -->
      <template v-for="(item,index) in getConfig.content.tabsData">
        <div :key="index" v-html="item.content" v-show="getActModule === (item.title+index)" class="tab_content" v-if="!(item.type==='chat'||item.type==='invite'||item.type==='courseware')"></div>
      </template>
      <!-- 暂无数据 -->
      <div class="no_data" v-if="nodata()">
        <span class="tip">暂无数据</span>
      </div>
    </section>
  </div>
  <!-- 网络选择 -->
  <network-line class="full" v-show="getToolsLine" :style="Index(1)"></network-line>
  <!-- 个人中心 -->
  <infomation @tab="tabDown" v-if="getConfig" v-show="getToolsInfomation" class="full" :style="Index(1)"></infomation>
  <!-- 红包 -->
  <reward-view></reward-view>
  <!-- 商城列表 -->
  <product-view v-show="getToolsProduct" :popShow="producUp" v-if="getConfig&&getConfig.global.switch.store.enable == 1" @product="emit"></product-view>
</div>
</template>

<script>
import OnlineTotal from "../OnlineTotal";
import ScrollNoticeView from "../ScrollNoticeView";
import NotificationView from "../NotificationView";
import RewardView from "../RewardView";
import LotteryView from "../LotteryView";
import TabCom from "../TabCom";
import TabItemCom from "../TabItemCom";
import SideContent from "../SideContent";
import TopInfomation from "../TopInfomation";
import RankView from "../RankView";
import TimerCount from "../TimerCount";
import ProductView from "../ProductView";
import RedAnimation from "../RedAnimation";
import Control from "./ControlView";
import NetworkLine from "../NetwordLine";
import Infomation from "../Infomation";
import * as util from "../../assets/js/util";
import * as TYPES from "@/assets/action-types";
import {
  mapGetters,
  mapActions
} from "vuex";

export default {
  name: "e-comView",
  data() {
    return {
      linebox: false,
      infobox: false,
      zhubo: {},
      isLike: false,
      toolsKits: {
        doc: false,
        chat: true,
        share: false
      },
      tabUp: false,
      rankUp: false,
      producUp: false,
      timer: null,
      on_replay: false,
      replay_timer: null,
      timerCountFlag: false,
      red_animation: false,
      red_animation_timer: null,
      isIos: false,
      toolsUp: false,
      num: 0,
      toolTimer: null,
      chatUp: false,
      isVod: window.isVod && window.isVod == 1 ? true : false,
      emojiPack: {
        "[微笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon1.png",
        "[调皮]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon2.png",
        "[害羞]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon3.png",
        "[奸笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon4.png",
        "[憨笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon5.png",
        "[尴尬]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon6.png",
        "[鼓掌]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon7.png",
        "[惊讶]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon8.png",
        "[闭嘴]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon9.png",
        "[呲牙]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon10.png",
        "[大哭]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon11.png",
        "[大笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon12.png",
        "[得意]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon13.png",
        "[囧]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon14.png",
        "[难过]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon15.png",
        "[敲打]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon16.png",
        "[色]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon17.png",
        "[委屈]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon18.png",
        "[疑问]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon19.png",
        "[郁闷]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon20.png",
        "[再见]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon21.png",
        "[可怜]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon22.png",
        "[捂脸]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon23.png",
        "[笑哭]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon24.png",
        "[安慰]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon25.png"
      },
      isWx: true,
      ppt_full:false
    };
  },
  filters: {
    // todo...
    getTime(_time) {
      return util.convertTimestamp(_time);
    },
    // render
    renderImg(msg) {
      // console.warn(msg)
      msg = '<img src="' + msg.replace(/\[(.+?)\]/g, "") + '" />';
      return msg;
    },
    // emoji
    renderEmoji(msg) {
      // msg = msg.replace(/\[*.\]/, '')
      return msg;
    },
    renderLike(num) {
      if (num > 9999 && num <= 9999999) {
        num = parseInt(num / 10000);
        num = parseInt(num) + "w";
      } else if (num > 9999999) {
        num = '9999w+'
      }
      return num;
    }
  },
  components: {
    OnlineTotal,
    ScrollNoticeView,
    NotificationView,
    RewardView,
    TabItemCom,
    TabCom,
    SideContent,
    LotteryView,
    TopInfomation,
    RankView,
    TimerCount,
    ProductView,
    RedAnimation,
    Control,
    NetworkLine,
    Infomation
  },
  methods: {
    ...mapActions({
      updateRankList: "GET_RANK_LIST",
      indexCashReward: "INDEX_CASH_REWARD",
    }),
    pptFull(){
      this.ppt_full = !this.ppt_full
      setTimeout(()=>{
        // this.HTSDK.playerResize()
      })
    },
    control() {
      this.on_replay = true
      if (this.replay_timer) {
        clearTimeout(this.replay_timer);
      }
      this.replay_timer = setTimeout(() => {
        this.on_replay = false
      }, 3000);
    },
    Index(index) {
      return {
        zIndex: index + 300
      }
    },
    clear() {
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'more',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'redAnimation',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'rank',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'line',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'private',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'product',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'infomation',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'redpackPop',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'emoji',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'menu',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'vote',
        flag: false
      })
    },
    doProduct() {
      let type = this.getConfig ? this.getConfig.global.switch.store.type : 0;
      let url = this.getConfig ? this.getConfig.global.switch.store.data.url : '';
      if (type == 1) {
        this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
          type: 'product',
          flag: true
        });
      } else if (type == 2) {
        window.location.href = url;
      } else if (type == 3) {
        this.$store.commit(TYPES.UPDATE_SIDE_MODE, 7);
      }
    },
    openTools(type) {
      if (type === 'product') {
        let url = this.getConfig ? this.getConfig.global.switch.store.data.url : '';
        window.location.href = url;
      } else if (type === 'more') {
        let url = this.getConfig ? this.getConfig.global.switch.more.data.store.url : '';
        if (url) {
          window.location.href = url;
        } else {
          // this.$emit("product", true);
        }
      } else if (type === 'line') {
        this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
          type: 'line',
          flag: true
        });
        if (this.isVod) {
          this.HTSDK.getSource(data => {
            // console.error(data)
            let arr = []
            for (let i = 0; i < data; i++) {
              // console.error(data)
              arr.push({
                key: i,
                label: "线路" + (i + 1)
              })
            }
            // console.error(arr)
            this.$store.commit(TYPES.UPDATE_LIVE_LINE, arr)
          })
        }
      } else if (type === 'info') {
        this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
          type: 'infomation',
          flag: true
        });
      } else if (type === 'report') {
        this.$store.commit(TYPES.UPDATE_SIDE_MODE, 8);
      } else if (type === 'private_chat') {
        this.$vux.loading.show({
          text: "Loading"
        });
        SDKEMIT.getOnline(this.HTSDK, {
          "page": 1,
          "size": 100
        }, list => {
          // 客服列表
          if (list.length > 0) {
            let private_chat_list = []
            list.forEach(element => {
              if (element.role === 'admin') {
                private_chat_list.push(element)
              }
            });
            this.$store.dispatch("setPvUserlist", private_chat_list)
          }
          //   打开客服私聊
          this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
            type: 'private',
            flag: true
          });
          this.$vux.loading.hide()
        })
      }
      this.tabUp = false
    },
    getIsWxClient() {
      var ua = navigator.userAgent.toLowerCase();
      if (ua.match(/MicroMessenger/i) == "micromessenger") {
        return true;
      }
      return false;
    },
    tabDown() {
      this.infobox = false
    },
    back() {
      if (window.history) {
        window.history.back()
      }
    },
    changeRewardState(val, index, reward) {
      this.tabUp = false
      if (val == 2) {
        // 打开红包前检查红包是否可以领取
        if (
          this.getRewardTimer ||
          tools.isMe(reward.user, this.getHtData.user)
        ) {
          this.$store.commit("UPDATE_REWARD_HID", reward.hid);
          // console.log(this.getRewardCurhid);
          this.checkReward({
            vm: this,
            data: {
              liveid: this.liveid,
              hid: this.getRewardCurhid
            },
            reward: reward
          });
          // this.jquery("#loading").removeClass("hidden");
          this.$vux.loading.show({
            text: "Loading"
          });
          // 隐藏视频
          this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 1);
        } else {
          this.$vux.toast.text("观看1分钟后才能参与红包领取", "bottom");
        }
      } else if (val == 5) {
        // 我的钱包
        this.indexCashReward({
          vm: this
        });
        // this.jquery("#loading").removeClass("hidden");
        this.$vux.loading.show({
          text: "Loading"
        });
        // 隐藏视频
        this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 1);
        this.pullbox = false;
      } else {
        this.$store.commit(TYPES.UPDATE_REWARD_STATUS, val);
        this.pullbox = false;
      }
    },
    timeChang(val) {
      // console.error("触发",val)
      if (val === 'start') {
        if (this.toolTimer) {
          clearTimeout(this.toolTimer)
          this.toolTimer = null
        }
      } else {
        if (this.toolTimer) {
          clearTimeout(this.toolTimer)
          this.toolTimer = setTimeout(() => {
            this.toolsUp = false
            this.toolTimer = null
          }, 2000)
        } else {
          this.toolTimer = setTimeout(() => {
            this.toolsUp = false
            this.toolTimer = null
          }, 2000)
        }
      }
    },
    like() {
      this.$store.commit(TYPES.UPDATE_SIDE_MODE, 3);
      this.timeChang()
    },
    fullInfo(tab) {
      // 全屏默认当前菜单项的加载方法 特殊逻辑--聊天和榜单的菜单配置不在tab的配置里，单独判断
      let tabsData = tab
      let curtab = ''
      for (let i = 0; i < tabsData.length; i++) {
        if (tabsData[i].type !== 'chat' && tabsData[i].type !== 'invite') {
          curtab = tabsData[i].type === 'editor' ? tabsData[i].title + i : tabsData[i].type
          break
        }
      }
      if (this.pulldownShwo) {
        curtab = 'apply'
      }
      this.$store.commit("UPDATE_PAGE_TAB", curtab);
    },
    comInfo(tab) {
      // 半屏默认当前菜单项的加载方法 -- 逻辑 半屏当前菜单的所有配置都在tab的配置里,不需要单独判断
      let tabsData = tab
      let curtab = ''
      if (tabsData.length === 0) {
        curtab = 'chat'
      } else {
        curtab = tabsData[0].type === 'editor' ? tabsData[0].title + 0 : tabsData[0].type
      }
      this.$store.commit("UPDATE_PAGE_TAB", curtab);
    },
    tabInfo(config) {
      this.tabUp = true;
      // 初始化配置加载
      let _tabs = config && config.content.tabsData || []
      this.fullInfo(_tabs)
    },
    toggleMenu(menu) {
      this.$store.commit("UPDATE_PAGE_TAB", menu);
    },
    nodata() {
      let flag = false;
      let curtab = this.getActModule
      curtab === '' ? flag = true : flag = false;
      return flag
    },
    getAvatar(_avatar) {
      if (!_avatar.a) {
        _avatar.a = 1;
      }
      let avaObj = this.HTSDK.getAvatar(_avatar);
      return avaObj.avatar;
    },
    renderMsg(msg) {
      if (!msg) {
        return '';
      }
      let _rule = /\[(.+?)\]/g;
      let _list = msg.match(_rule);
      if (_list && _list.length > 0) {
        // 截图
        if (msg.indexOf("[IMG]") > -1) {
          var imgClip = msg.replace(/\[(.+?)\]/g, "");
          return '<img src="' + imgClip + '" />';
        }
        // 表情
        msg = msg.replace(_rule, (r, k) => {
          let emoji = this.emojiPack[r];
          if (emoji) {
            return (
              '<img src="' +
              emoji +
              '"' +
              'style="vertical-align: bottom;"' +
              "/>"
            );
          }
        });
      }
      return msg;
    },
    emit() {
      this.producUp = false
    },
    play() {
      this.HTSDK.play()
      this.$store.commit("changePlayStatus", "play");
    },
    stop() {
      this.HTSDK.pause()
      this.$store.commit("changePlayStatus", "pause");
    },
    bindEvent(dom) {
      dom.addEventListener('touchend', () => {
        this.clear()
        this.control()
        if(this.toolsUp){
          this.toolsUp = false
          return
        }
        this.toolsUp = true
        if (this.toolTimer) {
          clearTimeout(this.toolTimer)
          this.toolTimer = setTimeout(() => {
            this.toolsUp = false
            this.toolTimer = null
          }, 2000)
        } else {
          this.toolTimer = setTimeout(() => {
            this.toolsUp = false
            this.toolTimer = null
          }, 2000)
        }

      })
    },
    showToolKit(type) {
      if (typeof this.toolsKits[type] !== "undefined") {
        this.toolsKits[type] = !this.toolsKits[type];
      }
      // show doc dom
      this.$nextTick(() => {
        if (type === "doc") {
          if (this.toolsKits[type]) {
            this.HTSDK.playerResize();
          }
        }
      });
    },
    likeMe() {
      if (this.isLike) {
        return false;
      }
      this.$vux.toast.show({
        text: "已关注:" + this.zhubo.nickname + "主播",
        position: "center",
        isShowMask: false
      });
      this.isLike = true;
    },
    tabchoose(type) {
      // console.error(type)
      if (type === "tab") {
        this.tabUp = !this.tabUp;
      }
      if (type === "rank") {
        if (!this.rankUp) {
          this.updateRankList({
            vm: this,
            data: {
              access_token: window.access_token ||
                "ITN4Q2N5YjZmljY3gDMxMmZ0UTOxkjNmJzNxczYmhjZ8xHf9JSNxgjMyMzX4YDNxIDOiojIl1WYuJnIsEjOiEmIsAjOiQWanJCL1EDOyIzM6ICZp9VZzJXdvNmIsIiI6IichRXY2FmIsAjOiIXZk5WZnJCLzgTO1ITNzYTNxojIlJXawhXZiwyM4MDNwUzM2UTM6ISZtlGdnVmciwSXbpjIyRHdhJCLiIXZzVnI6ISZs9mciwCM5UDMyUzM3ojIklGeiwiIadkTPhURFxkI6ISZtFmbrNWauJCLwojIklmYiwiIxAjN2czXkJXaoRnI6ICZpVnIsgjN0EjM4ojIklWbv9mciwiNwMTMxojIklGciwiNwMTMxojIkl2XyVmb0JXYwJye",
              page: 1,
              rank: "rank"
            }
          });
          this.$vux.loading.show({
            text: "Loading"
          });
        }
        this.rankUp = !this.rankUp;
      }
      if (type === 'product') {
        this.producUp = !this.producUp;
      }
    },
    replay() {
      location.reload()
    },
    full() {
      let targetDiv = this.liveCurMode == 0 ? document.querySelector("#ht_camera_container") : document.querySelector("#ht_player_container");
      // console.error(targetDiv.getElementsByTagName("video")[0])
      targetDiv.getElementsByTagName("video")[0].webkitEnterFullScreen()
    },
    showtime(flag) {
      this.timerCountFlag = flag;
    },
    showred(flag) {
      this.red_animation = flag
    },
    config(type) {
      let flag = false;
      if (this.getConfig) {
        this.getConfig.content.tabsData.forEach((item) => {
          if (item.type === type) {
            flag = true
          }
        })
      }
      return flag
    },
  },
  computed: {
    ...mapGetters([
      "getToolsPrivate",
      "getToolsProduct",
      "getToolsLine",
      "getToolsInfomation",
      "getToolsVote",
      "getToolsRank",
      "getToolsRedAnimation",
      "getToolsMenu",
      "getMemberTotal",
      "getHtData",
      "getLiveState",
      "getScreenStatus",
      "liveCurMode",
      "getRewardState",
      "getVideoCurMode",
      "getLottery",
      "getVideoStatus",
      "getPPTModel",
      "getVideoPause",
      "getConfig",
      "getProductIdList",
      "getZhuboRewardMsg",
      "getVodPlayVideo",
      "getPlayStatus",
      "getChatList",
      "getActModule",
      "getLikeCount"
    ]),
    pptbackground() {
      let getConfig = this.getConfig
      if (getConfig && getConfig.global.switch.pptbackground && getConfig.global.switch.pptbackground.enable == 1 && getConfig.global.switch.pptbackground.url != '') {
        return {
          background: 'url(' + getConfig.global.switch.pptbackground.url + ') no-repeat',
          backgroundSize: '100% 100%',
        }
      } else {
        return false
      }
    },
    pptfull(){
      let dom = document.querySelector("#app")
      let w = dom && dom.offsetWidth
      let h = dom && dom.offsetHeight
      if(this.ppt_full){
        return {
          top:`${(h-w)/2}px`,
          left:`-${(h-w)/2}px`
        }
      }else{
        return {}
      }
    },
    isHorizontal() {},
    pulldownShwo() {
      let more = this.getConfig && this.getConfig.global.switch.more.data || {}
      if (this.isWx) {
        return (more.info == 0 && more.liveLine == 0 && more.redPackRecord == 0 && more.withdraw == 0 && (more.store && more.store.enable == 0) && more.report == 0) ? false : true
      } else {
        return (more.liveLine == 0 && (more.store && more.store.enable == 0) && more.report == 0) ? false : true
      }
    },
    resizeDoc() {
      if (this.toolsKits.doc) {
        return {
          width: "100%",
          height: "100%"
        };
        this.HTSDK.playerResize();
      } else {
        return "";
      }
    },
    zhuboAvatar() {
      return {
        backgroundImage: "url(" + this.zhubo.p_40 + ")"
      };
    },
    liveState() {
      if (this.getLiveState === "wait") {
        //指定合作商
        if (this.getHtData && this.getHtData.course && this.getHtData.course.course_id == 394363 ||
          this.getHtData && this.getHtData.course && this.getHtData.course.course_id == 394362 ||
          this.getHtData && this.getHtData.course && this.getHtData.course.course_id == 398690) {
          return '敬请期待'
        }
        return "主播暂时不在，稍后再来";
      } else if (this.getLiveState === "stop") {
        return "直播已结束";
      }
    },
    chatList() {
      let result = this.getChatList.map(item => {
        if (item.type === "notify_reward") {
          item.reward = this.notifyRewardHander(item);
          return item;
        }
        if (item.msg && item.msg.indexOf("[IMG]") > -1) {
          item.image = item.msg
            .replace(/\[(.+?)\]/g, "")
            .replace(/_s\.jpg/, ".jpg");
          //  .replace(/_s\.jpg/, '.jpg')
        }
        return item;
      });
      return result;
    },
    total() {
      let total = 0
      this.getProductIdList.forEach(element => {
        if (element.putaway == 1) {
          total += 1
        }
      });
      return total
    },
    background() {
      let getConfig = this.getConfig
      if (getConfig && getConfig.global.switch.background && getConfig.global.switch.background.enable == 1 && getConfig.global.switch.background.url != '') {
        return {
          background: 'url(' + getConfig.global.switch.background.url + ') no-repeat',
          backgroundSize: '100% 100%',
        }
      } else {
        return false
      }
    }
  },
  watch: {
    getHtData(nv, ov) {
      // console.error(nv)
      this.zhubo = nv.zhubo;
    },
    getVideoStatus(nv, ov) {
      // console.error(nv)
      if (nv === "onplay") {
        if (this.getVodPlayVideo) {
          // setTimeout(() => {
          //   if (this.getVodPlayVideo.muted) {
          //     this.getVodPlayVideo.muted = false
          //     this.HTSDK.pause()
          //   }
          // }, 500)
        }
        // this.timer = null;
        // this.clearArrt = setInterval(() => {
        //   if (this.getVodPlayVideo && this.getVodPlayVideo.removeAttribute) {
        //     this.getVodPlayVideo.removeAttribute('poster')
        //     clearInterval(this.clearArrt)
        //   }
        // }, 100);
      }
    },
    getZhuboRewardMsg(nd, od) {
      if (!this.red_animation_timer) {
        this.red_animation = true
        this.red_animation_timer = setTimeout(() => {
          this.red_animation = false
          this.red_animation_timer = null
        }, 8000)
      }
    },
    getProductIdList() {
      if (this.num > 0) {
        this.producUp = true
      }
      this.num += 1;
    },
    getVodPlayVideo(nd) {
      if (nd && nd.addEventListener) {
        this.bindEvent(nd)
      }
      if (nd && nd.removeAttribute) {
        nd.removeAttribute("controls")
      }
      if (nd) {
        // nd.muted = true
        // nd.poster = '//static-1.talk-fun.com/open/cooperation/default/live-h5-v1/static/img/bg_full.png'
        setTimeout(() => {
          // alert("执行")
          this.stop()
        })
        let getConfig = this.getConfig
        let url = '//static-1.talk-fun.com/open/cooperation/default/live-h5-v1/static/img/bg_full.png'
        if (getConfig && getConfig.global.switch.background && getConfig.global.switch.background.enable == 1 && getConfig.global.switch.background.url != '') {
          url = getConfig.global.switch.background.url
        }
        nd.poster = url
      }
    }
  },
  mounted() {
    this.isWx = this.getIsWxClient();
    this.control()
    this.isIos = util.isIos();
    this.jquery(".live_media,.masker,.timer_count,#ht_camera_container,#ht_player_container,#ht_course_container").on("touchend", e => {
      this.tabUp = false;
      this.rankUp = false;
      this.producUp = false;
      this.chatUp = false;
      this.linebox = false;
      // this.infobox = false;
    });
    this.jquery(".live_media,.masker,.timer_count,#ht_camera_container,#ht_player_container,#ht_course_container").on("click", e => {
      this.tabUp = false;
      this.rankUp = false;
      this.producUp = false;
      this.chatUp = false;
      this.linebox = false;
      // this.infobox = false;
    });
    if (document.querySelector("#ht_course_container")) {
      this.bindEvent(document.querySelector("#ht_course_container"))
    }
  }
};
</script>

<style lang="less" scoped>
body .mod-ecom-wp {
  height: 100vh;

  /deep/ #tf-xplay-icon {
    background: none !important;
  }

  .masker {
    position: absolute;
    left: 50%;
    top: 30%;
    // background: rgba(0, 0, 0, 0.9);
    z-index: 1500;
    transform: translate(-50%, 0);
    font-size: 16px;
    color: #b9b9b9;
    padding-top: 2%;
    text-align: center;

    .ico_stop {
      padding-top: 50%;
      display: block;
    }

    .ico_live {
      display: block;
      margin: auto;
      width: 30px;
      height: 30px;
      fill: #ec9b4b;
    }
  }

  ._masker_loading {
    position: absolute;
    // width: 100vw;
    // height: 100vh;
    // background: black;
    top: 30%;
    left: 50%;
    transform: translate(-50%, 0);
    z-index: 1500;

    @keyframes line-grow {
      0% {
        height: 0;
      }

      100% {
        height: 75%;
      }
    }

    .loader {
      position: relative;
      width: 1.2rem;
      height: 1.2rem;
      border-radius: 50%;
      display: inline-block;
      vertical-align: middle;
    }

    .line {
      width: 8px;
      position: absolute;
      border-radius: 5px;
      bottom: 0;
      background: linear-gradient(180deg, rgba(80, 231, 255, 1) 0%, rgba(64, 160, 255, 1) 100%);
    }

    .line1 {
      left: 0;
      animation: line-grow 0.5s ease alternate infinite;
    }

    .line2 {
      left: 20px;
      animation: line-grow 0.5s 0.2s ease alternate infinite;
    }

    .line3 {
      left: 40px;
      animation: line-grow 0.5s 0.4s ease alternate infinite;
    }

    .text_line {
      position: absolute;
      width: 100px;
      font-size: 14px;
      bottom: -30px;
      left: -20px;
      color: #FFFFFF;
      text-align: center;
    }
  }

  .mod_notification_layer {
    position: absolute;
    margin: 20px;
    top: 20%;
    padding: 10px 15px;
    border-radius: 5px;
    line-height: 20px;
    z-index: 501;
    background: rgba(6, 6, 6, 0.8);
    border: 1px solid #565656;
    right: 0;
    left: 0;
    font-size: 12px;
    -webkit-box-shadow: 0 0 14px 0px rgba(0, 0, 0, 0.1);
    box-shadow: 0 0 14px 0px rgba(0, 0, 0, 0.42);

    h2 {
      color: #ff5777;
    }

    .ico_close {
      padding: 5px;
      // background: #060606;
      background-color: #585858;
      border-radius: 50em;
      color: #ffffff;
      position: absolute;
      fill: #fff;
      right: 10px;
      top: 10px;
    }

    .content {
      color: #e0e0e0;
    }
  }

  .ppt_media {
    height: 5.6rem !important;
    display: block !important;
    &.full{
        transform: rotate(90deg);
        width: 100vh !important;
        height: 100vw !important;
        z-index: 999999;
        background: #ffffff;
      }
  }

  .ppt_full{
      position: absolute;
      top: 10px;
      right: 10px;
      z-index: 1000000;
      width:1.2rem/2;
      height:1.2rem/2;
      background:rgba(0, 0, 0, 0.5) url(~@/assets/images/live-v2/full.png) no-repeat;
      background-size: 100% 100%;
      &.full{
        background: rgba(0, 0, 0, 0.5) url(~@/assets/images/live-v2/full.png) no-repeat;
        background-size: 100% 100%;
      }
    }

  .live_media {
    #tf-xplay-icon {
      position: absolute !important;
    }

    position: absolute !important;
    width: 100% !important;
    top: 5.6rem;
    bottom: 0;
    left: 0;
    height: auto !important;
    z-index: 100;
    background: url(../../assets/images/live-v2/bg_full.png) no-repeat;
    background-size: 100% 100%;

    &.partner1 {
      background: url(../../assets/images/bg_parten.png) no-repeat;
      background-size: 100% 100%;
    }

    &.partner2 {
      background: url(../../assets/images/bg_parten2.png) no-repeat;
      background-size: 100% 100%;
    }

    /deep/ video {
      // width: 100vw !important;
      // height: 100vh !important;
      // position: absolute;
      // top: 0;
      // left: 0;
      object-fit: cover;
    }
  }

  .play {
    position: absolute;
    top: 40%;
    left: 50%;
    transform: translate(-50%, 0);
    z-index: 200;
    width: 1rem;
    height: 1rem;
    border-radius: 50%;
    background: rgba(0, 0, 0, .3) url(../../assets/images/live-v2/play.svg) no-repeat;
    background-size: 60% 60%;
    background-position: .24rem .2rem;

    &.stop {
      background: rgba(0, 0, 0, .3) url(../../assets/images/live-v2/stop.svg) no-repeat;
      background-size: 50% 50%;
      background-position: center center;
    }
  }

  .replay {
    position: absolute;
    top: 2rem/2;
    right: .4rem/2;
    z-index: 400;
    width: 1.2rem/2;
    height: 1.2rem/2;
    background: url(../../assets/images/live-v2/refash.png) no-repeat;
    background-size: 100% 100%;
    background-position: center center;
    border-radius: 50%;

    &.replaying {
      animation: replaying 1s linear infinite;
    }

    @keyframes replaying {
      0% {
        transform: rotate(0);
      }

      100% {
        transform: rotate(360deg);
      }
    }
  }

  .full_screen_btn {
    position: absolute;
    top: .5rem/2;
    right: .4rem/2;
    z-index: 400;
    // width:1rem/2;
    // height:1rem/2;
    padding: 2px 10px;
    background: rgba(0, 0, 0, 1);
    // background-size: 60% 60%; 
    // background-position: center center;
    border-radius: 15px;
    font-size: 14px;
    color: #FFFFFF;

    &.replaying {
      animation: replaying 1s linear infinite;
    }

    @keyframes replaying {
      0% {
        transform: rotate(0);
      }

      100% {
        transform: rotate(360deg);
      }
    }
  }

  .full_tab {
    &.tabUp {
      height: 50vh;
    }

    position: absolute;
    bottom: 0;
    width: 100%;
    height: 0;
    z-index: 400;
    display: flex;
    flex-direction: column;
    transition: .5s;
    z-index: 3000;

    .tab {
      width: 100%;
      height: .8rem;
      flex: none;

      .ht_nav_box {
        height: 0;
      }
    }

    .tab_item {
      flex: 1;
    }
  }

  .full_chat {
    .mod_chat_list {
      background: none;
    }

  }

  .bttom_tools {
    position: absolute;
    bottom: -1rem;
    // height: auto;
    width: 100%;
    // background: #565656;
    z-index: 300;
    transition: .5s;

    &.up {
      bottom: 0;
    }

    .tools_warp {
      height: 1rem;
      // background: salmon;
      margin: 0 15px 32px/2;
      position: relative;
      font-size: 16px;

      .left,
      .right {
        position: absolute;

        &>div {
          float: left;
        }
      }

      .left {
        position: absolute;
        height: 100%;
        left: 0;

        .product_icon {
          width: .9rem;
          height: .9rem;
          background: url("../../assets/images/live-v2/product.svg") no-repeat;
          background-size: 100%;
          position: absolute;
          top: 50%;
          transform: translate(0, -50%);
        }
      }

      .right {
        position: absolute;
        height: 100%;
        right: 0;

        &>div {
          width: 1.5rem/2;
          height: 1.5rem/2;
          border-radius: 50%;
          position: relative;
          top: 50%;
          transform: translate(0, -50%);
          margin-left: .8rem/2;
        }

        .chat_icon {
          background: rgba(0, 0, 0, .3) url("../../assets/images/live-v2/chat.svg") no-repeat;
          background-size: 65%;
          background-position: center center;
        }

        .tab_icon {
          background: rgba(0, 0, 0, .3) url("../../assets/images/live-v2/pullup.svg") no-repeat;
          background-size: 60%;
          background-position: center center;
        }

        .like_icon {
          position: relative;
          background: rgba(0, 0, 0, .3) url("../../assets/images/live-v3/like.svg") no-repeat;
          background-size: 130% 130%;
          background-position: center center;

          &>span {
            padding: 2px 6px;
            position: absolute;
            font-size: 14px;
            background: #FF5362;
            border-radius: .18rem;
            color: #fff;
            top: 6px;
            left: 50%;
            transform: translate(-50%, -100%);
          }
        }
      }
    }

  }

  .mod_chat_list {
    position: absolute;
    height: 60vh;
    bottom: 0;
    width: 100%;
    overflow: auto;
    box-sizing: border-box;
    z-index: 300;
    background: #ffffff;
    border-radius: 20px/2 20px/2 0px 0px;
    display: flex;
    flex-direction: column;
    transform: translate(0, 100%);
    transition: .5s;

    &.chatUp {
      transform: translate(0, 0);
    }

    ._title {
      flex: none;
      text-align: center;
      height: 1.76rem/2;
      line-height: 1.76rem/2;
      font-size: 32px/2;
      color: #1b3947;
      border-bottom: 1px solid #d8dce2;
      flex: none;
      position: relative;
    }

    .chat_inner {
      flex: 1;
      padding: 0 .3rem .5rem;
      box-sizing: border-box;
      height: 100%;
      overflow-y: scroll;
      overflow-x: hidden;

      &::-webkit-scrollbar {
        display: none;
      }

      .chat-item {
        .pub_msg {
          display: flex;
          padding: 12px 0 0 0;
          box-sizing: border-box;

          .avatar {
            display: block;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            margin-right: 10px;
          }

          .chat_right {
            flex: 1;

            .chat_head_com {
              font-size: 0;

              .nickname {
                color: #FFCD44;
                font-size: 13px;
              }

              .chat_time {
                color: #B2BDC4;
                font-size: 14px;
              }

              .zhubo {
                display: inline-block;
                font-size: 12px;
                color: #ffffff;
                padding: 0 6px;
                border-radius: 9px;
                margin-right: 30px;
                background: linear-gradient(180deg,
                    rgba(80, 243, 255, 1) 0%,
                    rgba(64, 134, 255, 1) 100%);
              }
            }

            .chat_detail {
              font-size: 14px;
              color: #353A41;
              margin: 6px 0 0 0;
              padding-bottom: 12px;

              /deep/img {
                width: 20px;
                height: 20px;
              }

              &.image {
                img {
                  width: 100%;
                  height: 100px;
                  object-fit: cover;
                  border-radius: 5px;
                }

                padding: 0 !important;
                margin-left: 5px;
                background: none !important;

                &::after {
                  display: none;
                }
              }
            }
          }
        }

        &:nth-last-of-type(1) {
          .pub_msg {
            .chat_right {
              border: none;
            }
          }
        }
      }
    }

  }

  .tab_menu {
    position: absolute;
    height: 60vh;
    bottom: 0;
    width: 100%;
    z-index: 300;
    background: #ffffff;
    border-radius: 20px/2 20px/2 0px 0px;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    transform: translate(0, 100%);
    transition: .5s;

    &.tabUp {
      transform: translate(0, 0);
    }

    .com_menu_head {
      width: 100vw;
      flex: none;
      height: 1.76rem/2;
      overflow: hidden;
      position: relative;
      background: #fff;
      display: flex;

      .ht_nav_list {
        flex: 1;
        height: 100%;
        box-sizing: border-box;
        margin: 0;
        list-style: none;
        padding: 0 15px 2px;
        font-size: 0;
        white-space: nowrap;
        overflow-x: hidden;
        overflow-y: hidden;
        display: flex;

        //  box-sizing: border-box;
        li {

          //  position: absolute;
          &.apply {
            width: 2.8rem/2;
            flex: none;
          }

          flex: 1;
          background: white;
          max-width: 50%;
          height: 100%;
          font-size: 14px;
          text-align: center;
          line-height: 0.9rem;
          color: #797979;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;

          &.selected {
            border-bottom: 2px solid #01c2ff;
            color: #01c2ff;
          }
        }
      }

      .focus {
        flex: none;
        width: 2.2rem/2;
        height: 100%;
        background: #01C2FF;
        color: #FFFFFF;
        text-align: center;
        line-height: .8rem;
        font-size: 15px;
      }
    }

    .mod_modules {
      width: 100%;
      height: 100%;
      flex: 1;
      background: #ffffff;
      border-top: 1px solid #d8dce2;
      -webkit-overflow-scrolling: touch;
      overflow-y: scroll;
      overflow-x: hidden;

      .ppt {
        height: 100%;
        background: rgba(238, 240, 242, 1);
      }

      .tab_content {
        font-size: 14px;
        padding: 0.2rem;
        box-sizing: border-box;
        background: rgba(238, 240, 242, 1);
        min-height: 100%;

        &.apply {
          background: #ffffff;

          ul {
            // margin: 0.4rem 0.3rem;
            margin-top: .4rem;
            // padding-top: 0.4rem;
            list-style: none;

            &::after {
              content: "";
              display: block;
              clear: both;
            }

            li {
              float: left;
              margin: 0 .22rem .55rem;
              text-align: center;
              width: 2.6rem/2;
              height: 2.6rem/2;

              // background: saddlebrown;
              // &:nth-of-type(4n) {
              //   margin: 0;
              // }

              // &:nth-of-type(n+5) {
              //   margin-top: 0.55rem;
              // }

              .item {
                width: 0.8rem;
                height: 0.8rem;
                // border-radius: 50%;
                margin: 0 auto 0.1rem;
                // background: white;

                &:active {
                  background: #e7ecef;
                }

                span {
                  display: inline-block;
                  width: 100%;
                  height: 100%;
                  vertical-align: -0.48rem;
                }

                &.reward_icon {
                  span {
                    background: url("../../assets/images/reward_icon.svg") no-repeat;
                    background-size: 100% 100%;
                  }
                }

                &.reward_cash {
                  span {
                    background: url("../../assets/images/re_cash.svg") no-repeat;
                    background-size: 100% 100%;
                  }
                }

                &.product_icon {
                  span {
                    background: url("../../assets/images/live-v2/product.svg") no-repeat;
                    background-size: 100%;
                  }
                }

                &.line_icon {
                  span {
                    background: url("../../assets/images/live-v2/network.svg") no-repeat;
                    background-size: 100%;
                  }
                }

                &.info_icon {
                  span {
                    background: url("../../assets/images/live-v2/person.svg") no-repeat;
                    background-size: 100%;
                  }
                }

                &.report_icon {
                  span {
                    background: url("../../assets/images/live-v2/report.svg") no-repeat;
                    background-size: 100%;
                  }
                }
              }
            }
          }
        }

        /deep/img {
          width: 100%;
        }
      }

      .no_data {
        position: absolute;
        width: 100px;
        height: 120px;
        background: url(../../assets/images/live/rankdate.svg) no-repeat;
        background-size: 100%;
        top: 1.5rem;
        left: 0;
        right: 0;
        margin: auto;

        .tip {
          width: 100%;
          text-align: center;
          position: absolute;
          font-size: 16px;
          color: rgba(158, 176, 196, 1);
          bottom: -10px;
        }
      }
    }
  }

  .side-content-wp {
    z-index: 200;
    top: 0;

    /deep/.like_warp {
      right: 0;
      bottom: 1.2rem;
    }
  }

  @color_1: #FFFFFF;
  @color_2: #ff5777;

  .head-section {
    position: relative;
    font-size: 12px;
    z-index: 105;
    padding-top: .18rem;
    padding-left: .2rem;
    height: 0.8rem;
    // opacity: .7;
    background-image: linear-gradient(0deg, transparent, rgba(0, 0, 0, .02) 18%, rgba(0, 0, 0, .6));
    display: flex;

    .top_bar_tools {
      line-height: 0.8rem;

      span {
        display: inline-block;
        padding: 0 5px;
      }

      svg {
        fill: #d2d2d2;

        &:hover {
          fill: #d2d2d2;
        }
      }
    }

    .focus-actor {
      display: flex;
      flex: 1;
      opacity: .7;

      .actor-avatar {
        position: relative;
        margin-right: .1rem;
        width: .5rem;
        height: .5rem;
        border-radius: 50%;
        background-repeat: no-repeat;
        background-size: 100% auto;
      }

      .actor-tag {
        position: absolute;
        right: -.02rem;
        bottom: 0;
        width: .2rem;
        height: .2rem;
        border-radius: 50%;
        background-repeat: no-repeat;
        background-size: cover;
      }

      .info {
        margin-right: .15rem;
        color: @color_1;
      }

      .online-num {
        font-size: 11px;
        display: flex;
      }

      .focus-btn {
        font-size: 12px;
        width: .88rem;
        height: .4rem;
        border-radius: .5rem;
        border: 1px solid #ff5777;
        color: @color_2;
        line-height: .4rem;
        text-align: center;
      }

      .subscribe-btn {
        font-size: 12px;
        width: .88rem;
        height: .5rem;
        border-radius: .5rem;
        border: 1px solid #ff5777;
        color: @color_2;
      }

      .has-subscribe-btn-btn {
        font-size: 12px;
        width: 1rem;
        height: .5rem;
        border-radius: .5rem;
        border: 1px solid #fff;
        color: @color_1;
      }
    }
  }

  .loading {
    width: 100vw;
    height: 100vh;
    position: absolute;
    bottom: 0;
    z-index: 9999;
    background: white;
    font-size: 16px;
    text-align: center;
    color: rgba(22, 63, 78, 1);

    &.hidden {
      display: none;
    }

    .loading_bg {
      position: absolute;
      top: 40vh;
      left: 0;
      right: 0;

      @keyframes bouncedelay {

        0%,
        80%,
        100% {
          -webkit-transform: scale(0.0)
        }

        40% {
          -webkit-transform: scale(1.0)
        }
      }

      .cicle_warp {
        margin-top: .4rem;

        .cicle {
          display: inline-block;
          width: .28rem;
          height: .28rem;
          background: linear-gradient(90deg, rgba(112, 179, 255, 1) 0%, rgba(59, 203, 241, 1) 100%);
          border-radius: 50%;
          margin: 0 .08rem;
          animation: bouncedelay 1.4s infinite ease-in-out;
          animation-fill-mode: both;
        }

        .cicle1 {
          animation-delay: -0.32s;
        }

        .cicle2 {
          animation-delay: -0.16s;
        }
      }
    }
  }

  .top_infomation {
    /deep/ .rank_top_show {
      margin-top: 10px;
    }
  }

  .ppt_media {
    position: absolute;
    width: 100%;
    height: 5.6rem;
  }

  .live_media {
    top: 5.6rem;
    bottom: 0;
    left: 0;
    right: 0;
    height: auto;

    /deep/video {
      height: 100% !important;
    }
  }

  ._masker_loading {
    top: 8rem;
  }

  .masker {
    top: 5.6rem;
    height: auto;

    .masker_content {
      margin-top: 1.5rem;

      &.no_icon {
        margin-top: 3rem;
      }
    }
  }

  .camera_status {
    top: 5.6rem;
    bottom: 0;
    left: 0;
    right: 0;
    height: auto;
  }

  .replay {
    top: 6rem;
  }

  .top_infomation {
    top: 6rem;
  }
}
</style>
