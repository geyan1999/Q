<template>
<div class="mod-company-wp" :class="getScreenStatus">
  <div id="warp_top">
    <div id="video_warp">
      <!-- 视频区域 -->
      <div id="ht_camera_container" class="live" :class="{model_16_9:advertisement}" v-show="liveCurMode === 0 && getVideoCurMode==0"></div>
      <!-- 桌面分享 -->
      <div id="ht_player_container" class="live" :class="{model_16_9:advertisement}" v-show="getVideoCurMode == 0 && liveCurMode === 2"></div>
      <!-- 控制条 -->
      <control v-show="controlShow"></control>
    </div>
    <!-- 广告位 -->
    <advertisement-view v-if="getConfig&&getConfig.global.switch.banner.enable==1"></advertisement-view>
    <!-- 导航栏 -->
    <tab-com class="tab" v-if="getConfig"></tab-com>
  </div>
  <!-- 选项卡区域 -->
  <tab-item-com v-if="getConfig"></tab-item-com>
  <!-- 工具栏 -->
  <tools-view v-if="getConfig"></tools-view>
  <!-- 加载中动画 -->
  <div class="loading hidden" id="loading">
    <div class="loading_bg">
      正在加载中
      <div class="cicle_warp">
        <div class="cicle1 cicle"></div>
        <div class="cicle2 cicle"></div>
        <div class="cicle3 cicle"></div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
import {
  mapGetters
} from "vuex";
import OnlineTotal from "../OnlineTotal";
import TabItemCom from "../TabItemCom";
import ScrollNoticeView from "../ScrollNoticeView";
import TabCom from "../TabCom";
import RewardView from "../RewardView";
import LotteryView from "../LotteryView";
import SideContent from "../SideContent";
import RedAnimation from "../RedAnimation"
import AdvertisementView from "../AdvertisementView"
import Control from "./ControlView"
import ToolsView from "@/components/ToolsView"
import * as util from "../../assets/js/util";
import * as TYPES from "@/assets/action-types";
export default {
  name: "ModCompanyView",
  data() {
    return {
      maskInfo: "正在加载...",
      re_text: "刷新",
      isreplay: false,
      timer: null,
      advance: false,
      red_animation: false,
      advertisement: true,
      isIos: false,
      controlShow: true,
      timer_control: null,
      mousemove: null,
      frist: true
    };
  },
  components: {
    OnlineTotal,
    TabItemCom,
    ScrollNoticeView,
    TabCom,
    RewardView,
    LotteryView,
    SideContent,
    RedAnimation,
    AdvertisementView,
    Control,
    ToolsView
  },
  methods: {
    back() {
      if (window.history) {
        window.history.back()
      }
    },
    replay() {
      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => {
        if (this.HTSDK) {
          this.HTSDK.reload();
          this.timer = null;
        }
      }, 1000);
    },
    stop() {
      this.HTSDK.pause()
      this.$store.commit("changePlayStatus", "pause");
    },
    full() {
      let targetDiv = this.liveCurMode == 0 ? document.querySelector("#ht_camera_container") : document.querySelector("#ht_player_container");
      targetDiv.getElementsByTagName("video")[0].webkitEnterFullScreen()
    },
    showred(flag) {
      this.red_animation = flag
    },
    config(type) {
      let flag = false;
      if (this.getConfig) {
        this.getConfig.content.tabsData.forEach((item) => {
          if (item.type === type) {
            flag = true
          }
        })
      }
      return flag
    },
    bindEvent(dom) {
      dom.addEventListener('touchstart', () => {
        this.clear()
        this.toolsUp = true
        if (this.toolTimer) {
          clearTimeout(this.toolTimer)
          this.toolTimer = setTimeout(() => {
            this.toolsUp = false
            this.toolTimer = null
          }, 2000)
        } else {
          this.toolTimer = setTimeout(() => {
            this.toolsUp = false
            this.toolTimer = null
          }, 2000)
        }
      })
    },
    clear() {
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'more',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'redAnimation',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'rank',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'line',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'private',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'product',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'infomation',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'redpackPop',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'emoji',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'menu',
        flag: false
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'vote',
        flag: false
      })
    },
  },
  computed: {
    ...mapGetters([
      "getMemberTotal",
      "getHtData",
      "getLiveState",
      "getScreenStatus",
      "getActModule",
      "getRewardState",
      "getListReward",
      "getRewardDebug",
      "getFlagReward",
      "liveCurMode",
      "getLottery",
      "getVideoCurMode",
      "getVideoStatus",
      "getPPTModel",
      "getVideoPause",
      "getConfig",
      "getVodPlayVideo"
    ]),
    isHorizontal() {},
    resizeDoc() {
      if (this.toolsKits.doc) {
        return {
          width: "100%",
          height: "100%"
        };
        this.HTSDK.playerResize();
      } else {
        return "";
      }
    },
    zhuboAvatar() {
      return {
        backgroundImage: "url(" + this.zhubo.p_40 + ")"
      };
    },
    liveState() {
      if (this.getLiveState === "wait") {
        return "主播暂时不在，稍后再来"
      } else if (this.getLiveState === "stop") {
        return "直播已结束"
      }
    }
  },
  watch: {
    getHtData(nv, ov) {
      this.zhubo = nv.zhubo;
    },
    red_animation(nd, od) {
      if (nd) {
        setTimeout(() => {
          this.red_animation = false
        }, 8000)
      }
    },
    getVodPlayVideo(nd) {
      if (nd && nd.addEventListener) {
        this.bindEvent(nd)
      }
      if (nd && nd.removeAttribute) {
        nd.removeAttribute("controls")
      }
      if (nd && nd.setAttribute) {
        if (this.frist) {
          setTimeout(() => {
            this.stop()
            // this.frist = false
          })
        }
        let getConfig = this.getConfig
        let url = ''
        if (getConfig && getConfig.global.switch.intro && getConfig.global.switch.intro.url) {
          url = getConfig.global.switch.intro.url
        }
        let timer = setInterval(() => {
          nd.setAttribute('poster', url)
          // console.error(nd)
        })
        setTimeout(() => {
          clearInterval(timer)
        }, 2000);
      }
    }
  },
  mounted() {
    this.isIos = util.isIos();
    if (this.getConfig && this.getConfig.global.switch.banner.enable == 1) {
      this.advertisement = true
    }
  }
};
</script>

<style src='@/assets/less/mod_company.less' lang='less'></style>
