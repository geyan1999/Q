<template>
<div class="_control" v-show="!onFull" :class="{full_model:getPageModel!=0,couse_model:getPageModel==2}">
  <div class="tools">
    <!-- 暂停 -->
    <span class="talkfunfont stop icon" @click="videoControl('stop')" v-show="getPlayStatus==='play' || getPlayStatus==='waiting'" title="暂停">&#xe626;</span>
    <!-- 开始 -->
    <span class="talkfunfont start icon" @click="videoControl('start')" v-show="getPlayStatus==='pause' || getPlayStatus==='stop'" title="播放">&#xe61c;</span>
    <!-- 重放 -->
    <span class="talkfunfont replay icon" @click="videoControl('replay')" title="停止">&#xe69d;</span>
    <!-- 播放时间 -->
    <span class="time icon">
      <span class="curtime">{{vodCurTime}}</span>
      <div class="slider_container">
        <el-slider v-model="curtime" @change="video" :format-tooltip="formatCurtime" :tooltip-class="'curtime-slider-tips'"></el-slider>
      </div>
      <span>{{vodTotalTime}}</span>
    </span>
    <!-- 播放速度 -->
    <span class="speed icon" title="倍速播放" @click.stop="speedPull()">{{!curSpeed?'倍速':curSpeed===1?'1.0x':curSpeed+'x'}}
      <span class="speed_pull" v-if="speedflag" title>
        <span @click.stop="switchSpeed(1)" :class="{select:curSpeed == 1 || curSpeed == 0}">正常</span>
        <span @click.stop="switchSpeed(1.2)" :class="{select:curSpeed == 1.2}">1.2x</span>
        <span @click.stop="switchSpeed(1.5)" :class="{select:curSpeed == 1.5}">1.5x</span>
        <span @click.stop="switchSpeed(1.8)" :class="{select:curSpeed == 1.8}">1.8x</span>
        <span @click.stop="switchSpeed(2)" :class="{select:curSpeed == 2}">2.0x</span>
      </span>
    </span>
    <!-- 全屏按钮 -->
    <span class="full icon" title="全屏" @click.stop="videoFullScreen()">全屏</span>
  </div>
</div>
</template>

<script>
import {
  mapGetters
} from "vuex";
import * as tools from "../../assets/js/util";
import * as TYPES from "../../assets/action-types";
export default {
  data() {
    return {
      curtime: 0,
      curvolume: 80,
      beforevolume: 0,
      seeklock: false,
      silence: false,
      SourceLine: [],
      Sourceflag: false,
      speedflag: false,
      ischange: false,
      curSource: 0,
      curSpeed: 0,
      vodmodel: window.playback_type,
      vodCurTime: "00:00:00",
      fullStatus: false,
      timer: null,
      onFull: false,
      mousemove: null,
      isIos: false
    };
  },
  props: ['toolsUp'],
  methods: {
    video(val) {
      this.seeklock = false;
      let precent = val / 100;
      let sliderTime = this.getPcVod.duration * precent;
      this.HTSDK.play();
      this.HTSDK.seek(sliderTime);
      this.$emit("Time", 'end')
      setTimeout(function () {
        if (document.querySelector(".curtime-slider-tips")) {
          document.querySelector(".curtime-slider-tips").style.display = "none";
        }
      }, 0);
    },
    volume(val) {
      // console.log(val);
      setTimeout(function () {
        if (document.querySelector(".volume-slider-tips")) {
          // document.querySelector(".volume-slider-tips").style.display = "none";
        }
      }, 0);
      if (val === 0) {
        this.silence = true;
        this.curvolume = 0;
      } else {
        this.silence = false;
        this.curvolume = val;
      }
      this.HTSDK.volume((val / 100) + '');
    },
    novolume() {
      this.silence = true;
      this.beforevolume = this.curvolume;
      this.curvolume = 0;
      this.HTSDK.volume("0");
      // console.log("cur before", this.curvolume, this.beforevolume);
    },
    formatCurtime(val) {
      let precent = val / 100;
      let sliderTime = this.getPcVod.duration * precent;
      return tools.second2HMS(sliderTime, "total");
    },
    videoControl(type) {
      this.$emit("Time")
      if (type === "stop") {
        this.HTSDK.pause();
        this.$store.commit("changePlayStatus", "pause");
      } else if (type === "start") {
        this.HTSDK.play();
        this.seeklock = false;
        this.$store.commit("changePlayStatus", "play");
      } else if (type === "replay") {
        this.seeklock = true;
        this.curtime = 0;
        this.HTSDK.stop();
        this.vodCurTime = "00:00:00";
        this.$store.commit("changePlayStatus", "stop");
      }
    },
    getSource() {
      this.HTSDK.getSource(sourceCount => {
        this.SourceLine = new Array(sourceCount);
        this.Sourceflag = !this.Sourceflag;
        this.speedflag = false;
      });
    },
    switchSource(sourceNum) {
      this.curSource = sourceNum;
      this.Sourceflag = false;
      this.HTSDK.changeSource(sourceNum, ret => {
        // console.log("切换线路");
      });
    },
    switchSpeed(speed) {
      this.HTSDK.playRate(speed);
      this.curSpeed = speed;
      this.speedflag = false;
      this.$vux.toast.text(`已为你切换${this.curSpeed==1?'1.0':this.curSpeed}x倍速`, `${this.getPageModel!=0?'center':'bottom'}`)
    },
    speedPull() {
      this.speedflag = !this.speedflag;
      this.Sourceflag = false;
    },
    toggleVideo() {
      let player = document.querySelector("#ht_player_container");
      let camera = document.querySelector("#ht_camera_container");
      let playerview = document.querySelector(".player_container");
      let cameraview = document.querySelector(".camera_container");
      let toggleplayer = document.querySelector(".toggle_player_container");
      let togglecamera = document.querySelector(".toggle_camera_container");
      if (this.ischange) {
        this.ischange = false;
        cameraview.appendChild(camera);
        this.$emit("toggleVideo", false);
      } else {
        this.ischange = true;
        toggleplayer.appendChild(camera);
        this.$emit("toggleVideo", true);
      }
    },
    bindEvent() {
      document.addEventListener("click", () => {
        this.Sourceflag = false;
        this.speedflag = false;
      });
    },
    videoFullScreen() {
      let targetDiv = this.liveCurMode == 0 ? document.querySelector("#ht_camera_container") : document.querySelector("#ht_player_container");
      let video = targetDiv.getElementsByTagName("video")[0]
      if (video && video.webkitEnterFullScreen) {
        video.webkitEnterFullScreen()
        if (this.isIos) {
          video.addEventListener('pause', this.exitFullEvent)
          video.addEventListener('webkitendfullscreen', () => {
            setTimeout(() => {
              video.removeEventListener('pause', this.exitFullEvent)
            }, 2000)
          })
          video.addEventListener('x5videoexitfullscreen', () => {
            video.removeEventListener('pause', this.exitFullEvent)
          })
        }

      }
    },
    exitFullScreen() {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      } else if (document.oRequestFullscreen) {
        document.oCancelFullScreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      } else {

      }
    },
    fullEvent() {},
    exitFullEvent() {
      this.HTSDK.play()
    }
  },
  computed: {
    ...mapGetters([
      "getPcVod",
      "liveCurMode",
      "getPlayStatus",
      "getPageModel"
    ]),
    vodTotalTime() {
      return tools.second2HMS(this.getPcVod.duration, "total");
    }
  },
  watch: {
    getPcVod(nv, ov) {
      if (this.getPlayStatus === "play") {
        this.vodCurTime = tools.second2HMS(this.getPcVod.currentTime, "total");
      }
      if (!this.seeklock) {
        this.curtime = this.getPcVod.currentPercent * 100;
        this.isplay = true;
      }
    },
    speedflag(nv) {
      if (nv) {
        this.$emit("Time", 'start')
      } else {
        this.$emit("Time", 'end')
      }
    },
    toolsUp(nv) {
      if (!nv) {
        this.speedflag = false
      }
    }
  },
  mounted() {
    this.isIos = tools.isIos();
    setTimeout(() => {
      let sliderButton = document.querySelectorAll(".el-slider__button");
      let sliderContainer = document.querySelector(".slider_container");
      // console.error(sliderButton);
      sliderButton[0].addEventListener("mousedown", () => {
        this.seeklock = true;
      });
      sliderButton[0].addEventListener("touchstart", () => {
        this.seeklock = true;
        this.$emit("Time", 'start')
        setTimeout(function () {
          if (document.querySelector(".curtime-slider-tips")) {
            document.querySelector(".curtime-slider-tips").style.display =
              "block";
          }
        });
      });
      sliderButton[0].addEventListener("mouseup", () => {
        this.seeklock = false;
      });
      sliderButton[0].addEventListener("touchend", () => {
        this.seeklock = false;
      });
      sliderContainer.addEventListener("click", event => {
        if (event.target.className === "slider_container") {
          if (event.clientX < 10) {
            this.curtime = 0;
            this.HTSDK.seek(0);
          } else {
            this.curtime = Number(this.getPcVod.duration);
            this.HTSDK.seek(Number(this.getPcVod.duration - 2));
          }
        }
      });
    });
    this.bindEvent();
  }
};
</script>

<style lang="less">
@font-face {
  font-family: 'talkfunfont';
  /* project id 963250 */
  src: url('../../assets/font/iconfont.eot');
  src: url('../../assets/font/iconfont.eot?#iefix') format('embedded-opentype'),
    url('../../assets/font/iconfont.woff2') format('woff2'),
    url('../../assets/font/iconfont.woff') format('woff'),
    url('../../assets/font/iconfont.ttf') format('truetype'),
    url('../../assets/font/iconfont.svg#talkfunfont') format('svg');
}

._control {
  z-index: 18;

  // 第三方样式
  .el-slider__button-wrapper {
    width: 12px;
    height: 12px;
    top: -6px;
    z-index: 100;

    .el-slider__button {
      width: 100%;
      height: 100%;
      // vertical-align: -1px;
      display: block;
    }
  }

  .el-slider__runway {
    margin: 0 !important;
    height: 4px;
    background-color: #8794a5 !important;
  }

  .el-slider__bar {
    background-color: #5489e9 !important;
    height: 4px;
  }

  .el-checkbox__label {
    color: white !important;
  }

  .el-slider__button {
    border: 2px solid #01C2FF;
  }

  .volume-slider-tips {
    padding: 2px 10px !important;
  }
}

.talkfunfont {
  font-family: 'talkfunfont';
  font-style: normal;
}

._control {
  background: #111822;
  width: 100%;
  height: 40px;

  &.full_model {
    background: none;
    // height: .3rem;
    box-sizing: border-box;
    padding: 0 5px;
    margin: .5rem 0;

    &.couse_model{
      margin: 0 0 .2rem;
      .tools{
        .icon{
          &.full{
            display: block;
            margin: 0;
            background: none;
          }
        }
      }
    }

    .tools {
      // height: 100%;
      background: rgba(0, 0, 0, .3);
      border-radius: 30px;
      position: relative;
      top: 50%;
      transform: translateY(-50%);
      text-align: center;
      -ms-flex-pack: center;
      justify-content: center;

      .icon {
        font-size: 14px;
        margin: 0;
        margin-right: 10px;

        &.full {
          display: none;
        }
        &.speed{
          background: none;
          margin: 0;
          .speed_pull{
            top: -14px;
            right: 0px;
          }
        }
      }

      .time {

        .el-slider__runway {
          background: #FFFFFF !important;

          .el-slider__bar {
            background: #FF8050 !important;
          }

          .el-slider__button-wrapper {
            top: -4px;

            .el-slider__button {
              border: none !important;
            }
          }
        }

      }
    }
  }

  .tools {
    line-height: normal;
    color: white;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 100%;
    padding: 0 .3rem;
    box-sizing: border-box;

    .icon {
      position: static;
      cursor: pointer;
      font-size: 20px;
      // margin: 0 20px;
    }

    .replay {
      display: none;
    }

    .time {
      left: 148px;
      font-size: 12px;
      cursor: text;
      margin: 0 0 0 10px;
      // width: 80%;
      flex: 1;
      display: flex;
      align-items: center;

      .slider_container {
        width: 100%;
        padding: 0 10px;
        height: 4px;
      }
    }

    .full {
      display: flex;
      flex: none;
      padding: 0 5px;
      height: 28px;
      background: #6983b2;
      border-radius: 4px;
      line-height: 28px;
      font-size: 12px;
      text-align: center;
    }

    .speed {
      display: inline-block;
      padding: 0 5px;
      height: 28px;
      background: #6983b2;
      border-radius: 4px;
      line-height: 28px;
      font-size: 12px;
      text-align: center;
      position: relative;
      margin: 0 10px 0;

      .speed_pull {
        position: absolute;
        top: -6px;
        display: flex;
        flex-direction: column;
        z-index: 100;
        // width: 80px;
        // height: 158px;
        text-align: center;
        background: rgba(0, 0, 0, 0.6);
        right: -2px;
        font-size: 14px;
        box-shadow: 0px 3px 10px 0px rgba(0, 0, 0, 0.2);
        border-radius: 6px;
        padding: 5px 15px;
        transform: translate(0, -100%);
        box-sizing: border-box;
        white-space: nowrap;

        &::after {
          content: "";
          display: block;
          width: 0;
          height: 0;
          border: 5px solid transparent;
          border-top-color: #323a45;
          position: absolute;
          bottom: -10px;
          left: 34px;
        }

        &>span:hover {
          color: #32dbff;
        }

        .select {
          color: #32dbff;
        }
      }
    }

    .life-line {
      position: relative;
      left: 10px;

      &.vod_pc {
        right: 166px;
      }

      .sourceLine_warp {
        width: 80px;
        display: flex;
        position: absolute;
        bottom: 42px;
        left: -28px;
        color: white;
        flex-direction: column;
        line-height: 25px;
        background: #323a45;
        text-align: center;
        font-size: 14px;
        padding: 8px 0;
        box-shadow: 0px 3px 10px 0px rgba(0, 0, 0, 0.2);
        border-radius: 4px;

        &::after {
          content: "";
          display: block;
          width: 0;
          height: 0;
          border: 5px solid transparent;
          border-top-color: #323a45;
          position: absolute;
          bottom: -10px;
          left: 34px;
        }

        .select {
          color: #32dbff;
        }
      }
    }

    .tab {
      right: 172px;
    }

    .volume_warp {
      position: static;
      width: 25%;
      display: flex;
      align-items: center;

      .volume-slider {
        flex: 1;
        padding: 0 10px;

        .el-slider__button {
          width: 10px;
          height: 10px;

        }

        .el-slider__runway {
          display: flex;
          height: 4px;
        }

        .el-slider__bar {
          height: 4px;
        }
      }

      .volume {
        position: static;
        padding-right: 10px;
      }
    }
  }
}
</style>
