<template>
  <div class="sign_warp" v-if="getSignStatus!=='end'">
    <div class="sign_contener" v-show="getSignStatus==='start'">
      <div class="sign_wp"></div>
      <div class="sign_bg">{{time|formatTimer}}</div>
      <div class="sign_time">倒计时</div>
      <div class="sign_bt" @click.stop="sign()">签到</div>
      <div class="sign_close" @click.stop="close()"></div>
    </div>
    <div class="sign_success" v-show="getSignStatus==='success'">
      <div class="icon"></div>
      <div class="tip">签到成功</div>
    </div>
  </div>
</template>
<script>
import {
  mapGetters,
  mapActions
} from "vuex"
export default {
  data() {
    return {
      time:0,
      timer:null
    }
  },
  computed: {
    ...mapGetters(["getSign","getSignStatus"])
  },
  filters: {
    formatTimer(value) {
      var secondTime = parseInt(value); // 秒
      var minuteTime = 0; // 分
      var hourTime = 0; // 小时
      var day = 0;
      if (secondTime > 60) {
        //如果秒数大于60，将秒数转换成整数
        //获取分钟，除以60取整数，得到整数分钟
        minuteTime = parseInt(secondTime / 60);
        //获取秒数，秒数取佘，得到整数秒数
        secondTime = parseInt(secondTime % 60);
        //如果分钟大于60，将分钟转换成小时
        if (minuteTime > 60) {
          //获取小时，获取分钟除以60，得到整数小时
          hourTime = parseInt(minuteTime / 60);
          //获取小时后取佘的分，获取分钟除以60取佘的分
          minuteTime = parseInt(minuteTime % 60);
        }
        // console.error(hourTime)
        if (hourTime >= 24) {
          //获取天数，获取小时除以24，得到整数天数
          day = parseInt(hourTime / 24);
          //获取天输后取佘的小时，获取天数除以24取佘的小时
          hourTime = parseInt(hourTime % 24);
          // console.error(day,hourTime)
        }
      }
      return `${(parseInt(minuteTime)>=0&&parseInt(minuteTime)<10)?`0${parseInt(minuteTime)}`:`${parseInt(minuteTime)}`}
      :
      ${(parseInt(secondTime)>=0&&parseInt(secondTime)<10)?`0${parseInt(secondTime)}`:`${parseInt(secondTime)}`}` ;
    }
  },
  watch: {
    getSignStatus(nv){
      if(nv==='start'){
        this.time = this.getSign && this.getSign.data.duration
        this.upTiem()
      }
      if(nv==='end'){
        this.time = 0
        clearInterval(this.timer)
      }
      if(nv==='success'){
        setTimeout(()=>{
          this.$store.commit("UPDATA_SIGN_STATUS",'end')
        },2000)
      }
    }
  },
  methods: {
    ...mapActions({
      post:"POST_SIGN"
    }),
    sign(){
      this.post({
        vm:this,
        data:{
          access_token:window.access_token,
          signId: (this.getSign&&this.getSign.data.signId)||0
        }
      })
      this.$vux.loading.show()
    },
    close(){
      this.$store.commit("UPDATA_SIGN_STATUS",'end')
    },
    upTiem() {
      this.timer = setInterval(() => {
        if (this.time == 0) {
          clearInterval(this.timer);
          return
        }
        this.time -= 1;
      }, 1000);
    }
  },
}
</script>
<style lang="less" scoped>
.sign_warp{
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, .6);
  position: absolute;
  top: 0;
  left: 0;
  .sign_contener{
    width:11.2rem/2;
    height:9.16rem/2;
    background:rgba(255,249,242,1);
    border-radius:.4rem/2;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    .sign_wp{
      height: 3.16rem/2;
      background: url(~@/assets/images/live-v3/sign_wp.png) no-repeat;
      background-size: 100% 100%;
    }
    .sign_bg{
      width: 3.92rem/2;
      height: 3.2rem/2;
      line-height: 3.6rem/2;
      background: url(~@/assets/images/live-v3/sign_bg.png) no-repeat;
      background-size: 100% 100%;
      font-size: 16px;
      color: #FF5454;
      text-align: center;
      position: absolute;
      top: .28rem;
      left: 50%;
      transform: translateX(-50%);
    }
    .sign_time{
      width: 7.56rem/2;
      height: 1.84rem/2;
      background: url(~@/assets/images/live-v3/sign_bottom.png) no-repeat;
      background-size: 100% 100%; 
      text-align: center;
      color: #ffffff;
      line-height: 1.7rem/2;
      font-size: 14px;
      position: absolute;
      top: 1.44rem;
      left: 50%;
      transform: translateX(-50%);
    }
    .sign_bt{
      width:7.2rem/2;
      height:1.76rem/2;
      background:linear-gradient(180deg,rgba(255,172,77,1) 0%,rgba(255,114,78,1) 100%);
      box-shadow:0px 4px 12px rgba(255,114,78,0.4);
      border-radius:.88rem/2;
      color: #ffffff;
      text-align: center;
      line-height: 1.76rem/2;
      font-size: 20px;
      position: absolute;
      bottom: 1rem/2;
      left: 50%;
      transform: translateX(-50%);
    }
    .sign_close{
      width: 1.6rem/2;
      height: 1.6rem/2;
      // border: 1px solid #ffffff;
      // border-radius: 50%;
      position: absolute;
      bottom: -100px;
      left: 50%;
      transform: translateX(-50%);
      background: url(~@/assets/images/live-v3/sign_close.png) no-repeat;
      background-size: 100% 100%;
    }
  }
  .sign_success{
      width: 6.92rem/2;
      height: 6.92rem/2;
      background: #ffffff;
      position: absolute;
      margin: auto;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      border-radius: .4rem/2;
      .icon{
        width: 5.2rem/2;
        height: 3.12rem/2;
        margin: 1.08rem/2 auto .76rem/2;
        background: url(~@/assets/images/live-v3/sign2.png) no-repeat;
        background-size: 100% 100%;
      }
      .tip{
        font-size: 18px;
        color: #1B3947;
        text-align: center;
      }
    }
}
</style>


