<template>
<!-- chat Post -->
<div id="mode_chat_post" class="mod_chat_post_v2" :class="{full_mode:getPageModel!=0,pull_post:(onSend||getToolsEmoji)&&getPageModel!=0,red:styleRed}" @click.stop="">
  <!-- 网络优化提示 -->
  <div class="network_tip" v-if="networkTip&&isVod==0&&getLiveState === 'start'">
    <span>直播不流畅，请尝试</span>
    <span class="try_replay try_btn" @click.stop="replay">刷新</span>
    <span class="try_switch try_btn" @click.stop="openTools('line')">切换网络</span>
  </div>
  <!-- 聊天区 -->
  <div class="post_con">
    <!-- 商城 -->
    <span class="product" :class="{animation:productPop}" @click="openTools('product')" v-if="(getConfig&&getConfig.global.switch.store.enable == 1&&!onSend&&!getToolsEmoji)">
      <span v-if="ProductTotal">{{ProductTotal}}</span>
    </span>
    <!-- 输入框 -->
    <span class="mod_chat_ipt" v-if="config('chat')&&!isVod">
      <input id="chat_post_txt" type="text" placeholder="来说点什么吧" autocomplete="off" @focus="onChatFocus()" :chatMsg="chatMsg" @blur="onBlur()" v-model.trim="chatMsg" />
      <!-- 表情 -->
      <span class="emoji_btn" :class="{send:getToolsEmoji}" @click.stop="openEmoji($event)" v-show="onSend||getToolsEmoji"></span>
    </span>
    <span class="mod_chat_ipt no_chat" v-if="!config('chat')||isVod" :class="{vod:isVod}">不能发送聊天...</span>
    <!-- 功能区 -->
    <div class="icon_warp">
      <!-- 发送 -->
      <span data-type="chat" @click.stop="chat_send($event)" class="csend" :class="{onsend:chatMsg}" v-if="(onSend&&config('chat'))||getToolsEmoji">发送</span>
      <!-- 自定义菜单 -->
      <span class="tab" @click.stop="openTools('menu')" v-if="getConfig && getConfig.global.switch.menu.enable == 1 && !onSend && !getToolsEmoji && getPageModel!=0"></span>
      <!-- 分享 -->
      <span class="share" @click.stop="goshare()" v-if="getConfig&&getConfig.global.switch.inviteRanking.enable == 1 && isWx && !onSend && !isVod && !getToolsEmoji"></span>
      <!-- 更多菜单 -->
      <span ref="pull_down_icon" @click.stop="openTools('more')" class="pull_down_icon" v-if="!onSend&&pulldownShwo&&!getToolsEmoji">
        <span class="private_chat_tip" v-show="(PvChatTip && getConfig && getConfig.global.switch.service && getConfig.global.switch.service.enable == 1 && !isVod)||(getQuesTip&&getPageModel!=0)"></span>
      </span>
      <!-- 红包打赏 -->
      <span class="redpack" @click.stop="openTools('redpack')" v-if="getConfig && (getConfig.global.switch.redPack.enable == 1||getConfig.global.switch.reward.enable == 1) && isWx && !isVod &&!onSend &&!getToolsEmoji">
        <span class="open_wp" v-show="getToolsRedpackPop">
          <span class="redpack_bg" @click.stop="redpop('redpack')" v-if="getConfig && getConfig.global.switch.redPack.enable == 1 && isWx && !isVod">
            <i class="icon"></i>
            群发红包
          </span>
          <span class="reward_bg" @click.stop="redpop('award')" v-if="getConfig && getConfig.global.switch.reward.enable == 1 && isWx && !isVod">
            <i class="icon"></i>
            打赏主播
          </span>
        </span>
      </span>
      <!-- 点赞 -->
      <span class="like" @click.stop="openTools('like')" v-show="getConfig && getConfig.global.switch.like.enable==1&&!onSend &&!getToolsEmoji && !isVod">
        <span>{{count|renderLike}}</span>
        <!-- 点赞动画 -->
        <div class="like_warp" id="ht_like_canvas" v-show="likeShow" @click.stop=""></div>
      </span>
    </div>
  </div>
  <!-- 表情包 -->
  <div class="emoji" :class="{edit:getToolsEmoji}">
    <ul v-if="getToolsEmoji||EmojiLoaded">
      <li v-for="(value, key,index) in emojiPack" :key="index" @click.stop="emoji(key)">
        <img :src="value" alt="正在加载..." :title="key" />
      </li>
    </ul>
  </div>
  <!-- 更多功能 -->
  <more-view></more-view>
</div>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
import flutterheart from "../assets/js/flutter-hearts-zmt";
import SDKEMIT from "@/assets/js/sdk.emit";
import jQuery from "jquery";
import * as tools from "@/assets/js/util";
import * as TYPES from "@/assets/action-types";
import fixOverflowScroll from "fix-overflow-scroll";
import BScroll from "better-scroll";
import IScroll from "iscroll";
import MoreView from "./MoreView"
export default {
  // name: "ChatView",
  components: {
    MoreView
  },
  data() {
    return {
      emojiPack: {
        "[微笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon1.png",
        "[调皮]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon2.png",
        "[害羞]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon3.png",
        "[奸笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon4.png",
        "[憨笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon5.png",
        "[尴尬]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon6.png",
        "[鼓掌]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon7.png",
        "[惊讶]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon8.png",
        "[闭嘴]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon9.png",
        "[呲牙]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon10.png",
        "[大哭]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon11.png",
        "[大笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon12.png",
        "[得意]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon13.png",
        "[囧]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon14.png",
        "[难过]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon15.png",
        "[敲打]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon16.png",
        "[色]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon17.png",
        "[委屈]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon18.png",
        "[疑问]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon19.png",
        "[郁闷]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon20.png",
        "[再见]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon21.png",
        "[可怜]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon22.png",
        "[捂脸]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon23.png",
        "[笑哭]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon24.png",
        "[安慰]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon25.png"
      },
      EmojiLoaded:false,
      isWx: true,
      msg: "",
      chatMsg: "",
      onSend: false,
      isVod: window.isVod && window.isVod == 1 ? true : false,
      checkTimer: null,
      networkTip: false,
      productPop: false,
      productPopTimer: null,
      count: 0,
      clickTime: 0,
      clickNext: null,
      isLikeLoard: false,
      YiQianBao: window.YiQianBao || false,
      BubbleHearts: null,
      images: null,
      likeShow: false,
      cmsNum: 0
    };
  },
  filters: {
    // todo...
    getTime(_time) {
      return tools.convertTimestamp(_time);
    },
    // render
    renderImg(msg) {
      // console.warn(msg)
      msg = '<img src="' + msg.replace(/\[(.+?)\]/g, "") + '" />';
      return msg;
    },
    // emoji
    renderEmoji(msg) {
      // msg = msg.replace(/\[*.\]/, '')
      return msg;
    },
    //
    renderLike(num) {
      if (num > 9999 && num <= 9999999) {
        // num = `${parseInt(num / 10000)}${parseInt((num % 10000) / 1000)>=0?'.'+parseInt((num % 10000) / 1000):''}${parseInt((num % 1000) / 100) >= 0 ? parseInt((num % 1000) / 100):''}w`
        num = (num / 10000).toFixed(2) + 'w'
      } else if (num > 9999999) {
        num = '9999w+'
      }
      return num;
    }
  },
  computed: {
    ...mapGetters([
      "getChatList",
      "getHtData",
      "getSideMode",
      "getRewardTimer",
      "getFlagReward",
      "getRewardCurhid",
      "getModeSwitch",
      "getintoRoom",
      "getLiveState",
      "getConfig",
      "getLiveLine",
      "getUser",
      "getActModule",
      "getpvUserlist",
      "getCurTip",
      "getQuesTip",
      "getToolsRedpackPop",
      "getPageModel",
      "getToolsEmoji",
      "getProductAddList",
      "getProductIdList",
      "getLikeCount",
      "getMemberTotal",
      "getLikeIntervalTime",
      "getToolsClaer"
    ]),
    course_id() {
      if (this.getHtData.course && this.getHtData.course.course_id) {
        return this.getHtData.course.course_id;
      }
      if (this.getHtData.id) {
        return this.getHtData.id
      }
      return 0
    },
    chatList() {
      if (this.getChatList.length > 0) {
        // console.error(this.getChatList)
        let result = this.getChatList.map(item => {
          if (item.type === "notify_reward") {
            item.reward = this.notifyRewardHander(item);
            return item;
          }
          if (item.msg && item.msg.indexOf("[IMG]") > -1) {
            item.image = item.msg
              .replace(/\[(.+?)\]/g, "")
              .replace(/_s\.jpg/, ".jpg");
            //  .replace(/_s\.jpg/, '.jpg')
          }
          return item;
        });
        return result;
      } else {
        return []
      }
    },
    liveid() {
      if (this.getHtData.live) {
        return this.getHtData.live.liveid;
      } else {
        return 0;
      }
    },
    pid() {
      if (this.isVod) {
        if (this.getHtData && this.getHtData.pid) {
          return this.getHtData.pid
        }
      } else {
        if (this.getHtData && this.getHtData.zhubo && this.getHtData.zhubo.partner_id) {
          return this.getHtData.zhubo.partner_id
        }
      }
      return 0
    },
    pulldownShwo() {
      let more = this.getConfig && this.getConfig.global.switch.more.data || {}
      if (this.isWx) {
        return (more.info == 0 && more.liveLine == 0 && more.redPackRecord == 0 && more.withdraw == 0 && (more.store && more.store.enable == 0) && more.report == 0) ? false : true
      } else {
        return (more.liveLine == 0 && (more.store && more.store.enable == 0) && more.report == 0) ? false : true
      }
    },
    PvChatTip() {
      let tip = 0
      if (this.getpvUserlist.length > 0) {
        this.getpvUserlist.forEach(user => {
          if (user.tip != 0) {
            tip += 1
          }
        })
      }
      return tip || Number(this.getCurTip)
    },
    ProductTotal() {
      let arr = 0
      this.getProductIdList.forEach((product) => {
        if (product.putaway != 0) {
          arr += 1
        }
      })
      return arr
    },
    styleRed() {
      let pids = window.annual_config_pid || []
      return pids.some((pid) => {
        return pid == this.pid
      }) && this.getPageModel == 0
    }
  },
  methods: {
    ...mapActions({
      fireChat: "CHAT_UPDATE_LIST",
      postLike: "POST_LIKE"
    }),
    lazyTime() {
      if (this.getMemberTotal < 100) {
        return 1
      } else if (this.getMemberTotal < 1000) {
        return 3
      } else if (this.getMemberTotal < 3000) {
        return 5
      } else if (this.getMemberTotal < 5000) {
        return 7
      } else if (this.getMemberTotal < 8000) {
        return 10
      } else if (this.getMemberTotal < 10000) {
        return 15
      } else if (this.getMemberTotal < 15000) {
        return 20
      } else if (this.getMemberTotal < 20000) {
        return 30
      }
      // 点赞延迟 在线人数小于100影响为0 刷新时间大于60秒影响为0  最高延迟发送120秒 在线人数权重0.6(影响最大值78) 刷新时间权重0.4(最大影响值42)
      // let time = this.getLikeIntervalTime > 60 ? 0 : this.getLikeIntervalTime //间隔时间  单位 1/秒
      // let online = this.getMemberTotal < 100 ? 0 : number(this.getMemberTotal / 100) //在线人数 单位 100/人
      // let rate_t = .7 //刷新时间变化速率 
      // let rate_o = online > 10 ? .78 : .39 //在线人数变化速率，0~1000人 .39 / 1000人~max .78 在10000人达到峰值78
      // 当两种影响为0，延迟1秒
      // if (!time && !online) {
      //   return 1
      // }
      // 刷新时间小于1秒且在线人数超过100，延迟时间达到最大 （极端值）
      // if (time > 0 && time <= 1 && online > 100) {
      //   return 120
      // }
      // 当其中一个影响为0时，最高延迟发送60秒，变化速率较慢
      // if (!time || !online) {
      //   // 刷新时间影响为0
      //   if (!time) {
      //     rate_o = online > 10 ? .6 : .3
      //     return online * rate_o >= 60 ? 60 : online * rate_o
      //   }
      //   // 在线人数影响为0
      //   if (!online) {
      //     rate_t = 5/60
      //     return (5 - (time * rate_t) >= 5 ? 5 : 5 - (time * rate_t))
      //   }
      // }
      // let lazy = (42 - (time * rate_t) >= 42 ? 42 : 42 - (time * rate_t)) + (online * rate_o >= 78 ? 78 : online * rate_o)
      // return lazy >= 120 ? 120 : lazy
    },
    openTools(type) {
      if (this.productPopTimer) {
        clearTimeout(this.productPopTimer)
        this.productPopTimer = null
      }
      this.productPop = false
      if (type === 'product') {
        let type = this.getConfig ? this.getConfig.global.switch.store.type : 0;
        let url = this.getConfig ? this.getConfig.global.switch.store.data.url : '';
        if (type == 1) {
          this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
            type: 'product',
            flag: true
          });
        } else if (type == 2) {
          window.location.href = url;
        } else if (type == 3) {
          this.$store.commit(TYPES.UPDATE_SIDE_MODE, 7);
        }
        this.cmsNum = this.cmsNum + 1
      }
      if (type === 'like') {
        this.like()
        // this.$store.commit(TYPES.UPDATE_SIDE_MODE, 3);
        // let tiemr = setInterval(() => {
        //   let count = this.getLikeCount + 1
        //   this.$store.commit(TYPES.UPDATA_LIKE, count);
        // },1000);
        this.clickTime += 1
        this.count += 1
      }
      if (type === 'redpack') {
        this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
          type: 'redpackPop',
          flag: !this.getToolsRedpackPop
        });
      }
      if (type === 'line') {
        this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
          type: 'line',
          flag: true
        });
      }
      if (type === 'more') {
        this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
          type: 'more',
          flag: true
        });
      }
      if (type === 'menu') {
        this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
          type: 'menu',
          flag: true
        });
      }
    },
    replay() {
      this.HTSDK.reload()
    },
    config(type) {
      let flag = false;
      if (this.getConfig) {
        this.getConfig.content.tabsData.forEach((item) => {
          if (item.type === type) {
            flag = true
          }
        })
      }
      return flag
    },
    onChatFocus(e) {
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'inputFocus',
        flag: true
      })
      // setTimeout(() => {
      //   this.jquery(document).scrollTop(this.jquery(window).height());
      // }, 250);
      // alert("ss")
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'emoji',
        flag: false
      });
      this.onSend = true;
    },
    getIsWxClient() {
      var ua = navigator.userAgent.toLowerCase();
      if (ua.match(/MicroMessenger/i) == "micromessenger") {
        return true;
      }
      return false;
    },
    // 表情
    emoji(key) {
      this.chatMsg += key
    },
    openEmoji(event) {
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'emoji',
        flag: !this.getToolsEmoji
      });
      document.getElementById("chat_post_txt").blur();
      event.preventDefault();
    },
    // 发送聊天
    chat_send(event) {
      /**
       * 具体的发送聊天限制待处理
       */
      if (this.chatConfig()) {
        SDKEMIT.chatSend(this.HTSDK, this.chatMsg, res => {
          if (res.code !== 0) {
            this.$vux.toast.text(res.msg, "bottom");
            return false;
          }
          this.chatMsg = "";
          // 时间格式转化
          res.data.time = tools.convertTimestamp(res.data);
          this.fireChat({
            chatObject: res.data
          });
        });
      } else {
        this.$vux.toast.text(this.getLiveState === 'wait' ? '直播前不能发送聊天' : '直播结束不能发送聊天', "bottom");
      }
      document.getElementById("chat_post_txt").blur();
      this.$store.commit(TYPES.CHAT_SET_LOCK, false);
      this.onSend = false;
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'emoji',
        flag: false
      });
      event.preventDefault();
    },
    onBlur() {
      document.body.scrollTop = document.documentElement.scrollTop = 0;
      this.jquery("#app").scrollTop(0);
      if (this.chatMsg === "") {
        this.onSend = false;
      }
      if (window.parent && window.parent.postMessage) {
        window.parent.postMessage('chat:on:blur', "*");
      }
      // 失焦事件延迟，因为失焦比点击事件先触发，不延迟的话会导致清屏的状态错误getToolsClaer
      //  console.error(this.getToolsClaer)
      setTimeout(() => {
        this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
          type: 'inputFocus',
          flag: false
        })
      }, 100)
      this.networkTip = false
    },
    goshare() {
      // 打开侧边栏工具
      if (this.isWx) {
        this.$store.commit(TYPES.UPDATE_SIDE_MODE, 2);
        return
      } else {
        this.$vux.toast.text('分享失败', "bottom");
      }
    },
    redpop(type) {
      if (type === 'redpack') {
        this.$store.commit(TYPES.UPDATE_REWARD_STATUS, 1);
        this.$store.commit(TYPES.UPDATE_SIDE_MODE, 5);
      }
      if (type === 'award') {
        this.$store.commit(TYPES.UPDATE_SIDE_MODE, 4);
      }
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'redpackPop',
        flag: false
      });
    },
    // 聊天互动设置
    chatConfig() {
      let modules = this.getHtData && this.getHtData.modules
      let before_modules = {
        chat: {
          enable: (modules && modules.mod_beforeclass_live && modules.mod_beforeclass_live.config && modules.mod_beforeclass_live.config.chat && modules.mod_beforeclass_live.config.chat.enable) || 0
        },
        enable: (modules && modules.mod_beforeclass_live && modules.mod_beforeclass_live.enable) || 0
      }
      let after_modules = {
        chat: {
          enable: (modules && modules.mod_afterclass_live && modules.mod_afterclass_live.config && modules.mod_afterclass_live.config.chat && modules.mod_afterclass_live.config.chat.enable) || 0
        },
        enable: (modules && modules.mod_afterclass_live && modules.mod_afterclass_live.enable) || 0
      }
      if (this.getLiveState === 'wait' && before_modules.enable == 1) {
        return before_modules.chat.enable == 1 ? true : false
      }
      if (this.getLiveState === 'stop' && after_modules.enable == 1) {
        return after_modules.chat.enable == 1 ?
          true : false
      }
      if (this.getLiveState === 'start') {
        return true
      }
      return false
    },
    initLikeAnimation() {
      var that = this;
      flutterheart();
      // 图片资源;
      var assets = [
        "../assets/images/live-v2/1(1).svg",
        "../assets/images/live-v2/2(1).svg"
      ];
      // 加载图片;
      assets.forEach(function (src, index) {
        assets[index] = new Promise(function (resolve) {
          var img = new Image();
          img.onload = resolve.bind(null, img);
          var str = src;
          if (index == 0) {
            img.src = require("../assets/images/live-v2/1(1).svg");
          }
          if (index == 1) {
            img.src = require("../assets/images/live-v2/2(1).svg");
          }
        });
      });
      Promise.all(assets).then(function (images) {
        var obj = new BubbleHearts();
        that.BubbleHearts = obj;
        that.images = images;
        that.canvas = obj.canvas;
        that.canvas.width = 150;
        that.canvas.height = 400;
        that.canvas.style["width"] = "100%";
        that.canvas.style["height"] = "100%";
        that.canvas.id = "bubble-heart";
      });
    },
    like() {
      this.likeShow = true
      if (this.BubbleHearts && this.BubbleHearts.bubble) {
        var random = {
          uniform: function (min, max) {
            return min + (max - min) * Math.random();
          },
          uniformDiscrete: function (i, j) {
            return i + Math.floor((j - i + 1) * random.uniform(0, 1));
          }
        };
        if (!document.querySelector("#bubble-heart")) {
          document.querySelector("#ht_like_canvas").append(this.canvas);
          this.BubbleHearts.bubble(
            this.images[random.uniformDiscrete(0, this.images.length - 1)]
          );
        } else {
          this.BubbleHearts.bubble(
            this.images[random.uniformDiscrete(0, this.images.length - 1)]
          );
        }
      }
    }
  },
  watch: {
    chatMsg(nv) {
      if (this.onSend) {
        if (this.checkTimer) {
          clearTimeout(this.checkTimer)
          this.checkTimer = null
        }
        this.checkTimer = setTimeout(() => {
          if (this.chatMsg.search("卡") !== -1) {
            this.networkTip = true
          }
          this.checkTimer = null
        }, 500)
      }
      if (nv !== '') {
        this.onSend = true
      }
    },
    getProductAddList() {
      this.productPop = true
      if (this.productPopTimer) {
        clearTimeout(this.productPopTimer)
      }
      this.productPopTimer = setTimeout(() => {
        this.productPop = false
        this.productPopTimer = null
      }, 5000)
    },
    getLikeCount: {
      immediate: true,
      handler: function (nv) {
        this.count = Number(nv)
        // 以下是点赞冒泡逻辑，因为性能问题，暂不使用
        // if (nv > this.count) {
        //   let len = Number(nv) - this.count > 10 ? 10 : (Number(nv) - this.count)
        //   this.count = Number(nv)
        //   if (this.isLikeLoard) {
        //     this.count = Number(nv) - len
        //     for (let i = 1; i <= len; i++) {
        //       setTimeout(() => {
        //         this.like()
        //         this.count++
        //       }, i * 500)
        //     }
        //   }
        //   this.isLikeLoard = true
        // }
      }
    },
    clickTime(nv) {
      if (nv) {
        if (this.clickNext) {
          clearTimeout(this.clickNext)
          this.clickNext = null
        }
        this.clickNext = setTimeout(() => {
          this.postLike({
            times: this.clickTime,
            access_token: window.access_token || ''
          })
          this.clickTime = 0
          clearTimeout(this.clickNext)
          this.clickNext = null
        }, this.lazyTime() * 1000)
      }
    },
    getToolsEmoji(nv) {
      if(nv&&!this.EmojiLoaded){
        this.EmojiLoaded = true
      }
    }
  },
  mounted() {
    window._myComponent = this
    this.isWx = this.getIsWxClient()
    if(this.getConfig && this.getConfig.global.switch.like.enable==1){
      this.initLikeAnimation();
    }
  }
};
</script>

<style lang="less" scoped>
.mod_chat_post_v2 {
  // z-index: 1600;
  bottom: 0;
  width: 100%;
  max-width: 750px;
  position: fixed;
  // background: none;
  // transition: .5s;

  &.red {
    .post_con {
      background: #AF302C;
      border: none;

      #chat_post_txt {
        background: rgba(0, 0, 0, .16);

        &::placeholder {
          color: #C99492;
        }
      }

      .icon_warp {
        .csend {
          &.onsend {
            background-color: #FFCD8B;
            color: #AC0404;
          }
        }

        .share {
          background: url(~@/assets/images/styleRed/share_red.png) no-repeat;
          background-size: 100% 100%;
        }

        .pull_down_icon {
          background: url(~@/assets/images/styleRed/more_red.png) no-repeat;
          background-size: 100% 100%;
        }

        .redpack {
          background: url(~@/assets/images/styleRed/red_envelopes.png) no-repeat;
          background-size: 100% 100%;
        }

        .like {
          background: url(~@/assets/images/styleRed/fabulous_red.png) no-repeat;
          background-size: 100% 100%;
        }
      }
    }
  }

  &.full_mode {
    .post_con {
      background: none;
      box-shadow: none;
      border-top: none;
      // padding-top: 0.4rem;
      padding-bottom: 0.35rem;

      input {
        background: rgba(0, 0, 0, 0.3) !important;
        padding: 0 .2rem 0 .2rem !important;
        color: #EEF4F8;

        &::placeholder {
          color: #EEF4F8 !important;
        }
      }

      .icon_warp {
        .like {
          background: url(~@/assets/images/live-v3/like.svg) no-repeat;
          background-size: 130% 130% !important;
          background-position: center center !important;
          background-color: rgba(0, 0, 0, 0.3) !important;
          border-radius: 50%;
        }

        .redpack {
          background-color: rgba(0, 0, 0, .3);
          background-size: 110% 110% !important;
          background-position: center center !important;
          border-radius: 50%;
        }

        .share {
          background: url(~@/assets/images/live-v3/share.svg) no-repeat;
          background-size: 100% 100%;
          background-position: center center;
          background-color: rgba(0, 0, 0, 0.3) !important;
          border-radius: 50%;
        }

        .pull_down_icon {
          background: url(~@/assets/images/live-v3/more.svg) no-repeat;
          background-size: 100% 100%;
          background-position: center center;
          background-color: rgba(0, 0, 0, 0.3) !important;
          border-radius: 50%;
        }
      }
    }
  }

  &.pull_post {
    background-color: #ffffff;

    .post_con {
      padding-bottom: 7.5px;
    }

    .mod_chat_ipt {
      input {
        background: #F4F6F8 !important;
        padding: 0 .8rem 0 .2rem !important;
        color: #4D5358;

        &::placeholder {
          color: #A3A9AE !important;
        }
      }
    }
  }

  .network_tip {
    height: 2.4rem/2;
    background: #F6F8F9;
    font-size: 16px;
    color: #3F5465;
    padding: 0 .6rem/2;
    display: flex;
    justify-content: space-between;
    align-items: center;

    .try_btn {
      padding: .24rem/2 .65rem/2;
      border-radius: .7rem/2;
      background: #FFFFFF;
      border: 1px solid #B2BDC4;
      color: #3B96B4;
    }
  }

  .post_con {
    background-color: #ffffff;
    padding: .3rem .3rem .4rem;
    display: flex;
    align-items: center;
    // box-shadow: 0px -1px 0px rgba(0, 0, 0, 0.05);
    border-top: 1px solid #EBEFF2;

    .mod_chat_ipt {
      position: relative;
      height: 1.4rem/2;
      color: black;
      font-size: 14px;
      flex: 1;
      outline: none;
      position: relative;
      line-height: 1.4rem/2;
      text-align: center;
      // min-width: 40px;

      &.no_chat {
        color: #c6cdd2;
        text-align: left;
        text-indent: 1em;
      }

      &.vod {
        background: none;
      }

      .emoji_btn {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        right: 0.2rem;
        width: .92rem/2;
        height: .92rem/2;
        display: inline-block;
        background: url(~@/assets/images/live-v2/emoticon@2x.png) no-repeat;
        background-size: 100% 100%;

        &.send {
          background: url(~@/assets/images/live-v2/word@2x.png) no-repeat;
          background-size: 100% 100%;
        }
      }

      input {
        width: 100%;
        height: 100%;
        background-color: #F4F6F8;
        outline: none;
        border: none;
        border-radius: 0.6rem;
        padding: 0 .8rem 0 .2rem;
        // border: 1px solid #EEEEEE;
        font-size: 14px;
        text-overflow: ellipsis;
        overflow: hidden;
        box-sizing: border-box;
      }

      input::placeholder {
        color: #A3A9AE;
      }
    }

    .product {
      width: 1.4rem/2;
      height: 1.4rem/2;
      background: url(~@/assets/images/live-v3/product.svg) no-repeat;
      background-size: 100% 100%;
      display: block;
      position: relative;
      flex: none;
      margin-right: 0.2rem;
      max-width: 10%;

      &.animation {
        animation: icon-bounce 0.5s infinite;
      }

      &>span {
        position: absolute;
        font-size: 16px;
        color: #fff;
        top: 70%;
        left: 50%;
        transform: translate(-50%, -50%);
      }

      @keyframes icon-bounce {

        0%,
        100% {
          -moz-transform: rotate(0deg);
          -ms-transform: rotate(0deg);
          -webkit-transform: rotate(0deg);
          transform: rotate(0deg);
        }

        25% {
          -moz-transform: rotate(15deg);
          -ms-transform: rotate(15deg);
          -webkit-transform: rotate(15deg);
          transform: rotate(15deg);
        }

        50% {
          -moz-transform: rotate(-15deg);
          -ms-transform: rotate(-15deg);
          -webkit-transform: rotate(-15deg);
          transform: rotate(-15deg);
        }

        75% {
          -moz-transform: rotate(5deg);
          -ms-transform: rotate(5deg);
          -webkit-transform: rotate(5deg);
          transform: rotate(5deg);
        }

        85% {
          -moz-transform: rotate(-5deg);
          -ms-transform: rotate(-5deg);
          -webkit-transform: rotate(-5deg);
          transform: rotate(-5deg);
        }
      }
    }

    .private_chat_icon {
      width: 1.4rem/2;
      height: 1.4rem/2;
      background: url(~@/assets/images/live-v2/private_chat_icon.png) no-repeat;
      background-size: 100%;
      display: block;
      position: relative;
      flex: none;

      .private_chat_tip {
        position: absolute;
        top: 0;
        right: 0;
        width: 0.36rem/2;
        height: 0.36rem/2;
        background: rgba(255, 71, 71, 1);
        // border: 2px solid rgba(246, 248, 249, 1);
        border-radius: 50%;
      }
    }

    .icon_warp {
      flex: none;
      display: flex;
      z-index: 0;

      &>span {
        // max-width: 15%;
        flex: 1 !important;
      }

      max-width: 70%;

      .csend {
        width: 1rem;
        // height: 0.6rem;
        // line-height: 0.6rem;
        text-align: center;
        border-radius: 0.36rem;
        background-color: #C5D0D6;
        color: #fff;
        font-size: 16px;
        display: block;
        margin-left: 0.2rem;
        padding: 0.1rem 0;
        flex: none;

        &.onsend {
          background-color: #01C2FF;
        }
      }

      .redpack {
        flex: none;
        width: .7rem;
        height: .7rem;
        background: url(~@/assets/images/live-v3/redpack.svg) no-repeat;
        background-size: 110% 110%;
        background-position: center -1px;
        display: block;
        // margin-right: 0.16rem;
        margin-left: .2rem;
        position: relative;
        z-index: 1;

        .open_wp {
          display: inline-flex;
          position: absolute;
          // width:6.44rem/2;
          height: 3.68rem/2;
          background: rgba(255, 255, 255, 1);
          box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.16);
          top: -.1rem;
          left: 20%;
          font-size: 14px;
          transform: translate(-50%, -100%);
          justify-content: center;
          align-items: center;
          padding: 0 .6rem/2;
          border-radius: .2rem;

          &>span:nth-last-of-type(1) {
            margin: 0;
          }

          .icon {
            width: 1.4rem/2;
            height: 1.4rem/2;
            border-radius: 50%;
          }

          .redpack_bg {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            margin-right: .8rem/2;
            white-space: nowrap;

            .icon {
              margin-bottom: .2rem/2;
              background: url(~@/assets/images/live-v2/reward_icon.png) no-repeat;
              background-size: 100% 100%;
            }
          }

          .reward_bg {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            white-space: nowrap;

            .icon {
              margin-bottom: .2rem/2;
              background: url(~@/assets/images/live-v2/award.svg) no-repeat;
              background-size: 100% 100%;
            }
          }

          &::before {
            content: "";
            display: block;
            position: absolute;
            width: 0;
            height: 0;
            border: 6px solid transparent;
            border-top-color: #ffffff;
            bottom: 0;
            left: 56%;
            transform: translate(-50%, 100%);
            z-index: 2;
          }

          &::after {
            content: "";
            display: block;
            position: absolute;
            width: 0;
            height: 0;
            border: 8px solid transparent;
            border-top-color: rgba(0, 0, 0, 0.05);
            bottom: 0;
            left: 50%;
            transform: translate(-50%, 100%);
          }
        }
      }

      .like {
        flex: none;
        width: .7rem;
        height: .7rem;
        background: url(~@/assets/images/live-v3/like.png) no-repeat;
        background-size: 120% 120%;
        background-position: center center;
        display: block;
        // margin-left: 0.16rem;
        margin-left: .2rem;
        position: relative;

        &>span {
          padding: 2px 6px;
          position: absolute;
          font-size: 14px;
          background: #FF5362;
          border-radius: .18rem;
          color: #fff;
          top: 6px;
          left: 50%;
          transform: translate(-50%, -100%);
        }
      }

      .tab {
        flex: none;
        width: .7rem;
        height: .7rem;
        background: url(~@/assets/images/live-v3/tab_full.png) no-repeat;
        background-size: 100% 100%;
        background-position: center center;
        display: block;
        border-radius: 50%;
        overflow: hidden;
        // margin-right: 0.16rem;
        margin-left: .2rem;
      }

      .share {
        flex: none;
        width: .7rem;
        height: .7rem;
        background: url(~@/assets/images/live-v3/share.png) no-repeat;
        background-size: 100% 100%;
        background-position: center center;
        display: block;
        border-radius: 50%;
        overflow: hidden;
        // margin-right: 0.16rem;
        margin-left: .2rem;
      }

      .pull_down_icon {
        flex: none;
        width: .7rem;
        height: .7rem;
        display: inline-block;
        background: url(~@/assets/images/live-v3/more.png) no-repeat;
        background-size: 100% 100%;
        background-position: center center;
        font-size: 12px;
        border-radius: 50%;
        // overflow: hidden;
        margin-left: .2rem;
        position: relative;

        // margin-right: .2rem;
        .private_chat_tip {
          position: absolute;
          top: 0;
          right: 0;
          width: 0.36rem/2;
          height: 0.36rem/2;
          background: rgba(255, 71, 71, 1);
          // border: 2px solid rgba(246, 248, 249, 1);
          border-radius: 50%;
        }
      }

    }

  }

  .emoji {
    height: 0px;
    transform: translateY(100%);
    background: #ffffff;
    transition: 0.5s;
    overflow: hidden;
    border-top: 1px solid #EEEEEE;

    &.edit {
      height: auto;
      transform: translateY(0);
    }

    ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
      flex-wrap: wrap;
      // justify-content: space-around;
      padding: .3rem/2;
      box-sizing: border-box;

      li {
        margin: .3rem/2;
        width: .6rem;
        height: .6rem;

        img {
          width: 100%;
          height: 100%;
          display: block;
          object-fit: fill;
        }
      }
    }
  }

  .like_warp {
    width: 2rem;
    height: 6rem;
    position: absolute;
    bottom: 1rem;
    right: -.5rem;
  }
}
</style>
