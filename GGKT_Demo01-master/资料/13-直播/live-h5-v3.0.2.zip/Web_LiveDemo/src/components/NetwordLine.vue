<template>
<transition name="fade">
  <div class="line_tab">
    <div class="tip">网络选择</div>
    <div class="line_warp">
      <div class="line_content">
        <div class="line" :class="{active:curline === index}" v-for="(item,index) in getLiveLine" :key="index" @click.stop="changeLine(item.key)">{{item.label}}</div>
      </div>
    </div>
  </div>
</transition>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
export default {
  data() {
    return {
      curline: 0,
      isVod: window.isVod && window.isVod == 1 ? true : false
    }
  },
  computed: {
    ...mapGetters([
      "getLiveLine",
      "getToolsLine"
    ]),
  },
  methods: {
    changeLine(line) {
      this.curline = line
      if (this.isVod) {
        this.HTSDK.changeSource(line, data => {
          this.$vux.toast.text('线路切换成功', "bottom");
        })
        return
      }
      this.HTSDK.setLine(line)
      setTimeout(() => {
        this.$vux.toast.text('线路切换成功', "bottom");
      }, 1000)
    },
  },
}
</script>

<style lang="less" scoped>
.line_tab {
  bottom: 0;
  position: absolute;
  height: 6.4rem/2;
  width: 100%;
  background: #F6F8F9;
  display: flex;
  flex-direction: column;
  // transform: translate(0, 100%);
  transition: .5s;

  // &.linebox {
  //   transform: translate(0, 0);
  // }

  .tip {
    height: 1rem;
    font-size: 16px;
    color: #95A0A8;
    padding-left: 15px;
    box-sizing: border-box;
    line-height: 1rem;
    border-bottom: 1px solid #EBEFF2;
  }

  .line_warp {
    flex: 1;
    font-size: 16px;
    position: relative;

    .line_content {
      position: absolute;
      display: flex;
      height: .7rem;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      border-radius: 35px;
      background: #E2F3FF;

      .line {
        width: 3.4rem/2;
        border-radius: 35px;
        text-align: center;
        line-height: .7rem;
        // background: #3DADFF;
        color: #3DADFF;

        &.active {
          background: #3DADFF;
          color: #FFFFFF;
        }
      }
    }
  }
}

.fade-enter-active,
.fade-leave-active {
  transition: 0.5s;
}

.fade-enter {
  transform: translate(0, 100%);
}

.fade-enter-to {
  transform: translate(0, 0);
}

.fade-leave {
  transform: translate(0, 0);
}

.fade-leave-to {
  transform: translate(0, 100%);
}
</style>
