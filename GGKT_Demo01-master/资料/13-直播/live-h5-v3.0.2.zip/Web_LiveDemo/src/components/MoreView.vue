<template>
<div class="pull_down" :class="{pull:getToolsMore}">
  <ul>
    <li @click.stop="openTools('info')" v-if="!(getConfig&&getConfig.global.switch.more.data.info == 0) && isWx ">
      <div class="item info_icon">
        <span></span>
      </div>
      <span>个人中心</span>
    </li>
    <li @click.stop="openTools('line')" v-if="!(getConfig&&getConfig.global.switch.more.data.liveLine == 0)">
      <div class="item line_icon">
        <span></span>
      </div>
      <span>线路切换</span>
    </li>
    <li @click.stop="getList()" v-if="!(getConfig&&getConfig.global.switch.more.data.redPackRecord == 0) && isWx && !isVod">
      <div class="item reward_icon">
        <span></span>
      </div>
      <span>红包记录</span>
    </li>
    <li @click.stop="changeRewardState(5)" v-if="!(getConfig&&getConfig.global.switch.more.data.withdraw == 0) && isWx">
      <div class="item reward_cash">
        <span></span>
      </div>
      <span>提现</span>
    </li>
    <li @click.stop="openTools('product')" v-if="getConfig&&getConfig.global.switch.more.data.store.enable == 1">
      <div class="item product_icon">
        <span></span>
      </div>
      <span>商城</span>
    </li>
    <li @click.stop="openTools('private_chat')" v-if="getConfig && getConfig.global.switch.service && getConfig.global.switch.service.enable == 1 && !isVod">
      <div class="item private_icon">
        <span></span>
        <i class="private_chat_tip" v-show="PvChatTip">{{getCurTip}}</i>
      </div>
      <span>私聊</span>
    </li>
    <li @click.stop="openTools('question')" v-if="getPageModel!=0 && !isVod && getConfig && getConfig.global.switch.question && getConfig.global.switch.question.enable == 1">
      <div class="item question_icon">
        <span></span>
        <i class="question_tip" v-show="getQuesTip">{{getQuesTip}}</i>
      </div>
      <span>提问</span>
    </li>
    <li @click.stop="openTools('report')" v-if="!(getConfig&&getConfig.global.switch.more.data.report == 0)">
      <div class="item report_icon">
        <span></span>
      </div>
      <span>举报</span>
    </li>
  </ul>
</div>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
import SDKEMIT from "@/assets/js/sdk.emit";
import * as TYPES from "@/assets/action-types";
export default {
  data() {
    return {
      isWx: true,
      isVod: window.isVod && window.isVod == 1 ? true : false,
      quesIsLoaded: false,
    };
  },
  computed: {
    ...mapGetters([
      "getConfig",
      "getpvUserlist",
      "getCurTip",
      "getHtData",
      "getToolsMore",
      "getPageModel",
      "getQuesTip"
    ]),
    liveid() {
      if (this.getHtData.live) {
        return this.getHtData.live.liveid;
      } else {
        return 0;
      }
    },
    pulldownShwo() {
      let more = this.getConfig && this.getConfig.global.switch.more.data || {}
      if (this.isWx) {
        return (more.info == 0 && more.liveLine == 0 && more.redPackRecord == 0 && more.withdraw == 0 && (more.store && more.store.enable == 0) && more.report == 0) ? false : true
      } else {
        return (more.liveLine == 0 && (more.store && more.store.enable == 0) && more.report == 0) ? false : true
      }
    },
    PvChatTip() {
      let tip = 0
      if (this.getpvUserlist.length > 0) {
        this.getpvUserlist.forEach(user => {
          if (user.tip != 0) {
            tip += tip
          }
        })
      }
      return tip || Number(this.getCurTip)
    }
  },
  methods: {
    ...mapActions({
      checkReward: "CHECK_REWARD",
      indexCashReward: "INDEX_CASH_REWARD",
      listReward: "LIST_REWARD",
      updateQuesList: "UPDATE_QUESTION_LIST",
    }),
    getIsWxClient() {
      var ua = navigator.userAgent.toLowerCase();
      if (ua.match(/MicroMessenger/i) == "micromessenger") {
        return true;
      }
      return false;
    },
    changeRewardState(val, index, reward) {
      // 我的钱包
      this.indexCashReward({
        vm: this
      });
      // this.jquery("#loading").removeClass("hidden");
      this.$vux.loading.show({
        text: 'loading'
      })
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'more',
        flag: false
      });
    },
    getList() {
      this.listReward({
        vm: this,
        data: {
          liveid: this.liveid,
          page: 1
        }
      });
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'more',
        flag: false
      });
      // this.jquery("#loading").removeClass("hidden");
      this.$vux.loading.show({
        text: 'loading'
      })
    },
    openTools(type) {
      if (type === 'product') {
        let url = this.getConfig ? this.getConfig.global.switch.more.data.store.url : '';
        window.location.href = url;
      } else if (type === 'more') {
        let url = this.getConfig ? this.getConfig.global.switch.more.data.store.url : '';
        if (url) {
          window.location.href = url;
        } else {
          // this.$emit("product", true);
        }
      } else if (type === 'line') {
        this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
          type: 'line',
          flag: true
        });
        if (this.isVod) {
          this.HTSDK.getSource(data => {
            // console.error(data)
            let arr = []
            for (let i = 0; i < data; i++) {
              // console.error(data)
              arr.push({
                key: i,
                label: "线路" + (i + 1)
              })
            }
            // console.error(arr)
            this.$store.commit(TYPES.UPDATE_LIVE_LINE, arr)
          })
        }
      } else if (type === 'info') {
        this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
          type: 'infomation',
          flag: true
        });
      } else if (type === 'report') {
        this.$store.commit(TYPES.UPDATE_SIDE_MODE, 8);
      } else if (type === 'private_chat') {
        this.$vux.loading.show({
          text: "Loading"
        });
        SDKEMIT.getOnline(this.HTSDK, {
          "page": 1,
          "size": 100
        }, list => {
          // 客服列表
          if (list.length > 0) {
            let private_chat_list = []
            list.forEach(element => {
              if (element.role === 'admin') {
                private_chat_list.push(element)
              }
            });
            this.$store.dispatch("setPvUserlist", private_chat_list)
          }
          //   打开客服私聊
          this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
            type: 'private',
            flag: true
          });
          this.$vux.loading.hide()
        })
      } else if (type === 'question') {
        if (!this.quesIsLoaded) {
          this.HTSDK.getQuestion(res => {
            this.quesIsLoaded = true;
            // console.log('[debug]:: res => ', res)
            if (res && res.count > 0) {
              // this.$store.dispatch(types)
              // console.warn(this)
              this.updateQuesList({
                type: "list",
                data: res.data
              });
            }
            this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
              type: 'question',
              flag: true
            });
            this.quesIsLoaded = true
            this.$vux.loading.hide()
          });
          this.$vux.loading.show({
            text: "Loading"
          });
        } else {
          this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
            type: 'question',
            flag: true
          });
        }
        this.$store.commit(TYPES.UPDATE_QUESTION_TIP, false)
      }
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'more',
        flag: false
      });
    },
  },
  mounted() {
    this.isWx = this.getIsWxClient()
  },
}
</script>

<style lang="less" scoped>
.pull_down {
  min-height: 2.1rem;
  width: 100%;
  position: absolute;
  bottom: 0;
  transform: translate(0, 100%);
  font-size: 14px;
  background: rgba(246, 248, 249, 1);
  // background: #ffffff;
  // box-shadow: 0px -1px 0px rgba(0, 0, 0, 0.05);
  transition: 0.5s;
  border-radius: 0.2rem 0.2rem 0px 0px;
  overflow: hidden;

  &.pull {
    transform: translate(0, 0);
  }

  ul {
    // margin: 0.4rem 0.3rem;
    margin-top: .4rem;
    padding-left: 0.3rem;
    list-style: none;

    &::after {
      content: "";
      display: block;
      clear: both;
    }

    li {
      float: left;
      margin: 0 .22rem .55rem;
      text-align: center;
      width: 2.6rem/2;
      height: 2.6rem/2;

      // background: saddlebrown;
      // &:nth-of-type(4n) {
      //   margin: 0;
      // }

      // &:nth-of-type(n+5) {
      //   margin-top: 0.55rem;
      // }

      .item {
        width: 1rem;
        height: 1rem;
        // border-radius: 50%;
        margin: 0 auto 0.1rem;
        // background: white;

        &:active {
          background: #e7ecef;
        }

        span {
          display: inline-block;
          width: 100%;
          height: 100%;
          vertical-align: -0.48rem;
        }

        &.reward_icon {
          span {
            background: url(~@/assets/images/live-v2/reward_icon.png) no-repeat;
            background-size: 100% 100%;
          }
        }

        &.reward_cash {
          span {
            background: url(~@/assets/images/live-v2/reward_cash.png) no-repeat;
            background-size: 100% 100%;
          }
        }

        &.product_icon {
          span {
            background: url(~@/assets/images/live-v2/product_icon.png) no-repeat;
            background-size: 100%;
          }
        }

        &.question_icon {
          position: relative;

          span {
            background: url(~@/assets/images/live-v3/question.png) no-repeat;
            background-size: 100%;
          }

          .question_tip {
            position: absolute;
            top: -0.1rem;
            right: 0;
            width: .6rem/2;
            height: .6rem/2;
            background: rgba(255, 71, 71, 1);
            // border:2px solid rgba(246,248,249,1);
            color: #ffffff;
            font-size: 12px;
            border-radius: 50%;
          }
        }

        &.private_icon {
          position: relative;

          span {
            background: url(~@/assets/images/live-v2/private_icon.png) no-repeat;
            background-size: 100%;
          }

          .private_chat_tip {
            position: absolute;
            top: -0.1rem;
            right: 0;
            width: .7rem/2;
            height: .7rem/2;
            background: rgba(255, 71, 71, 1);
            // border:2px solid rgba(246,248,249,1);
            color: #ffffff;
            font-size: 12px;
            line-height: .75rem/2;
            border-radius: 50%;
          }
        }

        &.line_icon {
          span {
            background: url(~@/assets/images/live-v2/line_icon.png) no-repeat;
            background-size: 100%;
          }
        }

        &.info_icon {
          span {
            background: url(~@/assets/images/live-v2/info_icon.png) no-repeat;
            background-size: 100%;
          }
        }

        &.report_icon {
          span {
            background: url(~@/assets/images/live-v2/report_icon.png) no-repeat;
            background-size: 100%;
          }
        }
      }
    }
  }

  &>div {
    color: #B2BDC4;
    text-align: center;
    position: relative;
    margin: -0.25rem 0 0.2rem;

    &::after {
      content: '';
      display: block;
      clear: both;
    }

    p {
      float: left;
      margin: 0;
      margin-left: 50%;
      transform: translate(-50%, 0);
    }
  }
}
</style>
