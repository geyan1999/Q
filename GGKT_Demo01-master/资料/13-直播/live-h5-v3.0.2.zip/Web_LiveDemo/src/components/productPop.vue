<template>
<transition name="pop">
  <div class="product_pop" v-if="show&&getConfig&&getConfig.global.switch.store.enable == 1&&total">
    <div class="tip">
      <span class="icon"></span>
      <span>主播推荐宝贝，快来抢吧！</span>
      <span class="close" @click.stop="close()"></span>
    </div>
    <div class="list">
      <div class="item" v-for="(item, index) in list" :key="index" v-if="index<=2&&item.putaway!=3" @click.stop="goLink(item)">
        <div class="image">
          <img :src="item.img" alt class="avatar" />
        </div>
        <div class="infomation">
          <div class="title">{{item.name}}</div>
          <div class="price"><span style="font-size:12px;margin-right:2px">￥</span>{{item.price}}</div>
        </div>
      </div>
    </div>
  </div>
</transition>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
export default {
  data() {
    return {
      show: false,
      time: 10,
      timer: null,
      list: []
    }
  },
  computed: {
    ...mapGetters(["getPageModel", "getConfig", "getProductIdList", "getHtData", "getProductAddList", "getCancelProductList"]),
    total() {
      let total = 0
      this.list.forEach((item) => {
        if (item.putaway != 3) {
          total += 1
        }
      })
      return total
    }
  },
  methods: {
    close() {
      this.time = 10
      clearInterval(this.timer)
      this.timer = null
      this.show = false
    },
    restart() {
      this.time = 10
      // this.list = []
      clearInterval(this.timer)
      this.timer = null
      this.start()
    },
    start() {
      this.timer = setInterval(() => {
        if (this.time == 0) {
          this.end()
          return
        }
        this.time -= 1
      }, 1000);
    },
    end() {
      this.time = 10
      // this.list = []
      clearInterval(this.timer)
      this.timer = null
      this.show = false
    },
    updata(data) {
      // 将数组插入头部
      this.list.unshift(data)
      // 处理数据
      this.list = this.deepClone(this.onlyArr(this.flatten(this.list), 'id'))
      this.show = true
    },
    // 链接差异化
    goLink(good) {
      let url = good.url || ''
      if (good.pay == 1 || good.pay == undefined) {
        if (url.match(/\[wx\]/)) {
          url = url.replace('[wx]', '')
          if (window.wx) {
            window.wx.miniProgram.navigateTo({
              url: url
            })
          }
          return false
        } else {
          window.location.href = url
        }
      }
    },
    // 展开数组
    flatten(arr) {
      let result = [];
      for (let i = 0; i < arr.length; i++) {
        if (Array.isArray(arr[i])) {
          result = result.concat(this.flatten(arr[i]));
        } else {
          result.push(arr[i]);
        }
      }
      return result;
    },
    // 数组去重
    onlyArr(arr, key) {
      var result = [];
      var obj = {};
      for (var i = 0; i < arr.length; i++) {
        if (!obj[arr[i][key]]) {
          result.push(arr[i]);
          obj[arr[i][key]] = true;
        }
      }
      return result
    },
    deepClone(obj) {
      var _obj = JSON.stringify(obj),
        objClone = JSON.parse(_obj);
      return objClone;
    },
    init(data) {
      if (data.length) {
        data.forEach(product => {
          if (product.putaway == 2) {
            this.list.push(product)
          }
        });
      }
    }
  },
  watch: {
    getProductAddList(nv) {
      // console.error("弹出",nv)
      if (!this.timer) {
        this.start()
      } else {
        this.restart()
      }
      this.updata(nv)
    },
    getCancelProductList(nv) {
      // console.error("消失",nv)
      if (this.list.length && nv.length) {
        nv.forEach((cancel) => {
          this.list.forEach((product) => {
            if (product.id == cancel.id) {
              product.putaway = 3
            }
          })
        })
      }
      // 强制刷新,重新计算total
      this.$forceUpdate()
    },
    total(nv) {
      // console.error("total",nv)
    }
  },
  created() {
    this.init(this.getConfig.goods)
    if (this.list.length) {
      this.show = true
      this.start()
    }
  },
}
</script>

<style lang="less" scoped>
.product_pop {
  width: 10.48rem/2;
  position: absolute;
  background: #ffffff;
  left: 0;
  bottom: .2rem;
  z-index: 100;
  transition: .5s;
  border-radius: 0px 6px 6px 0px;
  overflow: hidden;

  &.half {
    box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.16);
    bottom: 1.6rem;
  }

  .tip {
    font-size: 12px;
    display: flex;
    justify-content: space-around;
    align-items: center;
    padding: 5px;
    box-sizing: border-box;
    border-bottom: 1px solid #EBEFF2;

    .icon {
      display: inline-block;
      width: .64rem/2;
      height: .64rem/2;
      background: url(~@/assets/images/live-v2/product.svg) no-repeat;
      background-size: 100% 100%;
    }

    .close {
      display: inline-block;
      width: .72rem/2;
      height: .72rem/2;
      background: url(~@/assets/images/live-v2/close.png) no-repeat;
      background-size: 100% 100%;
    }
  }

  .list {
    width: 100%;
  }

  .item {
    width: 100%;
    // height: 3.16rem/2;
    padding: .4rem/2;
    box-sizing: border-box;
    display: flex;

    .image {
      width: 2.44rem/2;
      height: 2.44rem/2;
      flex: none;

      img {
        width: 100%;
        height: 100%;
        object-fit: fill;
      }
    }

    .infomation {
      flex: 1;
      position: relative;
      margin-left: .3rem/2;
      overflow: hidden;

      .name {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }

      .title {
        width: 100%;
        font-size: 16px;
        height: 3em;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }

      .price {
        position: absolute;
        bottom: 4px;
        font-size: 16px;
        color: #FF3737;

      }
    }
  }
}

.pop-enter-active,
.pop-leave-active {
  transition: 0.5s;
}

.pop-enter {
  height: 0;
  opacity: 0;
  transform: translateY(100%);
}

.pop-enter-to {
  // height: auto;
  opacity: 1;
  transform: translateY(0);
}

.pop-leave {
  opacity: 1;
}

.pop-leave-to {
  opacity: 0;
  transform: translateY(100%);
}
</style>
