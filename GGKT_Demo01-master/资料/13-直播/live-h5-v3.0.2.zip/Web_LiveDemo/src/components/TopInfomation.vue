<template>
<div class="top_infomation" :class="{coures_mod:getPageModel==2}">
  <div class="zhubo_infomation">
    <div class="lfet_content">
      <img :src="getAnchorimg" alt />
    </div>
    <div class="right_content">
      <div class="_infomation">
        <p class="zhibo_title">{{getHtData.zhubo.nickname}}</p>
        <online-total class="zhibo_total"></online-total>
      </div>
      <div class="_focus" @click.stop="focus()" v-if="getConfig && getConfig.global.switch.focus.enable == 1">关注</div>
    </div>
  </div>
  <div class="rank_top_show" @click.stop="dotab()" v-if="getConfig && getConfig.global.switch.invitationList.enable == 1">
    <span class="_icon"></span>
    邀请榜单
    <span class="_icon"></span>
  </div>
</div>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
import OnlineTotal from "@/components/OnlineTotal"
import * as TYPES from "@/assets/action-types";
export default {
  data() {
    return {
      UpRankFlag: true,
      isVod: window.isVod || 0,
    };
  },
  components: {
    OnlineTotal
  },
  computed: {
    ...mapGetters([
      "getPageModel",
      "getMemberTotal",
      "getRobotTotal",
      "getHtData",
      "getLiveState",
      "getScreenStatus",
      "liveCurMode",
      "getRewardState",
      "getVideoCurMode",
      "getLottery",
      "getVideoStatus",
      "getPPTModel",
      "getAnchorimg",
      "getCouresName",
      "getConfig",
      "getToolsProduct"
    ]),
    getTotal() {
      return parseInt(this.getMemberTotal) + parseInt(this.getRobotTotal)
    }
  },
  methods: {
    ...mapActions({
      updateRankList: "GET_RANK_LIST"
    }),
    focus() {
      this.$store.commit(TYPES.UPDATE_SIDE_MODE, 1);
    },
    dotab() {
      if (!this.rankUp) {
        this.updateRankList({
          vm: this,
          data: {
            access_token: window.access_token ||
              "ITN4Q2N5YjZmljY3gDMxMmZ0UTOxkjNmJzNxczYmhjZ8xHf9JSNxgjMyMzX4YDNxIDOiojIl1WYuJnIsEjOiEmIsAjOiQWanJCL1EDOyIzM6ICZp9VZzJXdvNmIsIiI6IichRXY2FmIsAjOiIXZk5WZnJCLzgTO1ITNzYTNxojIlJXawhXZiwyM4MDNwUzM2UTM6ISZtlGdnVmciwSXbpjIyRHdhJCLiIXZzVnI6ISZs9mciwCM5UDMyUzM3ojIklGeiwiIadkTPhURFxkI6ISZtFmbrNWauJCLwojIklmYiwiIxAjN2czXkJXaoRnI6ICZpVnIsgjN0EjM4ojIklWbv9mciwiNwMTMxojIklGciwiNwMTMxojIkl2XyVmb0JXYwJye",
            page: 1,
            rank: "rank"
          }
        });
        this.$vux.loading.show({
          text: "Loading"
        });
      }
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'rank',
        flag: true
      })
      // this.$emit("Tab", "rank");
    }
  },
  mounted() {
  },
};
</script>

<style lang="less" scoped>
.top_infomation {
  position: absolute;
  z-index: 110;
  top: 0.4rem/2;
  left: 0.4rem/2;

  &.coures_mod {
    transform: scale(.85);
    left: 0;

    .zhubo_infomation {
      .lfet_content {
        width: 0.2rem;
        height: 0.2rem;
        background: none;

        img {
          display: none;
        }
      }
    }

  }

  .zhubo_infomation {
    height: 1.6rem/2;
    background: rgba(0, 0, 0, 0.3);
    border-radius: 1rem/2;
    display: flex;
    align-items: center;
    padding: 5px/2 8px 5px/2 7px/2;

    .lfet_content {
      flex: none;
      width: 1.4rem/2;
      height: 1.4rem/2;
      border-radius: 50%;
      overflow: hidden;
      background: sandybrown;
      margin-right: 7px;

      img {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
    }

    .right_content {
      flex: 1;
      display: flex;
      align-items: center;

      ._infomation {
        max-width: 4rem/2;
        color: #ffffff;
        margin-right: 7px;

        .zhibo_title {
          font-size: 24px/2;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          line-height: 1.5em;
          margin: 0;
        }

        .zhibo_total {
          margin: 0;
          font-size: 20px/2;
        }
      }

      ._focus {
        flex: none;
        width: 1.6rem/2;
        height: 1.12rem/2;
        background: linear-gradient(180deg,
            rgba(255, 172, 77, 1) 0%,
            rgba(255, 114, 78, 1) 100%);
        border-radius: 0.56rem/2;
        font-size: 13px;
        line-height: 1.22rem/2;
        text-align: center;
        color: #ffffff;
      }
    }
  }

  .rank_top_show {
    width: 3.8rem/2;
    height: 0.92rem/2;
    background: rgba(0, 0, 0, 0.3);
    border-radius: 0.46rem/2;
    font-size: 12px;
    color: #ffffff;
    line-height: 0.92rem/2;
    text-align: center;

    ._icon {
      display: inline-block;
      width: 0.6rem/2;
      height: 0.6rem/2;
      vertical-align: -4px;

      &:nth-of-type(1) {
        background: url(../assets/images/live-v2/rank.svg) no-repeat;
        background-size: 90% 90%;
      }

      &:nth-of-type(2) {
        background: url(../assets/images/live-v2/arrows.svg) no-repeat;
        background-size: 100% 90%;
        width: 0.5rem/2;
        height: 0.5rem/2;
        vertical-align: -2px;
      }
    }
  }
}
</style>
