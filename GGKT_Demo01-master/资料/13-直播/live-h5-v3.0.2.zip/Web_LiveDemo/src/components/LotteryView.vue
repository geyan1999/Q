<template>
<div class="lottery_warp" @click.stop="">
  <div class="lottery new_start" v-if="getLottery.staus == 0 || getLottery.staus == 1">
    <div class="wheel_warp">
      <div class="wheel" :style="[rotate,stop]"></div>
      <div class="pointer"></div>
      <div class="btn_close" @click.stop="close()"></div>
    </div>
  </div>
  <div class="lottery" :class="{
    winner: isGetLottery,
    lose: !isGetLottery,
    }" v-show="getLottery.staus == 2&&!showList">
    <div class="lottery_content">
      <div class="inner_warp"></div>
      <div class="left_top_angle angle"></div>
      <div class="close_angle angle" @click.stop="close()"></div>
      <div class="left_bottom_angle angle"></div>
      <div class="right_bottom_angle angle"></div>
      <div class="reword_detail">
        <div class="tips_title">
          <div>{{isGetLottery?'恭喜你中奖啦':'很遗憾没中奖'}}</div>
          <div>{{isGetLottery?'请在直播结束后与工作人员联系哦':'积攒运气下次再战'}}</div>
        </div>
        <div class="reword_name" v-if="getLottery.data.prize_name">{{getLottery.data.prize_name}}</div>
      </div>
      <div class="view_reword_list" @click.stop="viewList" v-if="getLottery.data.result&&getLottery.data.pub">查看中奖名单 <span class="view_go"></span></div>
    </div>
  </div>
  <div class="lottery_list" v-if="showList">
    <div class="content">
      <div class="inner_warp"></div>
      <div class="close_angle angle" @click.stop="close()"></div>
      <div class="list_warp">
        <div class="item" v-for="(item,index) in getLottery.data.result" :key="index">
          <div class="index">{{index+1}}</div>
          <div class="name">{{item.nickname}}({{item.xid}})</div>
        </div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
import * as TYPES from "@/assets/action-types";
export default {
  data() {
    return {
      position1: 0,
      time1: 1,
      position2: 0,
      time2: 1,
      position3: 0,
      time3: 1,
      speed: 10,
      deg: 0,
      degTimer: null,
      timer: [],
      showList: false,
      stop: {},
      animationSatus: 'start'
    }
  },
  computed: {
    ...mapGetters(["getLottery", "getHtData", "getLotteryStaus"]),
    isGetLottery() {
      var arr = this.getLottery.data.result || []
      //   console.log(this.getLottery.data.result)
      if (arr.length > 0) {
        //   console.log(arr)
        for (let i = 0; i < arr.length; i++) {
          if (arr[i].xid == this.getHtData.user.xid) return true
        }
      }
      return false
    },
    rotate() {
      return {
        transform: `rotate(${this.deg}deg) translateZ(0)`
      }
    }
  },
  watch: {
    getLotteryStaus: {
      handler: function (nv, ov) {
        // console.error(nv, ov)
        // 开始抽奖
        if (nv == 0) {
          if (ov !== -1 && ov !== undefined) {
            this.$store.commit(TYPES.UPDATE_LOTTERY_STATUS, {
              staus: -1,
              data: Object.assign({}, this.getLottery.data)
            })
            setTimeout(() => {
              this.$store.commit(TYPES.UPDATE_LOTTERY_STATUS, {
                staus: 0,
                data: Object.assign({}, this.getLottery.data)
              })
            })
            return
          }
          this.startAnimation()
        }
        // 结束抽奖
        if (nv == 1) {
          if (!this.getLottery.isStart) {
            this.startAnimation()
            setTimeout(() => {
              this.overAnimation()
            }, 2000)
          } else {
            this.overAnimation()
          }
        }
      },
      immediate: true
    }
  },
  methods: {
    close() {
      this.showList = false
      this.$store.commit(TYPES.UPDATE_LOTTERY_STATUS, {
        staus: -1,
        data: Object.assign({}, this.getLottery.data)
      })
      this.$store.commit('updataAnimaton', false)
      // this.overAnimation()
    },
    viewList() {
      this.showList = true
    },
    startAnimation() {
      // this.animationSatus = 'start'
      this.$store.commit('updataAnimaton', true)
      var that = this
      var lastTime = 0;
      var vendors = ['webkit', 'moz'];
      for (var x = 0; x < vendors.length && !window.requestAnimationFrame; ++x) {
        window.requestAnimationFrame = window[vendors[x] + 'RequestAnimationFrame'];
        window.cancelAnimationFrame = window[vendors[x] + 'CancelAnimationFrame'] || // Webkit中此取消方法的名字变了
          window[vendors[x] + 'CancelRequestAnimationFrame'];
      }

      if (!window.requestAnimationFrame) {
        window.requestAnimationFrame = function (callback, element) {
          var currTime = new Date().getTime();
          var timeToCall = Math.max(0, 16.7 - (currTime - lastTime));
          var id = window.setTimeout(function () {
            callback(currTime + timeToCall);
          }, timeToCall);
          lastTime = currTime + timeToCall;
          return id;
        };
      }
      if (!window.cancelAnimationFrame) {
        window.cancelAnimationFrame = function (id) {
          clearTimeout(id);
        };
      }
      var loop = function () {
        if (that.deg == 360) {
          that.deg = 0
        }
        that.deg += 6
        if (!that.getLottery.isStart) {
          // console.error(that.getLottery.isStart)
          return
        }
        that.$forceUpdate()
        requestAnimationFrame(loop)
      }
      loop()
    },
    overAnimation() {
      // this.animationSatus = 'stop'
      this.$store.commit('updataAnimaton', false)
      let deg = 360
      let time = 1.5
      if (this.deg >= 300) {
        deg = 360 + (360 - this.deg) + this.deg
      } else if (this.deg >= 240 && this.deg < 300) {
        deg = 360 + 120
      } else {
        time = time * (360 - this.deg) / 360
      }
      this.isGetLottery ? deg : deg = deg + 60
      // console.error(this.deg, deg, time, this.isGetLottery, this.getLottery)
      this.stop = {
        transform: 'rotate(' + deg + 'deg) translateZ(0)',
        transition: time + 's ease-out'
      }
      setTimeout(() => {
        this.$store.commit(TYPES.UPDATE_LOTTERY_STATUS, {
          staus: 2,
          data: Object.assign({}, this.getLottery.data)
        })
      }, time * 1000 + 300);
    }
  },
  mounted() {}
}
</script>

<style lang="less" scoped>
.lottery_warp {
  width: 100vw;
  height: 100vh;
  background: rgba(0, 0, 0, .8);
  position: absolute;
  top: 0;
  z-index: 1900;

  .lottery {
    top: 50%;
    left: 50%;
    position: absolute;
    transform: translate(-50%, -50%);

    &.start {
      width: 6.18rem;
      height: 3.9rem;
      border-radius: 10px;
      background: url(../assets/images/lottery/start.png) no-repeat;
      background-size: 100%;
      font-size: 18px;
      font-weight: bold;
      color: rgba(255, 255, 255, 1);
      padding: 0 .4rem;
      box-sizing: border-box;

      .lottery_top {
        height: .6rem;
        border-bottom: 1px solid white;

        span {
          display: inline-block;
          text-align: center;
          background: linear-gradient(121deg, #428bfe, #327ffa);
          width: 2rem;
          height: .6rem;
          line-height: .6rem;
          position: absolute;
          top: 0.3rem;
          left: 50%;
          margin-left: -1rem;
        }
      }

      .lottery_loading {
        width: 4.7rem;
        height: 1.96rem;
        position: absolute;
        left: 0;
        right: 0;
        margin: auto;
        bottom: .72rem;
        background: rgba(192, 216, 255, 1);
        box-shadow: 0px 0px 16px 0px rgba(50, 127, 250, 0.78);
        border-radius: 4px;
        display: flex;
        padding: 10px;
        box-sizing: border-box;

        ._loading {
          flex: 1;
          background: white url(../assets/images/lottery/loading.png);
          background-size: 100%;
          background-position-y: 0;

          &:nth-of-type(2) {
            margin: 0 5px;
          }
        }
      }
    }

    &.new_start {
      top: 50%;
      margin: 0;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 15rem/2;
      height: 28.02rem/1.5/2;
      background: url(~@/assets/images/lottery/lottery_bg.png) no-repeat;
      background-size: 100% 100%;

      .wheel_warp {
        position: absolute;
        top: .9rem;
        left: .6rem;
        width: 19.04rem/2/1.5;
        height: 19.04rem/2/1.5;
        transform-style: preserve-3d;

        .wheel {
          position: absolute;
          width: 100%;
          height: 100%;
          background: url(~@/assets/images/lottery/wheel.png) no-repeat;
          background-size: 100% 100%;
        }

        .pointer {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          width: 5.64rem/1.5/2;
          height: 7.08rem/1.5/2;
          background: url(~@/assets/images/lottery/pointer.png) no-repeat;
          background-size: 100% 100%;
        }

        .btn_close {
          width: 1.8rem/1.5/2;
          height: 1.8rem/1.5/2;
          background: url(~@/assets/images/lottery/btn_close.png) no-repeat;
          background-size: 100% 100%;
          position: absolute;
          right: 0;
          top: 0;
          transform: translate(0, -90%);
        }
      }
    }

    &.get {
      top: 1rem;
      width: 5rem;
      height: 6.8rem;

      .lottery_content {
        height: 100%;
        background: url(../assets/images/lottery/get.png) no-repeat;
        background-size: 100%;
      }

      .lottery_list {
        position: absolute;
        bottom: 35px;
        left: 0;
        right: 0;
        margin: auto;
        width: 3.7rem;
        height: 2.5rem;
        padding: 10px;
        box-sizing: border-box;
        background: rgba(255, 255, 255, 1);
        border-radius: 2px;
        font-size: 16px;
        color: rgba(38, 54, 80, 1);
        overflow: auto;
        -webkit-overflow-scrolling: touch;

        .isget {
          color: #3AC7F4;
        }
      }
    }

    &.none {
      top: 2.5rem;
      width: 5rem;
      height: 4.92rem;

      .lottery_content {
        height: 100%;
        background: url(../assets/images/lottery/none.png) no-repeat;
        background-size: 100%;
      }

      .lottery_list {
        position: absolute;
        bottom: 35px;
        left: 0;
        right: 0;
        margin: auto;
        width: 3.7rem;
        height: 2.5rem;
        padding: 10px;
        box-sizing: border-box;
        background: rgba(255, 255, 255, 1);
        border-radius: 2px;
        font-size: 16px;
        color: rgba(38, 54, 80, 1);
        overflow: auto;
        -webkit-overflow-scrolling: touch;

        .isget {
          color: #3AC7F4;
        }
      }
    }

    &.noshow_get {
      top: 4rem;
      width: 5rem;
      height: 4.92rem;

      .lottery_content {
        height: 100%;
        background: url(../assets/images/live-v3/in.png) no-repeat;
        background-size: 100%;
      }
    }

    &.noshow_none {
      top: 4rem;
      width: 5rem;
      height: 4.92rem;

      .lottery_content {
        height: 100%;
        background: url(../assets/images/live-v3/no_middle.png) no-repeat;
        background-size: 100%;
      }
    }

    &.winner {
      width: 17.8rem/1.5/2;
      height: 22rem/1.5/2;
      background: #FFE5A1;
      border-radius: .6rem/1.5/2;
      display: flex;

      .lottery_content {
        font-size: 14px;
        margin: .2rem/1.5/2;
        flex: 1;
        position: relative;
        background: linear-gradient(0deg, #D91F21, #F2673B);
        border-radius: .4rem/1.5/2;

        .inner_warp {
          position: absolute;
          top: .35rem/1.5/2;
          bottom: .35rem/1.5/2;
          left: .35rem/1.5/2;
          right: .35rem/1.5/2;
          border: 2px solid #FFE5A1;
          opacity: 0.3;
        }

        .angle {
          width: 1.3rem/1.5/2;
          height: 1.3rem/1.5/2;
          background: salmon;
          position: absolute;

          &.close_angle {
            width: 2rem/1.5/2;
            height: 2rem/1.5/2;
            top: 0;
            right: -1px;
            background: url(~@/assets/images/lottery/win_close.png) no-repeat;
            background-size: 100% 100%;
          }

          &.left_top_angle {
            top: 0;
            left: 0;
            background: url(~@/assets/images/lottery/win_angle_01.png) no-repeat;
            background-size: 100% 100%;
          }

          &.left_bottom_angle {
            left: 0;
            bottom: 0;
            background: url(~@/assets/images/lottery/win_angle_02.png) no-repeat;
            background-size: 100% 100%;
          }

          &.right_bottom_angle {
            right: 0;
            bottom: 0;
            background: url(~@/assets/images/lottery/win_angle_03.png) no-repeat;
            background-size: 100% 100%;
          }
        }

        .reword_detail {
          width: 14.2rem/1.5/2;
          height: 14.4rem/1.5/2;
          background: url(~@/assets/images/lottery/-s-light.png) no-repeat;
          background-size: 100% 100%;
          position: absolute;
          left: 50%;
          transform: translate(-50%, 0);

          .tips_title {
            font-size: 1.8rem/1.5/2;
            color: #FFE5A1;
            text-align: center;
            margin-top: 5.26rem/1.5/2;

            &>div {
              &:nth-of-type(2) {
                margin-top: .80rem/1.5/2;
                font-size: 14px;
              }
            }
          }

          .reword_name {
            position: relative;
            margin-top: 1.04rem/1.5/2;
            left: 50%;
            transform: translateX(-50%);
            width: 15.2rem/1.5/2;
            height: 4.7rem/1.5/2;
            background: url(~@/assets/images/lottery/win_gift.png) no-repeat;
            background-size: 100% 100%;
            text-align: center;
            line-height: 4.7rem/1.5/2;
            font-size: .8rem/1.5/2;
            color: #AE3F39;
          }
        }

        .view_reword_list {
          position: absolute;
          bottom: 1.6rem/1.5/2;
          left: 50%;
          transform: translateX(-50%);
          color: #FFE5A1;
          font-size: .8rem/1.5/2;
          white-space: nowrap;
          display: flex;
          justify-content: center;
          align-items: center;

          .view_go {
            display: inline-block;
            width: .4rem/1.5/2;
            height: .6rem/1.5/2;
            background: url(~@/assets/images/lottery/go.png) no-repeat;
            background-size: 100% 100%;
            margin-left: 10px;
          }
        }
      }
    }

    &.lose {
      width: 17.8rem/1.5/2;
      height: 22rem/1.5/2;
      background: linear-gradient(0deg, #F1603B, #FC8A4D);
      border-radius: .6rem/1.5/2;
      display: flex;

      .lottery_content {
        font-size: 14px;
        margin: .2rem/1.5/2;
        flex: 1;
        position: relative;
        background: #FEE7DA;
        border-radius: .4rem/1.5/2;

        .inner_warp {
          position: absolute;
          top: .35rem/1.5/2;
          bottom: .35rem/1.5/2;
          left: .35rem/1.5/2;
          right: .35rem/1.5/2;
          border: 2px solid #FABEAA;
          opacity: 0.3;
        }

        .angle {
          width: 1.3rem/1.5/2;
          height: 1.3rem/1.5/2;
          background: salmon;
          position: absolute;

          &.close_angle {
            width: 2rem/1.5/2;
            height: 2rem/1.5/2;
            top: -2px;
            right: -2px;
            background: url(~@/assets/images/lottery/btn.png) no-repeat;
            background-size: 100% 100%;
          }

          &.left_top_angle {
            top: 0;
            left: 0;
            background: url(~@/assets/images/lottery/notwin_angle_01.png) no-repeat;
            background-size: 100% 100%;
          }

          &.left_bottom_angle {
            left: 0;
            bottom: 0;
            background: url(~@/assets/images/lottery/notwin_angle_02.png) no-repeat;
            background-size: 100% 100%;
          }

          &.right_bottom_angle {
            right: 0;
            bottom: 0;
            background: url(~@/assets/images/lottery/notwin_angle_03.png) no-repeat;
            background-size: 100% 100%;
          }
        }

        .reword_detail {
          width: 14.2rem/1.5/2;
          height: 14.4rem/1.5/2;
          // background:url(~@/assets/images/lottery/-s-light.png) no-repeat;
          background-size: 100% 100%;
          position: absolute;
          left: 50%;
          transform: translate(-50%, 0);

          .tips_title {
            font-size: 1.8rem/1.5/2;
            color: #661F0D;
            text-align: center;
            margin-top: 5.26rem/1.5/2;

            &>div {
              &:nth-of-type(2) {
                margin-top: .80rem/1.5/2;
                font-size: .8rem/1.5/2;
              }
            }
          }

          .reword_name {
            position: relative;
            margin-top: 1.04rem/1.5/2;
            left: 50%;
            transform: translateX(-50%);
            width: 15.2rem/1.5/2;
            height: 4.7rem/1.5/2;
            background: url(~@/assets/images/lottery/notwin_gift.png) no-repeat;
            background-size: 100% 100%;
            text-align: center;
            line-height: 4.7rem/1.5/2;
            font-size: .8rem/1.5/2;
            color: #F1613C;
          }
        }

        .view_reword_list {
          position: absolute;
          bottom: 1.6rem/1.5/2;
          left: 50%;
          transform: translateX(-50%);
          color: #661F0D;
          font-size: .8rem/1.5/2;
          white-space: nowrap;
          display: flex;
          justify-content: center;
          align-items: center;

          .view_go {
            display: inline-block;
            width: .4rem/1.5/2;
            height: .6rem/1.5/2;
            background: url(~@/assets/images/lottery/notwin_more.png) no-repeat;
            background-size: 100% 100%;
            margin-left: 10px;
          }
        }
      }
    }
  }

  .lottery_list {
    width: 17.8rem/1.5/2;
    height: 22rem/1.5/2;
    background: linear-gradient(0deg, #F1603B, #FC8A4D);
    border-radius: .6rem/1.5/2;
    display: flex;
    top: 50%;
    left: 50%;
    position: absolute;
    transform: translate(-50%, -50%);

    .content {
      font-size: 14px;
      margin: .2rem/1.5/2;
      flex: 1;
      position: relative;
      background: #FEE7DA;
      border-radius: .4rem/1.5/2;
      border-radius: .6rem/1.5/2;

      &::after {
        content: '中奖名单';
        display: block;
        position: absolute;
        width: 9.2rem/1.5/2;
        height: 2.74rem/1.5/2;
        top: 0;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        line-height: 2.5rem/1.5/2;
        background: url(~@/assets/images/lottery/title.png) no-repeat;
        background-size: 100% 100%;
        color: #ffffff;
        font-size: 18px;
      }

      .inner_warp {
        position: absolute;
        top: .35rem/1.5/2;
        bottom: .35rem/1.5/2;
        left: .35rem/1.5/2;
        right: .35rem/1.5/2;
        border: 2px solid #FABEAA;
        opacity: 0.3;
      }

      .angle {
        width: 1.3rem/1.5/2;
        height: 1.3rem/1.5/2;
        background: salmon;
        position: absolute;

        &.close_angle {
          width: 2rem/1.5/2;
          height: 2rem/1.5/2;
          top: -2px;
          right: -2px;
          background: url(~@/assets/images/lottery/btn.png) no-repeat;
          background-size: 100% 100%;
        }

      }

      .list_warp {
        position: absolute;
        top: 50px;
        left: .48rem/1.5/2;
        right: 1rem/1.5/2;
        bottom: 50px;
        // background: salmon;
        padding-left: .5rem;
        box-sizing: border-box;
        overflow-y: scroll;

        &::-webkit-scrollbar {
          width: .12rem;
        }

        &::-webkit-scrollbar-thumb {
          background: #F5CCC1;
          border-radius: .12rem;
        }

        .item {
          font-size: .88rem/1.5/2;
          display: flex;
          align-items: center;
          margin-bottom: .2rem;

          .index {
            color: #BE7866;
          }

          .name {
            margin-left: 1rem/1.5/2;
            color: #7D4E42;
          }
        }
      }
    }
  }

  .close {
    position: absolute;
    bottom: -120px;
    left: 50%;
    margin-left: -20px;
    width: 40px;
    height: 40px;
    display: inline-block;
    background: url(../assets/images/com_cancel.svg) no-repeat;
    background-size: 100%;
    border-radius: 50%;
  }
}
</style>
