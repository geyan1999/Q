<template>
<div class="side-bar-wp">
  <div class="side-bar-bg">
    <!-- 打赏 -->
    <div class="side-bar-btn reword_btn" @click.stop="changeSiseMode(4)" v-if="getConfig && getConfig.global.switch.reward.enable == 1 && isWx"></div>
    <!-- 分享卡 -->
    <div class="side-bar-btn invant_btn" @click.stop="changeSiseMode(2)" v-if="getConfig && getConfig.global.switch.inviteRanking.enable==1 && getConfig.global.setting.pageViewMode == 1 && isWx && !isVod">
    </div>
    <!-- 发红包 -->
    <div class="side-bar-btn redpack_btn" @click.stop="changeSiseMode(5)" v-if="getConfig && getConfig.global.switch.redPack.enable == 1 && isWx && !isVod"></div>
    <!-- 点赞 -->
    <div class="side-bar-btn like_btn" @click.stop="changeSiseMode(3)" v-if="getConfig && getConfig.global.switch.like.enable==1">
    </div>
    <!-- 商城 -->
    <div class="side-bar-btn product_btn" @click.stop="dotab('product')" v-if="getConfig && getConfig.global.switch.store.enable == 1 && getConfig.global.setting.pageViewMode == 1 && !isVod"></div>
  </div>
</div>
</template>

<script>
import flutterHeart from "../assets/js/flutter-hearts-zmt";
import html2canvas from "../assets/js/html2canvas.min";
import * as TYPES from "@/assets/action-types";
import SDKEMIT from "@/assets/js/sdk.emit";
import Reward from "../components/RewardView";
import {
  mapGetters,
  mapActions
} from "vuex";
export default {
  data() {
    return {
      BubbleHearts: null,
      images: null,
      islike: false,
      isVod: window.isVod || 0,
      isWx: false
    };
  },
  computed: {
    ...mapGetters([
      "getListReward",
      "getHtData",
      "getFlagReward",
      "getShareQrcode",
      "getModeSwitch",
      "getPPTModel",
      "getPageModel",
      "getConfig",
      "getpvUserlist",
      "getCurTip"
    ]),
    liveid() {
      if (this.getHtData && this.getHtData.live) {
        return this.getHtData.live.liveid;
      } else {
        return 0;
      }
    },
    PvChatTip(){
      let tip = false
      if(this.getpvUserlist.length>0){
        this.getpvUserlist.forEach(user=>{
          if(user.tip != 0){
            tip = true
          }
        })
      }
      return tip || this.getCurTip
    }
  },
  methods: {
    ...mapActions({
      listReward: "LIST_REWARD"
    }),
    getIsWxClient() {
      var ua = navigator.userAgent.toLowerCase();
      if (ua.match(/MicroMessenger/i) == "micromessenger") {
        return true;
      }
      return false;
    },
    like() {
      var canvas = this.BubbleHearts.canvas;
      var images = this.images;
      var BubbleHearts = this.BubbleHearts;
      canvas.width = 120;
      canvas.height = 200;
      canvas.style["width"] = "2rem";
      canvas.style["height"] = "3rem";
      canvas.id = "bubble-heart";
      var random = {
        uniform: function (min, max) {
          return min + (max - min) * Math.random();
        },
        uniformDiscrete: function (i, j) {
          return i + Math.floor((j - i + 1) * random.uniform(0, 1));
        }
      };
      if (!document.querySelector("#bubble-heart")) {
        document.getElementsByClassName("side-bar-wp")[0].append(canvas);
        BubbleHearts.bubble(
          images[random.uniformDiscrete(0, images.length - 1)]
        );
      } else {
        BubbleHearts.bubble(
          images[random.uniformDiscrete(0, images.length - 1)]
        );
      }
      if (!this.islike) {
        this.islike = true;
      }
    },
    getList() {
      this.listReward({
        vm: this,
        data: {
          liveid: this.liveid,
          page: 1
        }
      });
      this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 1);
      // this.jquery("#loading").removeClass("hidden");
      this.$vux.loading.show({
        text: "Loading"
      });
    },
    back() {
      this.$store.commit(TYPES.UPDATE_SIDE_MODE, 0);
      this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 0);
    },
    changeSiseMode(type) {
      if (type == 2) {
        this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 1);
      }
      if (type == 5) {
        this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 1);
        this.$store.commit(TYPES.UPDATE_REWARD_STATUS, 1);
        return
      }
      this.$store.commit(TYPES.UPDATE_SIDE_MODE, type);
    },
    initLikeAnimation() {
      var that = this;
      flutterHeart();
      var assets = [
        "../assets/images/heart.svg",
        "../assets/images/heart.svg",
        "../assets/images/heart.svg",
        "../assets/images/heart.svg",
        "../assets/images/heart.svg"
      ];
      assets.forEach(function (src, index) {
        assets[index] = new Promise(function (resolve) {
          var img = new Image();
          img.onload = resolve.bind(null, img);
          var str = src;
          img.src = require("../assets/images/heart.svg");
        });
      });
      Promise.all(assets).then(function (images) {
        that.BubbleHearts = new BubbleHearts();
        that.images = images;
      });
    },
    dotab(tab) {
      let type = this.getConfig ? this.getConfig.global.switch.store.type : 0;
      let url = this.getConfig ? this.getConfig.global.switch.store.data.url : '';
      if (tab === 'product') {
        if (type == 1) {
          // 打开商城列表
          this.$emit("Tabup", "product", "no_link");
        } else if (type == 2) {
          // 打开商城链接
          window.location.href = url;
        } else if (type == 3) {
          // 打开商城二维码
          this.$store.commit(TYPES.UPDATE_SIDE_MODE, 7);
        }
      }
      if (tab === 'private_chat') {
        this.$vux.loading.show({
            text: "Loading"
          });
        SDKEMIT.getOnline(this.HTSDK, {
          "page": 1,
          "size": 100
        }, list => {
          // 客服列表
          if (list.length > 0) {
            let private_chat_list = []
            list.forEach(element => {
              if (element.role === 'admin') {
                private_chat_list.push(element)
              }
            });
            // console.error(private_chat_list)
            this.$store.dispatch("setPvUserlist", private_chat_list)
          }
          //   打开客服私聊
          this.$emit("Tabup", "private_chat");
          this.$vux.loading.hide()
        })
      }
    }
  },
  mounted() {
    this.isWx = this.getIsWxClient();
  }
};
</script>

<style src='@/assets/less/sidebar.less' lang='less'></style>
