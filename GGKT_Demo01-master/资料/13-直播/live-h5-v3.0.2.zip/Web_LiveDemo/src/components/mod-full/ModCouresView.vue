<template>
<!--#课件模式 -->
<div class="mod-ecom-wp mod-coures-wp" :class="getScreenStatus" @click="control()">
  <!-- 课件容器 -->
  <div class="ppt_media" :style="[pptbackground,full]" :class="{full:ppt_full}">
    <div id="ht_course_container"></div>
  </div>
  <!-- #全屏摄像头 -->
  <div id="ht_camera_container" class="live_media" :class="{pause:getVideoStatus==='pause'}" v-show="liveCurMode === 0 && getVideoCurMode==0" :style="background"></div>
  <!-- #外部推流 -->
  <div id="ht_player_container" class="live_media" :class="{pause:getVideoStatus==='pause'}" v-show="getVideoCurMode == 0 && liveCurMode === 2" :style="background"></div>
  <!-- 直播状态遮罩 -->
  <div class="masker" v-show="getLiveState !== 'start' && getVideoCurMode==0 && !(getConfig.global.switch.warmup && getConfig.global.switch.warmup.enable==1)" :style="background">
    <div class="masker_content" :class="{no_icon:!(liveState==='直播已结束'&&!background)}">
      <div class="_tip" v-if="!getToolsTime">{{liveState}}</div>
    </div>
  </div>
  <!-- 播放器加载动画 -->
  <div class="_masker_loading" v-if="getLiveState === 'start' && getVideoCurMode==0 && getVideoStatus==='waiting' && !getVideoPause && getCameraStatus !== 'close' ">
    <div class="loader loader-7">
      <div class="line line1"></div>
      <div class="line line2"></div>
      <div class="line line3"></div>
      <div class="text_line">正在加载直播...</div>
    </div>
  </div>
  <!-- 自动播放检测遮罩 -->
  <div class="live_media_pause" v-if="getVideoStatus==='pause' && getLiveState === 'start'" @click="play">
    <i class="icon"></i>
  </div>
  <!-- 摄像头状态 -->
  <div class="camera_status" v-if="getCameraStatus === 'close' && getLiveState === 'start' && getVideoStatus==='onplay' && liveCurMode === 0">
    <div class="zhubo_image">
      <img :src="getAnchorimg" alt="">
      <div class="loader loader-7">
        <!-- <div class="line line1"></div>
        <div class="line line2"></div>
        <div class="line line3"></div> -->
      </div>
      <div class="tip">语音直播中</div>
    </div>
  </div>
  <!-- 刷新按钮 -->
  <div class="replay" @click.stop="replay()" :class="{replaying:timer}" v-show="on_replay&&getLiveState === 'start'"></div>
  <!-- ppt全屏 -->
  <div class="ppt_full" @click.stop="pptFull" v-show="on_replay&&getLiveState === 'start'" :class="{full:ppt_full}"></div>
  <!-- 互动工具 -->
  <tools-view></tools-view>
  <!-- 加载中动画 -->
  <div class="loading hidden" id="loading">
    <div class="loading_bg">
      正在加载中
      <div class="cicle_warp">
        <div class="cicle1 cicle"></div>
        <div class="cicle2 cicle"></div>
        <div class="cicle3 cicle"></div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
import ToolsView from "@/components/ToolsView"
import WarmVideo from "@/components/WarmVideo"
import * as util from "../../assets/js/util";
import {
  mapGetters,
  mapActions
} from "vuex";

export default {
  name: "e-comView",
  data() {
    return {
      zhubo: {},
      timer: null,
      isIos: false,
      on_replay: false,
      replay_timer: null,
      isVod: window.isVod || 0,
      warm_onplay: false,
      ppt_full:false
    };
  },
  components: {
    ToolsView,
    WarmVideo
  },
  methods: {
    ...mapActions({
      updateRankList: "GET_RANK_LIST"
    }),
    warmOnplayHandle() {
      this.warm_onplay = true
    },
    control() {
      this.on_replay = true
      if (this.replay_timer) {
        clearTimeout(this.replay_timer);
      }
      this.replay_timer = setTimeout(() => {
        this.on_replay = false
      }, 3000);
    },
    back() {
      if (window.history) {
        window.history.back()
      }
    },
    play() {
      if (this.HTSDK) {
        this.HTSDK.play();
      }
    },
    pptFull(){
      this.ppt_full = !this.ppt_full
      setTimeout(()=>{
        // this.HTSDK.playerResize()
      })
    },
    replay() {
      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => {
        if (this.HTSDK) {
          // this.HTSDK.play();
          this.HTSDK.reload();
          this.timer = null;
        }
      }, 1000);
    },
  },
  computed: {
    ...mapGetters([
      "getHtData",
      "getLiveState",
      "getScreenStatus",
      "liveCurMode",
      "getVideoCurMode",
      "getVideoStatus",
      "getVideoPause",
      "getConfig",
      "getProductIdList",
      "getZhuboRewardMsg",
      "getCameraStatus",
      "getAnchorimg",
      "getToolsTime"
    ]),
    liveState() {
      if (this.getLiveState === "wait") {
        return "主播暂时不在，稍后再来";
      } else if (this.getLiveState === "stop") {
        return "直播已结束";
      }
    },
    pptbackground() {
      let getConfig = this.getConfig
      if (getConfig && getConfig.global.switch.pptbackground && getConfig.global.switch.pptbackground.enable == 1 && getConfig.global.switch.pptbackground.url != '') {
        return {
          background: 'url(' + getConfig.global.switch.pptbackground.url + ') no-repeat',
          backgroundSize: '100% 100%',
        }
      } else {
        return false
      }
    },
    background() {
      let getConfig = this.getConfig
      if (getConfig && getConfig.global.switch.background && getConfig.global.switch.background.enable == 1 && getConfig.global.switch.background.url != '') {
        return {
          background: 'url(' + getConfig.global.switch.background.url + ') no-repeat',
          backgroundSize: '100% 100%',
        }
      } else {
        return false
      }
    },
    full(){
      let dom = document.querySelector("#app")
      let w = dom.offsetWidth
      let h = dom.offsetHeight
      if(this.ppt_full){
        return {
          top:`${(h-w)/2}px`,
          left:`-${(h-w)/2}px`
        }
      }else{
        return {}
      }
    }
  },
  watch: {
    getHtData(nv, ov) {
      this.zhubo = nv.zhubo;
      if (nv.InitData && nv.InitData.step2) {
        this.$store.commit("UPDATE_WHITEBOARD", true)
      }
    },
    getVideoStatus(nv, ov) {
      if (nv === "onplay") {
        this.timer = null;
      }
      if (nv === "overTime") {
        this.HTSDK.reload();
      }
    },
    getVideoCurMode(nv,ov) {
      // console.error(nv)
    }
  },
  mounted() {
    this.control()
    this.isIos = util.isIos();
  }
};
</script>

<style src='@/assets/less/tpl_ecom.less' lang='less'></style>
