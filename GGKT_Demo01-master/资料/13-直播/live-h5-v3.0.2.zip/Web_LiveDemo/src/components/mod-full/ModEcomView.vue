<template>
<!--#全屏模式 -->
<div class="mod-ecom-wp" :class="getScreenStatus" @click="control()">
  <!-- #全屏摄像头 -->
  <div id="ht_camera_container" class="live_media" :class="{pause:getVideoStatus==='pause'}" v-show="liveCurMode === 0 && getVideoCurMode==0" :style="background"></div>
  <!-- #课件模块 -->
  <div id="ht_player_container" class="live_media" :class="{pause:getVideoStatus==='pause'}" v-show="getVideoCurMode == 0 && liveCurMode === 2" :style="background"></div>
  <!-- 直播状态遮罩 -->
  <div :class="{'masker':true}" v-show="getLiveState !== 'start' && getVideoCurMode==0 && !(getConfig.global.switch.warmup && getConfig.global.switch.warmup.enable==1)" :style="background">
    <div class="masker_content">
      <div class="_tip" v-if="!getToolsTime">{{liveState}}</div>
    </div>
  </div>
  <!-- 暖场视频 -->
  <div class="masker" v-show="getLiveState !== 'start' && getVideoCurMode==0 && getConfig.global.switch.warmup&&getConfig.global.switch.warmup.enable==1" :style="[{zIndex:warm_onplay?100:200},background]">
    <warm-video @onplay="warmOnplayHandle"></warm-video>
  </div>
  <!-- 播放器加载动画 -->
  <div class="_masker_loading" v-if="getLiveState === 'start' && getVideoCurMode==0 && getVideoStatus==='waiting' && !getVideoPause && getCameraStatus !== 'close' ">
    <div class="loader loader-7">
      <div class="line line1"></div>
      <div class="line line2"></div>
      <div class="line line3"></div>
      <div class="text_line">正在加载直播...</div>
    </div>
  </div>
  <!-- 自动播放检测遮罩 -->
  <div class="live_media_pause" v-if="getVideoStatus==='pause' && getLiveState === 'start'" @click.stop="play">
    <i class="icon"></i>
  </div>
  <!-- 摄像头状态 -->
  <div class="camera_status" v-if="getCameraStatus === 'close' && getLiveState === 'start' && getVideoStatus==='onplay' && liveCurMode === 0">
    <div class="zhubo_image">
      <img :src="getAnchorimg" alt="">
      <div class="loader loader-7">
      </div>
      <div class="tip">语音直播中</div>
    </div>
  </div>
  <!-- 刷新按钮 -->
  <div class="replay" @click.stop="replay()" :class="{replaying:timer}" v-show="on_replay"></div>
  <!-- 浮动广告 -->
  <float-ad style="z-index:110"></float-ad>
  <!-- 互动工具 -->
  <tools-view :style="clareScreen_style" :clear="clareScreen_style"></tools-view>
  <!-- 加载中动画 -->
  <div class="loading hidden" id="loading">
    <div class="loading_bg">
      正在加载中
      <div class="cicle_warp">
        <div class="cicle1 cicle"></div>
        <div class="cicle2 cicle"></div>
        <div class="cicle3 cicle"></div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
import ToolsView from "@/components/ToolsView"
import FloatAd from "@/components/FloatAd"
import WarmVideo from "@/components/WarmVideo"
import * as util from "../../assets/js/util";
import {
  mapGetters,
  mapActions
} from "vuex";

export default {
  name: "e-comView",
  data() {
    return {
      zhubo: {},
      timer: null,
      isIos: false,
      on_replay: false,
      replay_timer: null,
      isVod: window.isVod || 0,
      clareScreen_style: null,
      warm_onplay:false
    };
  },
  components: {
    ToolsView,
    WarmVideo,
    FloatAd
  },
  methods: {
    ...mapActions({
      updateRankList: "GET_RANK_LIST"
    }),
    warmOnplayHandle(){
      this.warm_onplay = true
    },
    clareScreen() {
      // console.error(this.getToolsClaer)
      if (this.getToolsClaer) {
        if (this.clareScreen_style) {
          this.clareScreen_style = null
        } else {
          this.clareScreen_style = {
            transform: 'translateX(-100%)',
            transition: '.5s'
          }
        }
      }
    },
    control() {
      this.on_replay = true
      this.clareScreen()
      if (this.replay_timer) {
        clearTimeout(this.replay_timer);
      }
      this.replay_timer = setTimeout(() => {
        this.on_replay = false
      }, 3000);
    },
    back() {
      if (window.history) {
        window.history.back()
      }
    },
    play() {
      if (this.HTSDK) {
        this.HTSDK.play();
      }
    },
    replay() {
      if (this.timer) {
        clearTimeout(this.timer);
      }
      this.timer = setTimeout(() => {
        if (this.HTSDK) {
          // this.HTSDK.play();
          this.HTSDK.reload();
          this.timer = null;
        }
      }, 1000);
    },
  },
  computed: {
    ...mapGetters([
      "getHtData",
      "getLiveState",
      "getScreenStatus",
      "liveCurMode",
      "getVideoCurMode",
      "getVideoStatus",
      "getVideoPause",
      "getConfig",
      "getProductIdList",
      "getZhuboRewardMsg",
      "getCameraStatus",
      "getAnchorimg",
      "getToolsTime",
      "getToolsClaer"
    ]),
    liveState() {
      if (this.getLiveState === "wait") {
        //指定合作商
        if (this.getHtData && this.getHtData.course && this.getHtData.course.course_id == 394363 ||
          this.getHtData && this.getHtData.course && this.getHtData.course.course_id == 394362 ||
          this.getHtData && this.getHtData.course && this.getHtData.course.course_id == 398690) {
          return '敬请期待'
        }
        return "主播暂时不在，稍后再来";
      } else if (this.getLiveState === "stop") {
        return "直播已结束";
      }
    },
    background() {
      let getConfig = this.getConfig
      if (getConfig && getConfig.global.switch.background && getConfig.global.switch.background.enable == 1 && getConfig.global.switch.background.url != '') {
        return {
          background: 'url(' + getConfig.global.switch.background.url + ') no-repeat',
          backgroundSize: '100% 100%',
        }
      } else {
        return false
      }
    },
    adlist(){
      return (this.getConfig&&this.getConfig.adlist) || []
    },
    adConfig(){
      return (this.getConfig&&this.getConfig.global.switcher.ad&&this.getConfig.global.switcher.ad.enable == 1) ? true : false
    },
    contentSize(){
      let _app = document.querySelector('#app')
      return {
        width:_app.clientWidth,
        height:_app.clientHeight
      }
    }
  },
  watch: {
    getHtData(nv, ov) {
      this.zhubo = nv.zhubo;
    },
    getVideoStatus(nv, ov) {
      if (nv === "onplay") {
        this.timer = null;
      }
      if (nv === "overTime") {
        this.HTSDK.reload();
      }
    },
  },
  mounted() {
    // this.control()
    this.isIos = util.isIos();
  }
};
</script>

<style src='@/assets/less/tpl_ecom.less' lang='less'></style>
