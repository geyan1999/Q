<template>
<div id="chat" class="mod_chat_hall">
  <!-- #消息 -->
  <div id="chat_scroller" class="mod_chat_list mod_com_scroller wrapper" v-if="config('chat')">
    <ul id="chat_hall" class="chat_inner content">
      <li class="chat-item" :id="'item_' + index" v-for="(item, index) in chatList" :key="index">
        <!-- #聊天消息 -->
        <div class="pub_msg" v-if="!item.type">
          <img :src="item.avatar" alt class="avatar" />
          <div class="chat_right spadmin">
            <div class="chat_head_com">
              <span class="nickname">{{item.nickname}}</span>
              <span class="chat_time" v-if="getConfig&&getConfig.global.switch.chatTime.enable == 1">{{item.time | getTime}}</span>
            </div>
            <p class="chat_detail" v-html="renderMsg(item.msg)" v-if="!item.image"></p>
            <p class="chat_detail image" v-if="item.image">
              <img :src="item.image" alt="" v-gallery:group1>
            </p>
          </div>
        </div>
        <!-- #红包信息 -->
        <div class="pub_msg reward_msg" v-if="item.type === 'notify_reward' && isWx">
          <div v-if="!item.reward.get">
            <img :src="item.reward.avatar" alt class="avatar" />
            <div class="chat_right spadmin">
              <div class="chat_head_com">
                <span class="nickname">{{item.reward.nickname}}</span>
                <span class="chat_time">{{item.reward.time | getTime}}</span>
              </div>
              <div class="reward_bg" @click.stop="changeRewardState(2, index, item.reward)">
                <div class="reward_title">{{item.reward.title}}</div>
                <div class="reward_type">普通红包</div>
              </div>
            </div>
          </div>
          <div class="reward_getlist" v-if="item.reward.get">
            <span class="getlist_icon"></span>
            <span>{{item.reward.get === '红包已被领取完'? '红包已被领取完':item.reward.get + '领取了你的红包'}}</span>
          </div>
        </div>
        <!-- #打赏消息 -->
        <div class="pub_msg reward_zhubo_msg" v-if="item.type === 'notify_reward_zhubo'">
          <div class="inner_warp">
            <span class="nickname">{{item.nickname}}</span>打赏了主播一个<span class="pirce">{{item.money}}</span>元的红包
          </div>
        </div>
      </li>
    </ul>
  </div>
  <!-- 进入直播消息 -->
  <div class="into_msg" v-if="getConfig&&getConfig.global.switch.entranceTips.enable == 1">
    <transition name="fade">
      <!-- <div class="into_msg" v-if="getintoRoom&&!intoroom"> -->
      <div class="into_msg_warp" v-if="roomData">
        <div class="avatar">
          <img :src="roomData.member.avatar" :alt="roomData.member.nickname" />
        </div>
        <div class="msg">{{roomData.member.nickname}}</div>
        <div class="msg_placeholder">进入</div>
      </div>
      <!-- </div> -->
    </transition>
  </div>
  <!-- chat Post -->
  <div id="mode_chat_post" class="mod_chat_post_v2">
    <!-- 网络优化提示 -->
    <div class="network_tip" v-if="networkTip&&isVod==0&&getLiveState === 'start'">
      <span>直播不流畅，请尝试</span>
      <span class="try_replay try_btn" @click.stop="replay">刷新</span>
      <span class="try_switch try_btn" @click.stop="switchNetwork">切换网络</span>
    </div>
    <!-- 聊天功能区 -->
    <div class="post_con" :class="{pull_post:pullbox||onSend||emojibox}">
      <div class="input_warp">
        <input id="chat_post_txt" class="mod_chat_ipt" type="text" placeholder="来说点什么吧" autocomplete="off" @focus="onChatFocus()" :chatMsg="chatMsg" @blur="onBlur()" v-model.trim="chatMsg" v-if="config('chat')" />
        <span class="emoji_btn" :class="{send:emojibox}" @mousedown.stop="openEmoji($event)" v-show="onSend||emojibox"></span>
      </div>
      <span class="mod_chat_ipt" v-if="!config('chat')"></span>
      <!-- <span data-type="chat" @touchend.stop="chat_send($event)" class="csend" v-if="onSend">发送</span> -->
      <span data-type="chat" @mousedown.stop="chat_send($event)" class="csend" :class="{onsend:chatMsg}" v-if="(onSend && config('chat')) || emojibox">发送</span>
      <span class="like" :class="{select:like}" @click.stop="dotab('tab')" v-if="getConfig && getConfig.global.switch.menu.enable == 1 && !onSend && !emojibox"></span>
      <span ref="pull_down_icon" @click.stop="boxContro('pulldown')" class="pull_down_icon" v-if="pulldownShwo&&!onSend&&!emojibox"></span>
    </div>
    <!-- 表情包 -->
    <div class="emoji" :class="{edit:emojibox}">
      <ul>
        <li v-for="(value, key,index) in emojiPack" :key="index" @click.stop="emoji(key)">
          <img :src="value" alt="正在加载..." :title="key" />
        </li>
      </ul>
    </div>
    <!-- 下拉框 -->
    <div class="pull_down" :class="{pull:pullbox}" v-if="pulldownShwo">
      <ul>
        <li @click.stop="dotab('info')" v-if="!(getConfig&&getConfig.global.switch.more.data.info == 0) && isWx && !isVod">
          <div class="item info_icon">
            <span></span>
          </div>
          <span>个人中心</span>
        </li>
        <li @click.stop="dotab('line')" v-if="!(getConfig&&getConfig.global.switch.more.data.liveLine == 0) && !isVod">
          <div class="item line_icon">
            <span></span>
          </div>
          <span>线路切换</span>
        </li>
        <li @click.stop="getList()" v-if="!(getConfig&&getConfig.global.switch.more.data.redPackRecord == 0) && isWx && !isVod">
          <div class="item reward_icon">
            <span></span>
          </div>
          <span>红包记录</span>
        </li>
        <li @click.stop="changeRewardState(5)" v-if="!(getConfig&&getConfig.global.switch.more.data.withdraw == 0) && isWx">
          <div class="item reward_cash">
            <span></span>
          </div>
          <span>提现</span>
        </li>
        <li @click.stop="dotab('product',getConfig.global.switch.more.data.store.url)" v-if="getConfig&&getConfig.global.switch.more.data.store.enable == 1">
          <div class="item product_icon">
            <span></span>
          </div>
          <span>商城</span>
        </li>
        <li @click.stop="dotab('private_chat')" v-if="getConfig && getConfig.global.switch.service && getConfig.global.switch.service.enable == 1">
          <div class="item private_icon">
            <span></span>
          </div>
          <span>私聊</span>
        </li>
        <li @click.stop="dotab('report')" v-if="!(getConfig&&getConfig.global.switch.more.data.report == 0) && !isVod">
          <div class="item report_icon">
            <span></span>
          </div>
          <span>举报</span>
        </li>
      </ul>
      <div v-if="getHtData.zhubo.partner_id==13067">
        <p>直播技术由欢拓云直播提供</p>
      </div>
    </div>
    <!-- 网络选择 -->
    <div class="line_tab" :class="{linebox:linebox}">
      <div class="tip">网络选择</div>
      <div class="line_warp">
        <div class="line_content">
          <div class="line" :class="{active:curline === index}" v-for="(item,index) in getLiveLine" :key="index" @click.stop="changeLine(item.key)">{{item.label}}</div>
        </div>
      </div>
    </div>
    <!-- 个人信息修改 -->
    <infomation :class="{infobox:infobox}" @tab="tabDown"></infomation>
  </div>
  <!-- 推荐商品弹出 -->
  <product-pop v-if="getConfig&&getConfig.global.switch.store.enable == 1"></product-pop>
  <!-- 侧边栏 -->
  <side-bar class="full-side-bar" @Tabup="dotab"></side-bar>
</div>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
import SDKEMIT from "@/assets/js/sdk.emit";
import jQuery from "jquery";
import * as tools from "@/assets/js/util";
import * as TYPES from "@/assets/action-types";
import SideBar from "../SideBar";
import Infomation from "../Infomation"
import fixOverflowScroll from "fix-overflow-scroll";
import BScroll from "better-scroll";
import IScroll from "iscroll";
import ProductPop from '../ProductPop'
export default {
  name: "ChatView",
  components: {
    SideBar,
    Infomation,
    ProductPop
  },
  data() {
    return {
      word: "",
      scrollTimer: null,
      emojibox: false,
      pullbox: false,
      linebox: false,
      infobox: false,
      curline: 0,
      emojiPack: {
        "[微笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon1.png",
        "[调皮]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon2.png",
        "[害羞]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon3.png",
        "[奸笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon4.png",
        "[憨笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon5.png",
        "[尴尬]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon6.png",
        "[鼓掌]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon7.png",
        "[惊讶]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon8.png",
        "[闭嘴]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon9.png",
        "[呲牙]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon10.png",
        "[大哭]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon11.png",
        "[大笑]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon12.png",
        "[得意]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon13.png",
        "[囧]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon14.png",
        "[难过]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon15.png",
        "[敲打]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon16.png",
        "[色]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon17.png",
        "[委屈]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon18.png",
        "[疑问]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon19.png",
        "[郁闷]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon20.png",
        "[再见]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon21.png",
        "[可怜]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon22.png",
        "[捂脸]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon23.png",
        "[笑哭]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon24.png",
        "[安慰]": "//static-1.talk-fun.com/open/cooperation/common/emotions/live/emoticon25.png"
      },
      isWx: true,
      msg: "",
      chatMsg: "",
      role: {
        spadmin: "管理员",
        admin: "助教",
        user: "学生"
      },
      timecount: 0,
      onSend: false,
      like: false,
      timer: null,
      intoroomlist: [], // 缓存数组
      roomData: null,
      isVod: window.isVod || 0,
      checkTimer: null,
      networkTip: false
    };
  },
  filters: {
    // todo...
    getTime(_time) {
      return tools.convertTimestamp(_time);
    },
    // render
    renderImg(msg) {
      // console.warn(msg)
      msg = '<img src="' + msg.replace(/\[(.+?)\]/g, "") + '" />';
      return msg;
    },
    // emoji
    renderEmoji(msg) {
      // msg = msg.replace(/\[*.\]/, '')
      return msg;
    }
  },
  computed: {
    // ...mapGetters(["getChatList", "getHtData", "getRewardTimer", "getActModule"]),
    ...mapGetters([
      "getChatList",
      "getHtData",
      "getRewardTimer",
      "getFlagReward",
      "getRewardCurhid",
      "getModeSwitch",
      "getintoRoom",
      "getConfig",
      "getLiveLine",
      "getUser",
      "getLiveState"
    ]),
    chatList() {
      let result = this.getChatList.map(item => {
        if (item.type === "notify_reward") {
          item.reward = this.notifyRewardHander(item);
          return item;
        }
        if (item.msg && item.msg.indexOf("[IMG]") > -1) {
          item.image = item.msg.replace(/\[(.+?)\]/g, "").replace(/_s\.jpg/, '.jpg');
          //  console.error(item.msg)
          //  .replace(/_s\.jpg/, '.jpg')
        }
        return item;
      });
      return result;
    },
    liveid() {
      if (this.getHtData.live) {
        return this.getHtData.live.liveid;
      } else {
        return 0;
      }
    },
    pulldownShwo() {
      let more = this.getConfig && this.getConfig.global.switch.more.data || {}
      if (this.isWx) {
        return (more.info == 0 && more.liveLine == 0 && more.redPackRecord == 0 && more.withdraw == 0 && (more.store && more.store.enable == 0) && more.report == 0) ? false : true
      } else {
        return (more.liveLine == 0 && (more.store && more.store.enable == 0) && more.report == 0) ? false : true
      }
    }
  },
  methods: {
    ...mapActions({
      fireChat: "CHAT_UPDATE_LIST",
      checkReward: "CHECK_REWARD",
      indexCashReward: "INDEX_CASH_REWARD",
      listReward: "LIST_REWARD"
    }),
    replay() {
      this.HTSDK.reload()
    },
    switchNetwork() {
      this.linebox = !this.linebox;
      let linebox = () => {
        this.linebox = false;
        document
          .getElementById("app")
          .removeEventListener("click", linebox, false);
      };
      document
        .getElementById("app")
        .addEventListener("click", linebox, false);
    },
    scrollInfo() {
      if (this.config('chat')) {
        this.$nextTick(() => {
          const bscroller = new BScroll("#chat_scroller", {
            click: true
            // preventDefault:false
          });
          this.bscroller = bscroller;
          this.bscroller.refresh();
          this.bscroller.scrollTo(0, -99999);
          // 聊天滚动优化
          this.bscroller.on("scrollEnd", () => {
            this.scrollTimer = setTimeout(() => {
              let item = document.querySelector("#item_" + (this.getChatList.length - 1));
              setTimeout(() => {
                this.bscroller.refresh();
                this.bscroller.scrollToElement(item, 100);
              }, 60);
              this.scrollTimer = null
            }, 2000)
          })
          this.bscroller.on("scrollStart", () => {
            if (this.scrollTimer) {
              clearTimeout(this.scrollTimer)
            }
          })
        });
      }
    },
    tabDown() {
      this.infobox = false
    },
    config(type) {
      let flag = false;
      if (this.getConfig) {
        this.getConfig.content.tabsData.forEach((item) => {
          if (item.type === type) {
            flag = true
          }
        })
      }
      return flag
    },
    getIsWxClient() {
      var ua = navigator.userAgent.toLowerCase();
      if (ua.match(/MicroMessenger/i) == "micromessenger") {
        return true;
      }
      return false;
    },
    onChatFocus(e) {
      setTimeout(() => {
        this.jquery(document).scrollTop(this.jquery(window).height());
      }, 250);
      this.emojibox = false
      this.onSend = true;
    },
    renderMsg(msg) {
      if (!msg) {
        return false;
      }
      let _rule = /\[(.+?)\]/g;
      let _list = msg.match(_rule);
      if (_list && _list.length > 0) {
        // 截图
        if (msg.indexOf("[IMG]") > -1) {
          var imgClip = msg.replace(/\[(.+?)\]/g, "");
          return '<img src="' + imgClip + '" />';
        }
        // 表情
        msg = msg.replace(_rule, (r, k) => {
          let emoji = this.emojiPack[r];
          if (emoji) {
            return '<img src="' + emoji + '"' + 'class="emoji_img"' + '/>';
          }
        });
      }
      return msg;
    },
    // 获取头像
    getAvatar(_avatar) {
      if (!_avatar.a) {
        _avatar.a = 1;
      }
      let avaObj = this.HTSDK.getAvatar(_avatar);
      return avaObj.avatar;
    },
    // 表情
    emoji(key){
      this.chatMsg += key
    },
    // 发送聊天
    chat_send(event) {
      /**
       * 具体的发送聊天限制待处理
       */
      SDKEMIT.chatSend(this.HTSDK, this.chatMsg, res => {
        // console.error(res, this)
        if (res.code !== 0) {
          this.$vux.toast.text(res.msg, "bottom");
          return false;
        }
        this.chatMsg = "";
        // 时间格式转化
        res.data.time = tools.convertTimestamp(res.data);
        // let d = {
        //   type: 'normal_chat',
        //   originCnt: res.data
        // }
        this.fireChat({
          chatObject: res.data
        });
      });
      document.getElementById("chat_post_txt").blur();
      this.onSend = false;
      this.emojibox = false
      event.preventDefault();
    },
    seeVoteDetail(vid) {
      this.HTSDK.plugins("vote").getVoteDetail(vid, retval => {
        this.$store.commit("UPDATE_VOTE_STATUS", "end");
        this.$store.commit("UPDATE_VOTE_POP_STATUS", "open");
        this.$store.commit("UPDATE_VOTE_RESULT", retval);
      });
    },
    notifyVoteHander(cnt) {
      let desc;
      let actTxt;
      let status;

      if (typeof cnt.isShow !== "undefined") {
        desc = `在${cnt.info.endTime}结束了投票。`;
        actTxt = "查看结果";
        status = "end";
      } else {
        desc = `在${cnt.info.startTime}发起了一个`;
        actTxt = "投票";
        status = "start";
      }

      return {
        roleZh: this.role[cnt.info.role],
        nickname: cnt.info.nickname,
        desc: desc,
        actTxt: actTxt,
        status: status,
        vid: cnt.info.vid
      };
    },
    notifyRewardHander(item) {
      let data = {
        nickname: item.originCnt.nickname,
        avatar: item.originCnt.avatar,
        title: item.originCnt.title,
        time: item.originCnt.time,
        hid: item.originCnt.hid,
        user: item.originCnt.user
      };
      if (item.end == 1) {
        // 领取红包信息
        data = {};
        data.get = item.originCnt.nickname;
      } else if (item.end == 2) {
        // 红包领取完信息
        data = {};
        data.get = "红包已被领取完";
      }
      return data;
    },
    onBlur() {
      document.body.scrollTop = document.documentElement.scrollTop = 0;
      this.jquery("#app").scrollTop(0);
      if (this.chatMsg === "") {
        this.onSend = false;
      }
      if (window.parent && window.parent.postMessage) {
        window.parent.postMessage('chat:on:blur', "*");
      }
      this.networkTip = false
    },
    changeLine(line) {
      this.HTSDK.setLine(line)
      this.curline = line
      this.linebox = false;
      setTimeout(() => {
        this.$vux.toast.text('线路切换成功', "bottom");
        // this.linebox = false;
      }, 1000)
    },
    openEmoji(event){
      this.emojibox = !this.emojibox;
      document.getElementById("chat_post_txt").blur();
      event.preventDefault();
    },
    boxContro(type) {
      let that = this;
      if (type === "emoji") {
        this.emojibox = !this.emojibox;
      } else if (type === "pulldown") {
        this.pullbox = !this.pullbox;
        let pulldown = () => {
          this.pullbox = false;
          document
            .getElementById("app")
            .removeEventListener("click", pulldown, false);
        };
        document
          .getElementById("app")
          .addEventListener("click", pulldown, false);
      }
      event.preventDefault();
    },
    addEmojiMsg() {
      let that = this;
      if (event.target.nodeName === "IMG") {
        var value = event.target.getAttribute("title");
        document.querySelector("#chat_post_txt").value += value;
        that.chatMsg += value;
        this.emojibox = false;
      }
    },
    changeRewardState(val, index, reward) {
      if (val == 2) {
        // 打开红包前检查红包是否可以领取
        if (
          this.getRewardTimer ||
          tools.isMe(reward.user, this.getHtData.user)
        ) {
          this.$store.commit("UPDATE_REWARD_HID", reward.hid);
          // console.log(this.getRewardCurhid);
          this.checkReward({
            vm: this,
            data: {
              liveid: this.liveid,
              hid: this.getRewardCurhid
            },
            reward: reward
          });
          // this.jquery("#loading").removeClass("hidden");
          this.$vux.loading.show({
        text: "Loading"
      });
          this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 1);
        } else {
          this.$vux.toast.text("观看1分钟后才能参与红包领取", "bottom");
        }
      } else if (val == 5) {
        // 我的钱包
        this.indexCashReward({
          vm: this
        });
        // this.jquery("#loading").removeClass("hidden");
        this.$vux.loading.show({
        text: "Loading"
      });
        this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 1);
        this.pullbox = false;
      } else {
        this.$store.commit(TYPES.UPDATE_REWARD_STATUS, val);
        this.pullbox = false;
      }
    },
    dotab(type, url) {
      // console.error(type,url)
      if (type === 'product') {
        if (url !== '' && url !== 'no_link') {
          window.location.href = url;
        } else if (url === 'no_link') {
          this.$emit("Tab", 'product');
        }
      } else {
        if (type === 'report') {
          this.$store.commit(TYPES.UPDATE_SIDE_MODE, 8);
          this.pullbox = !this.pullbox;
          return
        }
        if (type === 'info') {
          this.infobox = !this.infobox;
          this.pullbox = !this.pullbox;
          return
        }
        if (type === 'line') {
          this.linebox = !this.linebox;
          this.pullbox = !this.pullbox;
          let linebox = () => {
            this.linebox = false;
            document.getElementById("app").removeEventListener("click", linebox, false);
          };
          document.getElementById("app").addEventListener("click", linebox, false);
          return
        }
        if (type === 'private_chat') {
          this.$emit("Tab", 'private_chat');
          return
        } else {
          this.$emit("Tab", 'tab');
        }
      }
    },
    getList() {
      this.listReward({
        vm: this,
        data: {
          liveid: this.liveid,
          page: 1
        }
      });
      this.$store.commit(TYPES.UPDATE_VIEWO_MODE, 1);
      this.pullbox = false;
      // this.jquery("#loading").removeClass("hidden");
      this.$vux.loading.show({
        text: "Loading"
      });
    },
  },
  watch: {
    getChatList(nv, ov) {
      if (this.bscroller && !this.scrollTimer) {
        // console.error(nv, ov)
        this.$nextTick(() => {
          let item = document.querySelector("#item_" + (nv.length - 1));
          // console.warn(item)
          setTimeout(() => {
            this.bscroller.scrollToElement(item, 100);
          }, 50);
        });
      }
    },
    getintoRoom(nv, ov) {
      if (this.timer) {
        // 添加到缓存数组中,去除重复进入的用户
        if (!this.intoroomlist.some((item, index, arr) => {
            return item.member.xid === nv.member.xid;
          })) {
          this.intoroomlist.push(nv);
        }
      } else {
        // 设置当前数据
        this.roomData = nv;
        this.timer = true;
        setTimeout(() => {
          this.roomData = null;
          this.timer = false;
        }, 1000);
        // console.error("当前", this.roomData, this.intoroomlist);
      }
    },
    roomData(nv, ov) {
      let i = 0,
        list = this.intoroomlist,
        len = this.intoroomlist.length;
      if (!nv && !this.timer) {
        // 当前没有数据的时候，如果数组不为空则循环缓存数组
        if (len > 0) {
          for (i; i < len; i++) {
            let data = list[i];
            setTimeout(
              (function (roomdata, i, len, vm) {
                return function () {
                  vm.roomData = data;
                  // console.error("进入队列", i);
                  if (i === len - 1) {
                    vm.intoroomlist = [];
                    vm.timer = false;
                  }
                  setTimeout(() => {
                    // console.error("队列结束");
                    vm.roomData = null;
                  }, 1000);
                };
              })(list[i], i, len, this),
              (i + 1) * 2000
            );
          }
          this.timer = true;
        }
      }
    },
    chatMsg(nv) {
      if (this.onSend) {
        if (this.checkTimer) {
          clearTimeout(this.checkTimer)
          this.checkTimer = null
        }
        this.checkTimer = setTimeout(() => {
          if (this.chatMsg.search("卡") !== -1) {
            this.networkTip = true
          }
          this.checkTimer = null
        }, 500)
      } else {
        return
      }
    }
  },
  mounted() {
    this.isWx = this.getIsWxClient();
    let that = this;
    let _wrap = this.jquery("#chat_scroller");
    _wrap.bind("click", function () {
      that.jquery("#chat_post_txt").blur();
    });
    this.jquery(".live_media,.masker,.timer_count,.camera_status").on("touchend", e => {
      this.emojibox = false
    });
    this.jquery(".live_media,.masker,.timer_count,.camera_status").on("click", e => {
      this.emojibox = false
    });
    this.scrollInfo()
  }
};
</script>

<style lang="less" scoped>
@import "../../assets/less/chat.less";

html {
  &::-webkit-scrollbar {
    width: 0;
  }
}

.mod_chat_hall {
  position: absolute;
  top: 60%;
  left: 0;
  right: 0;
  bottom: 45px;
  z-index: 200;

  .chat-item {
    text-align: left;
  }

  .mod_chat_post_v2 {
    z-index: 1600;
    bottom: 0;
    width: 100%;
    max-width: 750px;
    position: fixed;

    .network_tip {
      height: 2.4rem/2;
      background: #F6F8F9;
      font-size: 16px;
      color: #3F5465;
      padding: 0 .6rem/2;
      display: flex;
      justify-content: space-between;
      align-items: center;

      .try_btn {
        padding: .24rem/2 .65rem/2;
        border-radius: .7rem/2;
        background: #FFFFFF;
        border: 1px solid #B2BDC4;
        color: #3B96B4;
      }
    }

    .post_con {
      &.pull_post {
        background-color: #ffffff;
        .mod_chat_ipt {
          color: black;
          border:1px solid #EEEEEE;
          background: #ffffff;
          // margin: 0 0 0 0.16rem;

          &::placeholder {
            color: #C6CDD2;
          }
        }
      }

      padding: 5% 2%;
      display: flex;
      align-items: center;
      // justify-content: center;

      .input_warp{
        position: relative;
        // padding-left: 0.2rem;
        // margin: 0 0 0 0.16rem;
        height: 1.4rem/2;
        flex: 1;
        .emoji_btn{
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          right: .2rem;
          width: .92rem/2;
          height: .92rem/2;
          display: inline-block;
          background: url(~@/assets/images/live-v2/emoticon@2x.png) no-repeat;
          background-size: 100% 100%;
          &.send{
            background: url(~@/assets/images/live-v2/word@2x.png) no-repeat;
          background-size: 100% 100%;
          }
        }
      }

      .mod_chat_ipt {
        display: block;
        width: 100%;
        padding:0 1.5rem/2 0 0.2rem;
        box-sizing: border-box;
        background-color: rgba(0, 0, 0, 0.3);
        border: none;
        color: #ffffff;
        font-size: 14px;
        height: 100%;
        outline: none;
        border-radius: .7rem/2;
        // display: block;
        overflow: hidden;

        &::placeholder {
          color: #EEF4F8;
          opacity: .6;
        }
      }

      .csend {
        width: 1rem;
        height: 0.6rem;
        line-height: 0.6rem;
        text-align: center;
        border-radius: 0.36rem;
        background-color: #C5D0D6;
        color: #fff;
        font-size: 16px;
        display: block;
        margin-left: 10px;
        flex: none;
        &.onsend{
          background-color: #01C2FF;
        }
      }

      .like {
        width: 0.6rem;
        height: 0.6rem;
        background: rgba(0, 0, 0, 0.3) url("../../assets/images/live-v2/pullup.svg") no-repeat;
        background-size: 60%;
        background-position: center center;
        display: block;
        position: relative;
        margin: 0 5px 0 15px;
        border-radius: 50%;
        flex: none;

        &.select {
          background: url("../../assets/images/live/like.svg") no-repeat;
          background-size: 100%;
        }
      }

      .pull_down_icon {
        width: 0.6rem;
        height: 0.6rem;
        display: inline-block;
        margin: 0 0.16rem 0 0.28rem;
        background: rgba(0, 0, 0, 0.3) url("../../assets/images/live-v2/more.svg") no-repeat;
        background-size: 66%;
        background-position: center center;
        border-radius: 50%;
        flex: none;
      }
    }

    .emoji {
      height: 0px;
      background: #ffffff;
      transition: 0.5s;
      overflow: hidden;
      border-top: 1px solid #EEEEEE;

      &.edit {
        height: auto;
      }

      ul {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-wrap: wrap;
        // justify-content: space-around;
        padding:.3rem/2;
        box-sizing: border-box;
        li {
          margin:.3rem/2;
          width: .6rem;
          height: .6rem;
          img{
            width: 100%;
            height: 100%;
            display: block;
            object-fit: fill;
          }
        }
      }
    }

    .pull_down {
      min-height: 2.1rem;
      // height: 0;
      width: 100%;
      position: absolute;
      bottom: 0;
      transform: translate(0, 100%);
      font-size: 14px;
      background: rgba(246, 248, 249, 1);
      box-shadow: 0px -1px 0px rgba(0, 0, 0, 0.05);
      transition: 0.5s;
      overflow: hidden;

      &.pull {
        transform: translate(0, 0);
      }

      ul {
        // margin: 0.4rem 0.3rem;
        margin-top: .4rem;
        // padding-top: 0.4rem;
        list-style: none;

        &::after {
          content: "";
          display: block;
          clear: both;
        }

        li {
          float: left;
          margin: 0 .22rem .55rem;
          text-align: center;
          width: 2.6rem/2;
          height: 2.6rem/2;

          // background: saddlebrown;
          // &:nth-of-type(4n) {
          //   margin: 0;
          // }

          // &:nth-of-type(n+5) {
          //   margin-top: 0.55rem;
          // }

          .item {
            width: 1rem;
            height: 1rem;
            // border-radius: 50%;
            margin: 0 auto 0.1rem;
            // background: white;

            &:active {
              background: #e7ecef;
            }

            span {
              display: inline-block;
              width: 100%;
              height: 100%;
              vertical-align: -0.48rem;
            }

            &.reward_icon {
              span {
                background: url("../../assets/images/live-v2/reward_icon.png") no-repeat;
                background-size: 100% 100%;
              }
            }

            &.reward_cash {
              span {
                background: url("../../assets/images/live-v2/reward_cash.png") no-repeat;
                background-size: 100% 100%;
              }
            }

            &.product_icon {
              span {
                background: url("../../assets/images/live-v2/product_icon.png") no-repeat;
                background-size: 100%;
              }
            }

            &.private_icon {
              span {
                background: url("../../assets/images/live-v2/private_icon.png") no-repeat;
                background-size: 100%;
              }
            }

            &.line_icon {
              span {
                background: url("../../assets/images/live-v2/line_icon.png") no-repeat;
                background-size: 100%;
              }
            }

            &.info_icon {
              span {
                background: url("../../assets/images/live-v2/info_icon.png") no-repeat;
                background-size: 100%;
              }
            }

            &.report_icon {
              span {
                background: url("../../assets/images/live-v2/report_icon.png") no-repeat;
                background-size: 100%;
              }
            }
          }
        }
      }

      &>div {
        color: #B2BDC4;
        text-align: center;
        position: relative;
        margin: -0.25rem 0 0.2rem;

        &::after {
          content: '';
          display: block;
          clear: both;
        }

        p {
          float: left;
          left: 50%;
          margin: 0;
          margin-left: 50%;
          transform: translate(-50%, 0);
        }
      }
    }

    .line_tab {
      bottom: -100%;
      position: fixed;
      height: 6.4rem/2;
      width: 100%;
      background: #F6F8F9;
      display: flex;
      flex-direction: column;
      // transform: translate(0, 100%);
      transition: .5s;
      visibility: hidden;

      &.linebox {
        // transform: translate(0, 0);
        bottom: 0;
        visibility: visible;
      }

      .tip {
        height: 1rem;
        font-size: 16px;
        color: #95A0A8;
        padding-left: 15px;
        box-sizing: border-box;
        line-height: 1rem;
        border-bottom: 1px solid rgba(0, 0, 0, 0.12);
      }

      .line_warp {
        flex: 1;
        font-size: 16px;
        position: relative;

        .line_content {
          position: absolute;
          display: flex;
          height: .7rem;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          border-radius: 35px;
          background: #E2F3FF;

          .line {
            width: 3.4rem/2;
            border-radius: 35px;
            text-align: center;
            line-height: .7rem;
            // background: #3DADFF;
            color: #3DADFF;

            &.active {
              background: #3DADFF;
              color: #FFFFFF;
            }
          }
        }
      }
    }
  }

  .mod_chat_list {
    // height: 50vh;
    overflow: hidden;

    // position: relative;
    .pub_msg {
      // margin-bottom: 10px;

      .avatar {
        width: 0.8rem;
        height: 0.8rem;
        margin-right: 0;
        margin-left: auto;
        vertical-align: top;
      }

      .chat_right {

        // font-size: 12px;
        .chat_time {
          padding-left: 0;
          color: #ececec;
        }

        margin-left: 0;

        .chat_head_com {
          padding: 0 0 0 8px;

          .nickname {
            color: #ffcd44;
            margin-right: 0.05rem;
            font-size: 14px;
          }

          .chat_time {
            color: rgba(125, 138, 148, 1);
            font-size: 14px;
          }
        }
      }

      .reward_bg {
        width: 4.36rem;
        height: 1.74rem;
        background: url("../../assets/images/reward_msg.svg") no-repeat;
        background-size: 100%;
        transition: 0.3s;

        &:active {
          transform: scale(0.9);
        }

        &.get {
          opacity: 0.5;
        }

        .reward_title {
          color: rgba(255, 255, 255, 1);
          font-weight: bold;
          height: 1.2rem;
          margin-left: 0.9rem;
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
          padding-top: 0.4rem;
          box-sizing: border-box;

          span {
            display: block;
          }

          &.get {
            padding-top: 0.2rem;
          }
        }

        .reward_type {
          height: 0.5rem;
          line-height: 0.5rem;
          margin-left: 12px;
          color: rgba(198, 205, 210, 1);

          &.get {
            vertical-align: -10px;
          }
        }
      }

      .chat_detail {
        margin: 0;
        margin-left: 10px;
        padding: 5px !important;
        font-size: 12px !important;
        background-color: rgba(39, 46, 52, 0.4) !important;
        color: #ffffff !important;

        /deep/.emoji_img{
          width: 30px;
          height: 30px;
          vertical-align: bottom;
        }

        &.image {
          padding: 0 !important;
          margin-left: 5px;
          background: none !important;

          &::after {
            display: none;
          }
        }

        &::after {
          // display: none;
          content: "";
          display: block;
          position: absolute;
          left: -7px;
          top: 6px;
          width: 0;
          height: 0;
          border-top: 5px solid transparent;
          border-bottom: 5px solid transparent;
          border-right: 5px solid rgba(39, 46, 52, 0.4) !important;
        }

        img {
          width: 100%;
          height: 2.3rem;
          object-fit: cover;
          border-radius: 5px;
        }
      }
    }

    .into_msg {
      position: relative;
      height: 30px;

      .into_msg_warp {
        color: #ffffff;
        height: 30px;
        padding: 0 10px 0 6px;
        display: flex;
        align-items: center;
        text-align: center;
        background: linear-gradient(270deg,
            rgba(80, 231, 255, 0.8) 0%,
            rgba(64, 179, 255, 0.8) 100%);
        box-shadow: 0px 3px 6px rgba(45, 171, 255, 0.16);
        border-radius: 33px;
        position: absolute;
        max-width: 380px/2;
        left: 50%;
        transform: translate(-50%, 0);
        line-height: 30px;

        .avatar {
          flex: none;
          width: 25px;
          height: 25px;
          border-radius: 50%;
          overflow: hidden;

          img {
            width: 100%;
            height: 100%;
          }
        }

        .msg {
          // flex: none;
          height: 100%;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
          padding-left: 5px;
        }

        .msg_placeholder {
          flex: none;
          width: 32px;
        }
      }
    }

    .reward_msg {
      .reward_getlist {
        text-align: center;
        margin-top: 10px;
        color: rgba(198, 205, 210, 1);

        .getlist_icon {
          display: inline-block;
          width: 18px;
          height: 22px;
          background: url("../../assets/images/reward_msg_ico.svg") no-repeat;
          background-size: 100%;
          vertical-align: -0.12rem;
        }
      }
    }

    .reward_zhubo_msg {
      text-align: center;
      padding: 10px 0;

      // position: relative;
      .inner_warp {
        display: inline;
        // position: absolute;
        background: rgba(255, 255, 255, .9);
        padding: 10px 12px;
        font-size: 14px;
        border-radius: 8px;
        color: #434f58;

        .nickname {
          color: #FFB444;
        }

        .pirce {
          color: #FF4141;
        }
      }
    }
  }

  .into_msg {
    position: absolute;
    top: -40px;
    left: 10px;
    height: 30px;
    width: 206px;
    overflow: hidden;

    .into_msg_warp {
      // position: absolute;
      // height: 30px;
      // top: 10px;
      // left: 10px;
      // flex: 1;
      font-size: 14px;
      color: #ffffff;
      height: 30px;
      padding: 0 10px 0 6px;
      display: flex;
      align-items: center;
      text-align: center;
      background: linear-gradient(270deg,
          rgba(80, 231, 255, 0.8) 0%,
          rgba(64, 179, 255, 0.8) 100%);
      box-shadow: 0px 3px 6px rgba(45, 171, 255, 0.16);
      border-radius: 5px;
      position: absolute;
      max-width: 380px/2;
      line-height: 30px;

      .avatar {
        flex: none;
        width: 25px;
        height: 25px;
        border-radius: 50%;
        overflow: hidden;

        img {
          width: 100%;
          height: 100%;
        }
      }

      .msg {
        // flex: none;
        height: 100%;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        padding-left: 5px;
      }

      .msg_placeholder {
        flex: none;
        width: 32px;
      }
    }
  }

  .fade-enter-active,
  .fade-leave-active {
    transition: 0.5s;
  }

  .fade-enter {
    transform: translate(-100%, 0);
  }

  .fade-enter-to {
    transform: translate(0, 0);
  }

  .fade-leave {
    opacity: 1;
  }

  .fade-leave-to {
    opacity: 0;
  }
}
</style>
