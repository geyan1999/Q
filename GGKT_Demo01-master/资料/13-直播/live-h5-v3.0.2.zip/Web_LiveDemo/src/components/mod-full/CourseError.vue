<template>
<div class="mod-ecom-wp">
  <!-- 直播状态遮罩 -->
  <div class="masker">
    <p>主播暂时不在，稍后再来</p>
  </div>
  <!-- #全屏摄像头 -->
  <div id="ht_camera_container" class="live_media"></div>
  <!-- #聊天 -->
  <div id="chat" class="mod_chat_hall full_chat">
    <!-- chat Post -->
    <div id="mode_chat_post" class="mod_chat_post_v2">
      <div class="post_con" :class="{pull_post:pullbox||onSend}">
        <span id="chat_post_txt" class="mod_chat_ipt">直播未开始，不能发送聊天</span>
        <span ref="pull_down_icon" @click.stop="boxContro('pulldown')" class="pull_down_icon"></span>
      </div>
      <!-- 下拉框 -->
      <div class="pull_down" :class="{pull:pullbox}">
        <ul>
          <li @click.stop="tip()">
            <div class="item product_icon">
              <span></span>
            </div>
            <span>商城</span>
          </li>
          <li @click.stop="tip()">
            <div class="item reward_icon">
              <span></span>
            </div>
            <span>红包</span>
          </li>
          <li @click.stop="tip()">
            <div class="item reward_cash">
              <span></span>
            </div>
            <span>提现</span>
          </li>
        </ul>
      </div>
    </div>
    <!-- 侧边栏 -->
    <div class="side-bar-wp">
      <div class="side-bar-bg">
        <div class="side-bar-btn invant_btn" @click.stop="tip()"></div>
        <div class="side-bar-btn redpack_btn" @click.stop="tip()"></div>
        <div class="side-bar-btn like_btn" @click.stop="dolike()"></div>
        <div class="side-bar-btn product_btn" @click.stop="tip()"></div>
      </div>
    </div>
  </div>
  <side-content></side-content>
</div>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
import SideContent from '../SideContent';
import * as TYPES from "@/assets/action-types";
export default {
  name: "ChatView",
  components: {
    SideContent
  },
  data() {
    return {
      pullbox: false,
      onSend: false,
      like: false,
      timer: null
    };
  },
  computed: {
    ...mapGetters([
      "getChatList",
      "getHtData",
      "getRewardTimer",
      "getFlagReward",
      "getRewardCurhid",
      "getModeSwitch",
      "getintoRoom"
    ])
  },
  methods: {
    boxContro(type) {
      let that = this;
      if (type === "emoji") {
        this.emojibox = !this.emojibox;
        document.onclick = function () {
          that.emojibox = false;
        };
      } else if (type === "pulldown") {
        this.pullbox = !this.pullbox;
        let pulldown = () => {
          this.pullbox = false;
          document
            .getElementById("app")
            .removeEventListener("click", pulldown, false);
        };
        document
          .getElementById("app")
          .addEventListener("click", pulldown, false);
      }
    },
    tip() {
      this.$vux.toast.text("直播未开始", "middle");
    },
    dolike() {
      this.$store.commit(TYPES.UPDATE_SIDE_MODE, 3);
    }
  },
  watch: {},
  mounted() {}
};
</script>

<style lang="less" scoped>
@import '../../assets/less/reset.less';
@import '../../assets/less/sidebar.less';

.mod-ecom-wp {
  height: 100vh;

  .live_doc {
    width: 95%;
    height: 30%;
    position: relative;
    z-index: 300;
    border-radius: 2px;
    margin: auto;
    background: #ececec;
    padding: 2px;
    box-shadow: rgba(109, 109, 109, 0.7) 1px 1px 11px;
  }

  .masker {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    height: 100%;
    z-index: 105;
    font-size: 16px;
    color: #eaeef3;
    text-align: center;
    background: url("~@/assets/images/live-v2/bg_full.png") no-repeat;
    background-size: 100% 100%;

    .ico_stop {
      padding-top: 50%;
      display: block;
    }

    .ico_live {
      display: block;
      margin: auto;
      width: 30px;
      height: 30px;
      fill: #ec9b4b;
    }

    p {
      font-size: 17px;
      font-weight: bold;
      color: #b9b9b9;
      padding-top: 50%;
      text-align: center;
    }
  }

  .live_media {
    #tf-xplay-icon {
      position: absolute !important;
    }

    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    height: 100vh;
    z-index: 100;
    background: url('../../assets/images/live-v2/bg_full.png') no-repeat;
    background-size: 100% 100%;

    video {
      height: 100vh !important;
      object-fit: cover;
    }
  }

  .full_chat {
    .mod_chat_list {
      background: none;
    }
  }

  .mod_chat_post_v2 {
    z-index: 1600;
    bottom: 0;
    width: 100%;
    max-width: 750px;
    position: fixed;

    .post_con {
      &.pull_post {
        background-color: rgba(246, 248, 249, 1);

        .mod_chat_ipt {
          color: black;
          background: rgba(255, 255, 255, 1);

          &::placeholder {
            color: #ffffff;
            color: rgba(198, 205, 210, 1);
          }
        }
      }

      padding: 2%;
      display: flex;
      align-items: center;

      .mod_chat_ipt {
        padding-left: 0.2rem;
        background-color: rgba(39, 46, 52, 0.3);
        border: none;
        color: #ffffff;
        font-size: 14px;
        margin: 0 0 0 0.16rem;
        height: 1.4rem/2;
        flex: 1;
        outline: none;
        position: relative;
        border-radius: .7rem/2;
        line-height: 1.4rem/2;

        &::placeholder {
          color: #EEF4F8;
          opacity: .6;
        }
      }

      .csend {
        width: 1rem;
        height: 0.6rem;
        line-height: 0.6rem;
        text-align: center;
        border-radius: 0.36rem;
        background-color: #70b3ff;
        color: #fff;
        font-size: 16px;
        display: block;
        position: relative;
        margin-left: 10px;
      }

      .like {
        width: 0.6rem;
        height: 0.6rem;
        background: rgba(0, 0, 0, 0.3) url("../../assets/images/live/pullup.svg") no-repeat;
        background-size: 100%;
        display: block;
        position: relative;
        margin: 0 5px 0 20px;
        border-radius: 50%;

        &.select {
          background: url("../../assets/images/live/like.svg") no-repeat;
          background-size: 100%;
        }
      }

      .pull_down_icon {
        width: 0.6rem;
        height: 0.6rem;
        display: inline-block;
        margin: 0 0.16rem 0 0.28rem;
        background: rgba(0, 0, 0, 0.3) url("../../assets/images/live-v2/more.svg") no-repeat;
        background-size: 66%;
        background-position: center center;
        border-radius: 50%;
      }
    }

    .emoji {
      height: 0px;
      background: gray;
      transition: 0.5s;
      overflow: hidden;

      &.edit {
        height: 100px;
      }

      ul {
        list-style: none;
        padding: 0;
        margin: 0;

        &::after {
          content: "";
          display: block;
          clear: both;
        }

        li {
          float: left;
        }
      }
    }

    .pull_down {
      // height: 2.1rem;
      height: 0;
      font-size: 14px;
      background: rgba(246, 248, 249, 1);
      box-shadow: 0px -1px 0px rgba(0, 0, 0, 0.05);
      transition: 0.5s;
      overflow: hidden;

      &.pull {
        height: 2.1rem;
      }

      ul {
        margin: 0.3rem 0.6rem;
        padding: 0;
        list-style: none;

        &::after {
          content: "";
          display: block;
          clear: both;
        }

        li {
          float: left;
          margin-right: 0.6rem;
          text-align: center;

          .item {
            width: 0.8rem;
            height: 0.8rem;
            // border-radius: 50%;
            margin: 0 auto 0.1rem;
            // background: white;

            &:active {
              background: #e7ecef;
            }

            span {
              display: inline-block;
              width: 100%;
              height: 100%;
              vertical-align: -0.48rem;
            }

            &.reward_icon {
              span {
                background: url("../../assets/images/reward_icon.svg") no-repeat;
                background-size: 100%;
              }
            }

            &.reward_cash {
              span {
                background: url("../../assets/images/re_cash.svg") no-repeat;
                background-size: 100%;
              }
            }

            &.product_icon {
              span {
                background: url("../../assets/images/live-v2/product.svg") no-repeat;
                background-size: 100%;
              }
            }
          }
        }
      }
    }
  }

  .side-bar-wp {
    z-index: 300;
    bottom: 1.5rem;
  }
}
</style>
