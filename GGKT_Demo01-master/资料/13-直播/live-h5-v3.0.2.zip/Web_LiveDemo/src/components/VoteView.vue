<template>
<transition name="fade">
  <div id="vote" class="mod_vote" @click.stop="">
    <div class="mbox_hd">
      <div class="h_left">
        <!-- <i class="vote_icon"></i> -->
        <span class="u_s">{{vote.headerText}}</span>
        (<span class="u_n">{{vote.nickname}}</span>
        <em>{{vote.startTime}} {{vote.actionText}}</em>)
      </div>
      <img class="close_btn" src="@/assets/images/close.svg" @click="closeVotePop()">
    </div>
    <div class="v_body mbox_bd">
      <div class="mod_scroll_box">
        <div v-show="!finished" class="selt_vote_option">
          <!-- <div class="vo_hd">
            <div class="col_l">
              <span class="u_n">{{vote.nickname}}</span>
              <em>{{vote.startTime}} {{vote.actionText}}</em>
            </div>
          </div> -->
          <div class="vo_bd">
            <h4><span class="vo_op">{{vote.optionalText}}</span> {{vote.title}} {{vote.tip}}</h4>
            <!-- selector -->
            <div class="chart_detail vote_selector" v-show="getVoteStatus === 'start'">
              <div class="opt_value" :class="vote.optional === 1 ? 'single' : 'multiple'">
                <ul>
                  <li v-for="item in vote.opList" :key="item.id" :class="item.selected ? (vote.optional === 1 ? 'check' : 'db_check') : ''" @click="selectOption(item)">
                    <span>{{item.id}}、{{item.text}}</span>
                  </li>
                </ul>
              </div>
              <!-- btns -->
              <div class="btn" :class="canSubmit ? 'has_check' : ''" @click="sendVote">
                <span class="vote_btn">投票</span>
              </div>
            </div>
            <!-- result -->
            <div class="chart_detail result" v-show="getVoteStatus === 'end'">
              <dl v-for="item in vote.opList" :key="item.id">
                <dt><em>{{item.id}}. </em>{{item.op}}</dt>
                <dd>
                  <div class="crt_percent_line">
                    <span :style="item.percentStyle"></span>
                  </div>
                  <div class="pn">{{item.opNum}}<em>({{item.percent}}%)</em></div>
                </dd>
              </dl>
              <div class="result_contener" v-if="answer!==''">正确答案：{{answer}}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="mask" v-show="finished">
      <div class="success">
        <div class="icon"></div>
        <div class="tip">投票成功</div>
      </div>
    </div>
  </div>
</transition>
</template>

<script>
import {
  mapGetters
} from 'vuex'
import * as TYPES from "@/assets/action-types"
export default {
  name: 'VoteView',
  data() {
    return {
      options: ['A', 'B', 'C', 'D', 'E', 'F', 'G','H','I','J'],
      canSubmit: false,
      finished: false // 是否完成投票
    }
  },
  computed: {
    ...mapGetters([
      'getVotePopStatus',
      'getNewVote',
      'getVoteStatus',
      'getVoteResult',
      'getToolsVote'
    ]),
    vote() {
      return this.getVoteStatus === 'start' ? this.newVoteHander() : this.voteResultHander()
    },
    answer(){
      return (this.getVoteResult&&this.getVoteResult.info&&this.getVoteResult.info.answer&&this.getVoteResult.info.answer.split(",").reduce((prev, cur, index, array) => {
          return prev + this.options[cur]
        }, '')) || ''
    }
  },
  watch: {
    getToolsVote(nv, ov) {
      if (!nv) {
        this.closeVotePop()
      }
    }
  },
  methods: {
    newVoteHander() {
      let options = this.getNewVote.opList.map((item, index) => {
        return {
          id: this.options[index],
          text: item,
          selected: false
        }
      })
      let d = {
        headerText: '投票中',
        nickname: this.getNewVote.info.nickname,
        startTime: this.getNewVote.info.startTime,
        actionText: '发起了投票',
        title: this.getNewVote.info.title,
        optionalText: +this.getNewVote.optional === 1 ? '单选' : '多选',
        tip: +this.getNewVote.optional === 1 ? '' : `(最多选择${this.getNewVote.optional}项)`,
        opList: options,
        vid: this.getNewVote.vid,
        optional: +this.getNewVote.optional
      }
      return d
    },
    voteResultHander() {
      let options = this.getVoteResult.statsList.map((item, index) => {
        return {
          id: this.options[index],
          op: item.op,
          opNum: item.opNum,
          percent: item.percent,
          percentStyle: {
            width: `${item.percent}%`
          }
        }
      })
      let d = {
        headerText: '投票结果',
        nickname: this.getVoteResult.info.nickname,
        startTime: this.getVoteResult.info.startTime,
        actionText: '发起了投票',
        title: this.getVoteResult.info.title,
        optionalText: +this.getVoteResult.info.optional === 1 ? '单选' : '多选',
        tip: +this.getVoteResult.info.optional === 1 ? '' : `(最多选择${this.getVoteResult.info.optional}项)`,
        opList: options,
        vid: this.getVoteResult.info.vid,
        optional: +this.getVoteResult.info.optional
      }
      return d
    },
    selectOption(option) {
      this.vote.optional === 1 ? this.selectSingleOption(option) : this.selectMultipleOption(option)
    },
    selectSingleOption(option) {
      let options = this.vote.opList
      for (let i = 0; i < options.length; i++) {
        options[i].selected = false
      }
      option.selected = true
      this.canSubmit = true
      // 这里不会再次v-for渲染该数组 所以强制刷新渲染
      this.$forceUpdate()
    },
    selectMultipleOption(option) {
      // 限制多选的选项
      if (this.vote.opList.reduce((prev, cur, index, array) => {
          return prev + (cur.selected ? 1 : 0)
        }, 0) >= this.getNewVote.optional) {
        option.selected = false
      }else{
        option.selected = !option.selected
      }
      this.canSubmit = this.vote.opList.some((item) => {
        return item.selected
      })
      // 这里不会再次v-for渲染该数组 所以强制刷新渲染
      this.$forceUpdate()
    },
    // 发送投票
    sendVote() {
      if (!this.canSubmit) {
        return
      }
      let options = this.vote.opList
      let curOptions = []
      for (let i = 0; i < options.length; i++) {
        let item = options[i]
        item.selected && curOptions.push(i + 1)
      }
      let params = {
        vid: this.vote.vid,
        options: JSON.stringify(curOptions)
      }
      // 发送投票
      this.HTSDK.plugins('vote').postVote(params, (retval) => {
        this.autoClose(3000)
      })
    },
    closeVotePop() {
      this.canSubmit = false
      this.finished = false
      this.$store.commit('UPDATE_VOTE_POP_STATUS', 'close')
      this.$store.commit(TYPES.UPDATE_TOOLS_MODE, {
        type: 'vote',
        flag: false
      })
    },
    autoClose(duration = 3000) {
      this.finished = true
      setTimeout(() => {
        this.closeVotePop()
      }, duration)
    }
  }
}
</script>

<style lang="less" src="@/assets/less/vote.less" scoped></style>
