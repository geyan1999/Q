<template>
<transition name="fade">
  <div class="info_tab" @click.stop="">
    <div class="warp">
      <div class="tip">个人中心
        <span @click.stop="cancel()" class="_back" v-if="editor">返回</span>
      </div>
      <div class="line_warp">
        <div class="inner_warp">
          <span class="info_img_warp">
            <img :src="infomation.img" alt="" class="info_img">
            <span class="mask" v-show="editor" @click.stop="isUp=!isUp"></span>
          </span>
          <input type="text" v-model="infomation.name" class="info_input" v-show="editor" @blur="onBlur()">
          <span class="info_name" v-show="!editor">{{getUser?getUser.nickname:'暂无数据'}}</span>
          <span class="info_editor" v-show="!editor" @click.stop="editor=!editor"></span>
          <span class="info_save" v-show="editor" @click.stop="save()">保存</span>
        </div>
      </div>
    </div>
    <div class="bg_warp" :class="{up:isUp}">
      <div class="input_warp">
        <input type="file" name="" id="" accept="image/*" @change="changeHandle($event)">
        从相册选择
      </div>
      <div class="input_warp">
        <input type="file" name="" id="" accept="image/*" capture="camera" @change="changeHandle($event)">
        拍照
      </div>
      <div @click.stop="isUp=!isUp" class="_cancel">取消</div>
    </div>
  </div>
</transition>
</template>

<script>
import {
  mapGetters,
  mapActions
} from "vuex";
import lrz from 'lrz';
import qs from "qs";
export default {
  data() {
    return {
      infomation: {
        name: '',
        img: ''
      },
      editor: false,
      isUp: false,
      fromdata: {
        img: null
      },
      postStutas: {
        img: 0, // 0 未请求、1正在请求、2请求成功、3请求失败
        name: 0,
        reload_url: ''
      },
      version: ''
    }
  },
  computed: {
    ...mapGetters([
      "getUser",
      "getHtData",
      "getToolsInfomation"
    ]),
  },
  methods: {
    onBlur() {
      document.body.scrollTop = document.documentElement.scrollTop = 0;
      this.jquery("#app").scrollTop(0);
    },
    cancel() {
      this.$emit('tab')
      this.editor = false;
      this.infomation.name = this.getUser.nickname
      this.infomation.img = this.getUser.avatar
    },
    changeHandle(event) {
      let img = event.target.files[0] || null
      let maxSize = 1024 * 1024 * 1
      let limitSize = 1024 * 1024 * 5
      if (img) {
        if (img.size < limitSize) {
          if (img.size > maxSize) {
            let that = this
            this.$vux.loading.show('正在上传')
            lrz(img, {
              quality: 0.2
            }).then(function (rst) {
              //成功时执行
              that.$vux.loading.hide()
              that.infomation.img = rst.base64
              that.fromdata.img = rst.file
            }).catch(function (error) {
              //失败时执行
              this.$vux.alert.show('上传图片失败,请重新上传', 'middle')
            })

          } else {
            // console.error("无压缩")
            let fileReader = new FileReader();
            fileReader.readAsDataURL(img);
            this.$vux.loading.show('正在上传')
            fileReader.onload = (event) => {
              this.$vux.loading.hide()
              this.infomation.img = event.target.result
              this.fromdata.img = img
              // console.error(this.fromdata.img)
            }
          }

        } else {
          this.$vux.alert.show('上传图片大小不能超过5M', 'middle')
        }
      } else {
        this.$vux.alert.show('上传图片失败,请重新上传', 'middle')
      }
      this.isUp = false
    },
    save() {
      if ((!this.fromdata.img) && (this.infomation.name === this.getUser.nickname)) {
        this.$vux.toast.text("请先修改后保存", 'bottom')
      } else if (this.fromdata.img) {
        this.editorImg()
      } else if ((this.infomation.name !== this.getUser.nickname) && (!this.fromdata.img)) {
        this.editorName()
      }
    },
    postHandle() {
      // 只有图片修改请求
      if (this.postStutas.name === 0) {
        this.$vux.loading.hide()
        // 请求成功
        if (this.postStutas.img === 2) {
          this.$vux.toast.text('修改成功', "bottom");
          setTimeout(() => {
            location.reload()
          }, 1000);
        } else {
          // 请求失败
          this.$vux.alert.show(this.postStutas.msg)
          this.postStutas.img = 0
        }
      }
      // 只有名称修改请求
      if (this.postStutas.img === 0) {
        this.$vux.loading.hide()
        // 请求成功
        if (this.postStutas.name === 2) {
          this.$vux.toast.text('修改成功', "bottom");
          setTimeout(() => {
            location.replace(this.postStutas.reload_url)
          }, 1000);
        } else {
          // 请求失败
          this.$vux.alert.show(this.postStutas.msg)
          this.postStutas.name = 0
        }
      }
      // 并发请求
      if (this.postStutas.img !== 0 && this.postStutas.name !== 0) {
        if (this.postStutas.img === 1 || this.postStutas.name === 1) {
          return
        } else {
          this.$vux.loading.hide()
          // 两个请求都修改成功
          if (this.postStutas.img === 2 && this.postStutas.name === 2) {
            this.$vux.toast.text('修改成功', "bottom");
            setTimeout(() => {
              location.replace(this.postStutas.reload_url)
            }, 1000);
            return
          }
          // 图片请求失败或者名称修改失败
          if (this.postStutas.img === 3 || this.postStutas.name === 3) {
            this.postStutas.img = 0
            this.postStutas.name = 0
            this.postStutas.reload_url = ''
            this.$vux.alert.show('保存失败(202),请重新上传')
          }
        }
      }
    },
    editorImg() {
      let _url = this.getHtData.uploadAvatarUrl || ''
      let _access_token = window.access_token || ''
      let fromdata = new FormData();
      fromdata.append('Filedata', this.fromdata.img);
      fromdata.append('access_token', _access_token)
      if (_url !== '') {
        this.postStutas.img = 1
        this.$vux.loading.show('正在保存')
        this.$http({
          method: 'post',
          url: _url,
          data: fromdata,
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }).then((res) => {
          if (res.data.code == 0) {
            this.postStutas.img = 2
            this.editorName(res.data.url)
          } else {
            this.postStutas.img = 3
            this.postStutas.msg = res.data.msg
          }
        }).catch(() => {
          this.postStutas.img = 3
        }).finally(() => {
          this.postHandle()
        })
      } else {
        this.$vux.alert.show('保存图片失败,请重新上传', 'middle')
      }
    },
    editorName(val) {
      if (this.postStutas.img !== 1) {
        this.$vux.loading.show('正在保存')
      }
      let _url = this.getHtData.updateUserUrl || ''
      let _access_token = window.access_token || ''
      let fromdata = {
        access_token: _access_token,
        nickname: this.infomation.name,
        act: 'nickname',
        avatar: val || this.infomation.img
      }
      this.postStutas.name = 1
      this.$http({
        method: 'post',
        url: _url,
        data: fromdata,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        transformRequest: [
          function (data) {
            return qs.stringify(fromdata);
          }
        ]
      }).then((res) => {
        if (res.data.code == 0) {
          this.postStutas.name = 2
          this.postStutas.reload_url = res.data.roomUrl
        } else {
          this.postStutas.name = 3
          this.postStutas.msg = res.data.msg
        }
      }).catch(() => {
        this.postStutas.name = 3
      }).finally(() => {
        this.postHandle()
      })
    }
  },
  mounted() {
    this.infomation.name = this.getUser.nickname
    this.infomation.img = this.getUser.avatar
  }
}
</script>

<style lang="less" scoped>
.info_tab {
  bottom: 0;
  position: absolute;
  height: 6.4rem/2;
  width: 100%;
  background: #F6F8F9;
  display: flex;
  flex-direction: column;
  transition: .5s;
  // &.infobox {
  //   // transform: translate(0, 0);
  //   bottom: 0;
  // }

  .warp {
    height: 100%;
    display: flex;
    flex-direction: column;

    .tip {
      height: 1rem;
      font-size: 16px;
      color: #95A0A8;
      padding: 0 15px;
      box-sizing: border-box;
      line-height: 1rem;
      border-bottom: 1px solid #EBEFF2;
      // text-align: center;

      ._back {
        float: right;
        color: #404D56;
      }
    }

    .line_warp {
      flex: 1;
      font-size: 16px;
      position: relative;
      display: flex;
      padding: 0 15px;
      box-sizing: border-box;
      flex-direction: column;
      justify-content: center;

      // background: saddlebrown;
      .inner_warp {
        display: flex;
        height: 1rem;
        align-items: center;

        // background: sandybrown;
        .info_img_warp {
          width: 1rem;
          height: 1rem;
          border-radius: 50%;
          overflow: hidden;
          position: relative;
          flex: none;

          .info_img {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }

          .mask {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            display: inline-block;
            background: rgba(0, 0, 0, 0.1) url(../assets/images/live-v2/person_carmer.svg) no-repeat;
            background-size: 50% 50%;
            background-position: center center;
          }
        }

        .info_input {
          flex: 1;
          margin: 0 15px;
          height: .88rem;
          outline: none;
          border: 1px solid #BABDBF;
          border-radius: 4px;
          color: #1B3947;
          padding: 0 1em;
        }

        .info_name {
          flex: 1;
          padding: 0 15px;
          box-sizing: border-box;
        }

        .info_editor {
          flex: none;
          display: inline-block;
          width: .44rem;
          height: .44rem;
          background: url(../assets/images/live-v2/person_editor.svg) no-repeat;
          background-size: cover;
        }

        .info_save {
          color: #01C2FF;
          font-size: 18px;
          flex: none;
        }
      }

    }
  }

  .bg_warp {
    width: 100%;
    height: 100%;
    bottom: 0;
    position: absolute;
    // background: sandybrown;
    transform: translate(0, 100%);
    transition: .5s;
    text-align: center;
    background: #F2F2F2;

    // border-radius:20px 20px 0px 0px;
    &.up {
      transform: translate(0, 0)
    }

    .input_warp {
      position: relative;
      font-size: 18px;
      color: #1B3947;
      height: 1rem;
      line-height: 1rem;
      background: #ffffff;

      input {
        position: absolute;
        width: 100%;
        height: 100%;
        opacity: 0;
        left: 0;
        top: 0;
      }
    }

    ._cancel {
      width: 100%;
      position: absolute;
      font-size: 18px;
      height: 1rem;
      line-height: 1rem;
      color: #858F97;
      bottom: 0;
      background: #ffffff;
    }
  }
}

.fade-enter {
  transform: translate(0, 100%);
}

.fade-enter-to {
  transform: translate(0, 0);
}

.fade-leave {
  transform: translate(0, 0);
}

.fade-leave-to {
  transform: translate(0, 100%);
}
</style>
