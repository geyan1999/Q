document.documentElement.style.fontSize = (document.documentElement.clientWidth / 7.5) + 'px'
import Vue from 'vue'
import { AlertPlugin, ToastPlugin, LoadingPlugin, WechatPlugin } from 'vux'
import gallery from 'img-vuer'
import jQuery from 'jquery'
import Store from './store'
import EVENT from '@/assets/event-types'
import * as TYPES from '@/assets/action-types'
import * as tools from '@/assets/js/util'
// swipe
import VueAwesomeSwiper from 'vue-awesome-swiper'
import '@/assets/less/swiper.css'
// element
import {Slider} from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
// axios
import axios from 'axios'
import App from './App'
// FastClick
import FastClick from 'fastclick'
import {pageConfig,sdkConfig} from './config'

FastClick.prototype.focus = function (targetElement) {
  var length;
  if (targetElement.setSelectionRange && targetElement.type.indexOf('date') !== 0 && targetElement.type !== 'time' && targetElement.type !== 'month' && targetElement.type !== 'email') {
    length = targetElement.value.length;
    targetElement.focus();
    targetElement.setSelectionRange(length, length);
  } else {
    targetElement.focus();
  }
};
FastClick.attach(document.body);

// 配置
Vue.config.productionTip = false
// 注入
Vue.prototype.jquery = jQuery
Vue.prototype.EVENT = EVENT
Vue.prototype.TYPES = TYPES
Vue.prototype.tools = tools
Vue.prototype.$http = axios

// 组件
Vue.use(AlertPlugin)
Vue.use(ToastPlugin, { isShowMask: false, 'is-show-mask': false })
Vue.use(LoadingPlugin)
Vue.use(WechatPlugin)
Vue.use(VueAwesomeSwiper)
Vue.use(Slider)
Vue.use(gallery, {
  useCloseButton: false
})
let _vue = new Vue({
  el: '#talkfun_wrapper',
  store: Store,
  // i18n,
  components: {
    App,
  },
  template: '<App/>'
})

window.__vue = _vue
window.pageConfig = pageConfig
window.sdkConfig = sdkConfig