# live-h5

### 安装说明
 - 安装node
 - 安装npm\yarn\cnpm等包依赖工具
 - 使用依赖工具构建相关依赖库 例如：yarn install
 - 在目录下的package.json文件里查看启动命令
 - 在终端启动命令
 - 例如：yarn build (打包命令)、yarn dev(本地启动命令)
### 使用说明
 - 获取token 在html配置相关参数，如有疑问请咨询欢拓技术支持人员
 - config.js 直播功能配置文件，在html页面设置开启后生效，不开启则读取欢拓后台直播配置数据，如后台没有配置数据则默认读取本地配置
### src目录结构说明
  - assets
    - less
    - font
    - images
    - js
      - sdk.emit.js
        > 事件处理的集合
      - sdk.cmd.js
        > 监听事件的集合
      - util.js
        > 工具类
    - action-type.js
      > 
  - components
    - mod-company
      > 半屏模板
    - mod-full
      > 全屏模板
    - mod-playback
      > 回放模板
  - store
    > 状态管理
